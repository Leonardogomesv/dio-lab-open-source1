---
name: Community Challenge
about: Crie uma issue sobre o Desafio proposto a comunidade
title: "[DESAFIO]"
labels: 'community challenge'
assignees: ''

---

*Tem alguma sugestão para quem for fazer o Desafio? Por favor descreva.*
Prestar muito a atenção pois é um conteúdo complicado porém muito legal de se aprender.

*Descreva como você realizou o seu*
Olhando a explicação e replicando.

*Links úteis*
- N/A
