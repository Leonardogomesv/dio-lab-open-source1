# Nome | Bruno Fereira Valentim
# Sobre Mim
Meu nome é Bruno, tenho 24 anos e sou uma pessoa cheia de energia e positiva com excelentes habilidades de comunicação, tanto escrita como verbal. Sou extremamente organizado e trabalhador, com habilidades excepcionais para lidar com pessoas. Trabalho bem de forma independente e sob pressão.

# Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/bruno-valentim-1968b2158//Brunofv99/)


![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Brunofv99&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

[![GitHub Streak](https://streak-stats.demolab.com/?user=Brunofv99&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)

# Tecnologia 

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)