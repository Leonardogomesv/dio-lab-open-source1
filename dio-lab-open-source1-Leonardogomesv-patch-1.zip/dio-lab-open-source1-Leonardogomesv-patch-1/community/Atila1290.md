# Atila Silva 
  Olá eu sou Átila, estou começando na área, comecei por indicações de amigos e estou facinado em aprender cada vez mais, estou no segundo semestre de Ánalise e desenvolvimento de sistemas na UCB
  
## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/atila-silva-40456b144)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://instagram.com/slv_atila19?utm_source=qr&igshid=MzNlNGNkZWQ4Mg%3D%3D)

## Habilidades
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)

## Github status
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Atila1290&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Minhas contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Atila1290&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Atila1290/dio-lab-open-source.git)
