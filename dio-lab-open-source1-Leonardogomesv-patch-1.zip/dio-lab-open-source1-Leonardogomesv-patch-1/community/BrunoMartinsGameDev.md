# Bruno Martins Game and Web Dev
Olá, Sou professor de desenvolvimento web, ensino as linguagens html5, css3, python e o framework django.
Tambem dou aula de C# voltado para o desenvolvimento de jogos usando a Unity.
### Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/Linkedin%20-000000?style=for-the-badge&logo=linkedin)](https://www.linkedin.com/in/brunomartinsgamedev/)        [![Itch.io](https://img.shields.io/badge/Itch%20io-000000?style=for-the-badge&logo=itchdotio&logoColor=ffffff)](https://bruneca.itch.io)
### Linguagens
![CSS3](https://img.shields.io/badge/Css03%20-000000?style=for-the-badge&logo=css3&logoColor=ffffff) ![HTML5](https://img.shields.io/badge/Html05%20-000000?style=for-the-badge&logo=html5&logoColor=ffffff) ![Python](https://img.shields.io/badge/Python%20-000000?style=for-the-badge&logo=python&logoColor=ffffff) ![CSHARP](https://img.shields.io/badge/CSharp%20-000000?style=for-the-badge&logo=csharp&logoColor=ffffff)

### Ferramentas
![Django](https://img.shields.io/badge/Django%20-000000?style=for-the-badge&logo=django&logoColor=ffffff) ![Unity](https://img.shields.io/badge/unity%20-000000?style=for-the-badge&logo=unity&logoColor=ffffff)
![Git](https://img.shields.io/badge/git%20-000000?style=for-the-badge&logo=git&logoColor=ffffff) ![GitHub](https://img.shields.io/badge/github%20-000000?style=for-the-badge&logo=github&logoColor=ffffff) 

### Soft Skills
![Communicative](https://img.shields.io/badge/Communicative-000000?style=for-the-badge)
![Proactive](https://img.shields.io/badge/ProActive-000000?style=for-the-badge)
![Organized](https://img.shields.io/badge/Organized-000000?style=for-the-badge)
![Empathetic](https://img.shields.io/badge/Empathetic-000000?style=for-the-badge)

# GitHub Status
![BrunoMartinsGameDev's Stats](https://github-readme-stats.vercel.app/api?username=BrunoMartinsGameDev&theme=midnight-purple&show_icons=true&hide_border=false&count_private=true)
![BrunoMartinsGameDev's Streak](https://github-readme-streak-stats.herokuapp.com/?user=BrunoMartinsGameDev&theme=midnight-purple&hide_border=false)
![BrunoMartinsGameDev's Top Languages](https://github-readme-stats.vercel.app/api/top-langs/?username=BrunoMartinsGameDev&theme=midnight-purple&show_icons=true&hide_border=false&layout=compact)