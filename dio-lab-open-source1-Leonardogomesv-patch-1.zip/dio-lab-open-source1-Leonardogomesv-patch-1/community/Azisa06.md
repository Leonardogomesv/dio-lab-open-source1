# Azisa06
Olá, me chamo Isabella, tenho 21 anos e atualmente estou cursando o segundo termo de Análise e Desenvolvimento de Sistemas na Fatec.
Entrei na área da programação com pouco entusiasmo, mesmo já tendo certo conhecimento, e hoje sinto que encontrei meu caminho como desenvolvedora, amo muito o que estudo. <3
 
## Habilidades:
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5) ![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4) ![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python) [![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor)](https://www.linkedin.com/in/isabella-thomazini-a997b6275/)

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/isabella-thomazini-a997b6275/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/bella.thomazini/)

[![Git](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=Github&logoColor)](https://www.linkedin.com/in/isabella-thomazini-a997b6275/)