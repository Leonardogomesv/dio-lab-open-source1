<h1 align="center">Olá me chamo Bruno Gabriel Zordenunes </h1> 

- 🔭 Formado em Análise e desenvolvimento de Sistemas
- 🌱 Estou estudando atualmente JavaScript e TypeScript
- 📫  Pode contactar-me por brunogabrielzordenunes@gmail.com

## Status
<div align="center" style="display-flex">

![GitHub Streak](https://streak-stats.demolab.com/?user=Brunouch&theme=bear&background=000&border=30A3DC&dates=FFF/)
</div>


<div align="center" style="display-flex; padding: 5rem; ">
    <a href="https://github.com/Brunouch">
    <img height="160rem" src="https://github-readme-stats.vercel.app/api?username=Brunouch&show_icons=true&theme=tokyonight&include_all_commits=true&count_private=true"/>
    <img height="160rem" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Brunouch&layout=compact&langs_count=7&theme=tokyonight"/>
</div>

## Habilidades

<div align="center" style="display-flex" style="margin: 2rem" >
   <br>
   <img align="center" alt="bruno-Js" height="50" width="60" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
   <img align="center" alt="bruno-HTML" height="50" width="60" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
   <img align="center" alt="bruno-CSS" height="50" width="60" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
   <img align="center" alt ="bruno-c" height="50" width="60" src="https://github.com/devicons/devicon/blob/master/icons/c/c-original.svg">
   <img align="center" alt="bruno-java" height="50" width="60" src="https://github.com/devicons/devicon/blob/master/icons/java/java-original.svg">
   <img align="center" alt="bruno-php" height="50" width="60" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/php/php-original.svg"/>
   <img align="center" alt ="bruno-TS" height="50" width="60" 
   src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/typescript/typescript-plain.svg">
   <img align="center" alt ="bruno-SQL" height="50" width="60" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original-wordmark.svg">
</div>