## Aderigio

[![Linkedin](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/aderigio-ara%C3%BAjo-tom%C3%A9-candido/) 

Primeiro bootcamp. Estudante de TI, em mudança de carreira.

