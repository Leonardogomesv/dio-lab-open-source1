# André Vinícius (Andrews-X3)

## Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-FFF?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/andre-vinicius-lopes/)                          [![Instagram](https://img.shields.io/badge/Instagram-FFF?style=for-the-badge&logo=instagram)](https://www.instagram.com/_andre.vinicius_/) 

## Habilidades em desenvolvimento

![HTML5](https://img.shields.io/badge/HTML5-FFF?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-FFF?style=for-the-badge&logo=css3&logoColor=264CE4)
![JavaScript](https://img.shields.io/badge/JavaScript-FFF?style=for-the-badge&logo=javascript)
![TypeScript](https://img.shields.io/badge/TypeScript-FFF?style=for-the-badge&logo=typescript)
![Python](https://img.shields.io/badge/Python-FFF?style=for-the-badge&logo=python)

## GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Andrews-X3&theme=transparent&bg_color=FFF&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=000)

## Minhas contribuições

[![GitHub Streak](https://streak-stats.demolab.com/?user=Andrews-X3&background&border=30A3DC&dates=30A3DC)](https://git.io/streak-stats)