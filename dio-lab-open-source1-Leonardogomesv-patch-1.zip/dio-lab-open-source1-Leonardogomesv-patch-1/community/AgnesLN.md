# Olá, eu sou a Agnês! 👋

Oii, pessoal!

Eu sou do interior de São Paulo e curso Administração na UNESP.

Sou super iniciante no mundo da Tecnologia e o Bootcamp da DIO está sendo minha porta de entrada.

## Conecte-se comigo 🚀
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/agnes-novaes/)