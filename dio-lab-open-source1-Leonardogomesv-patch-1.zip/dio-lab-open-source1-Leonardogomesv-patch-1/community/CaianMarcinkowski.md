<h1 align="center">Hi 👋, I'm Caian Marcinkowski Ferreira</h1>
<h3 align="center">A Back-end and Mobile developer from Brazil</h3>

- 📫 How to reach me **caianferre@gmail.com**

<h3 align="center">Connect with me:</h3>
<p align="center">
<a href="https://stackoverflow.com/users/caian marcinkowski ferreira" target="blank">
  <img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/stack-overflow.svg" alt="caian marcinkowski ferreira" height="30" width="40" />
  </a>
<a href="https://instagram.com/marcinkowski__" target="blank">
  <img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/instagram.svg" alt="marcinkowski__" height="30" width="40" />
  </a>
  <a href="https://www.linkedin.com/in/caian-marcinkowski-ferreira-bb541a137/" target="blank">
    <img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/linked-in-alt.svg" alt="caian marcinkowski ferreira" height="30" width="40" />
  </a>
  <a href="https://discord.gg/Marcinkowski#1807" target="blank">
    <img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/discord.svg" alt="Marcinkowski#1807" height="30" width="40" />
  </a>
</p>

<h3>Languages and Tools:</h3>
<p align="center"> 
  
  <h3>Back-and</h3>
  
  <p align="center"> 
  
  <a href="https://www.java.com" target="_blank" rel="noreferrer"> 
    <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg" alt="java" width="40" height="40"/> 
  </a> 
  
  
  <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank" rel="noreferrer"> 
    <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg" alt="javascript" width="40" height="40"/> 
  </a> 
  
  <a href="https://nodejs.org" target="_blank" rel="noreferrer"> 
    <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/nodejs/nodejs-original-wordmark.svg" alt="nodejs" width="40" height="40"/> 
  </a> 
  
  <a href="https://www.python.org" target="_blank" rel="noreferrer"> 
    <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="40" height="40"/> 
  </a>
  
  </p>
       
  <h3>DB's</h3>
  
  <p align="center"> 
  
  <a href="https://www.mongodb.com/" target="_blank" rel="noreferrer"> 
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mongodb/mongodb-original-wordmark.svg" alt="mongodb" width="40" height="40"/> 
  </a> 
  
  <a href="https://www.mysql.com/" target="_blank" rel="noreferrer"> 
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mysql/mysql-original-wordmark.svg" alt="mysql" width="40" height="40"/> 
  </a> 
  
  <a href="https://www.postgresql.org" target="_blank" rel="noreferrer"> 
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/postgresql/postgresql-original-wordmark.svg" alt="postgresql" width="40" height="40"/> 
  </a> 
  
  </p>     
       
  <h3>Mobile</h3>   
  
  <p align="center"> 
  
  <a href="https://developer.android.com" target="_blank" rel="noreferrer"> 
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/android/android-original-wordmark.svg" alt="android" width="40" height="40"/>     </a> 
  
  <a href="https://www.java.com" target="_blank" rel="noreferrer"> 
    <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg" alt="java" width="40" height="40"/> 
  </a> 
  
  <a href="https://kotlinlang.org/" target="_blank" rel="noreferrer"> 
    <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/kotlin/kotlin-original.svg" alt="kotlin" width="40" height="40"/> 
  </a> 
  
  </p>
  
  <h3>IOT's</h3>
  
  <p align="center"> 
  
  <a href="https://www.arduino.cc/" target="_blank" rel="noreferrer"> 
    <img src="https://cdn.worldvectorlogo.com/logos/arduino-1.svg" alt="arduino" width="40" height="40"/> 
  </a> 
  
  <a href="https://www.cprogramming.com/" target="_blank" rel="noreferrer"> 
    <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/c/c-original.svg" alt="c" width="40" height="40"/> 
  </a> 
  
  </p>
  
  <h3 >Versioning and Testing</h3>
  
  <p align="center"> 
  
  <a href="https://github.com/" target="_blank" rel="noreferrer"> 
    <img src="https://www.vectorlogo.zone/logos/github/github-tile.svg" alt="git" width="40" height="40"/> 
  </a> 
  
  <a href="https://git-scm.com/" target="_blank" rel="noreferrer"> 
    <img src="https://www.vectorlogo.zone/logos/git-scm/git-scm-icon.svg" alt="git" width="40" height="40"/> 
  </a> 
   
  <a href="https://postman.com" target="_blank" rel="noreferrer"> 
    <img src="https://www.vectorlogo.zone/logos/getpostman/getpostman-icon.svg" alt="postman" width="40" height="40"/> 
  </a> 
 
 </p>
 
</p>
<br>
<p align="center" >&nbsp;
  <img height="160em" src="https://github-readme-stats.vercel.app/api?username=CaianMarcinkowski&show_icons=true&locale=en" alt="caianmarcinkowski" />
    <img height="160em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=CaianMarcinkowski&layout=compact&langs_count=7&theme=tokyonight"/>
</p>