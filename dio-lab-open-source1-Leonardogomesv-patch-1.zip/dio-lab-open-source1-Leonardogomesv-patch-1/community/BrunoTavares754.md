# Bruno Tavares

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-FFF?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/bruno-tavares-0651041a8/)

[![Discord](https://img.shields.io/badge/Discord-FFF?style=for-the-badge&logo=discord)](https://www.discord.com/in/tavares1074/)

[![Instagram](https://img.shields.io/badge/Instagram-FFF?style=for-the-badge&logo=instagram)](https://www.instagram.com/brunotavares.20/)


## Habilidades

![C#](https://img.shields.io/badge/C%23-FFF?style=for-the-badge&logo=c-sharp&logoColor=823085)

![Java](https://img.shields.io/badge/Java-FFF?style=for-the-badge&logo=java)


## Github Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=BrunoTavares754&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)


## Minhas contribuições

[![GitHub Streak](https://streak-stats.demolab.com/?user=SEUUSERNAME&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)
