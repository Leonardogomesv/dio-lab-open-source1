# Alessandro Muniz Caranha
Sou um Desenolvedor Front-End, atualmente focado em Angular.

### Hard Skills
![Stacks de Desenvolvimento](https://img.shields.io/badge/Stacks-black)
![Ferramentas](https://img.shields.io/badge/Ferramentas-blue)
![Linguagens de Programação](https://img.shields.io/badge/Linguagens-purple)
![Banco de Dados](https://img.shields.io/badge/Banco-orange)

### Soft Skills
![Trabalho em Equipe](https://img.shields.io/badge/Trabalho-black)
![Pensamento Crítico](https://img.shields.io/badge/Pensamento-blue)
![Gerenciamento do Tempo](https://img.shields.io/badge/Gerenciamento-purple)
![Comunicação](https://img.shields.io/badge/Comunicação-red)
![Liderança](https://img.shields.io/badge/Liderança-green)

### Veja meus perfis
[![DIO](https://img.shields.io/badge/DIO-black?style=for-the-badge&logo=dio)](https://web.dio.me/users/alessandro_muniz)
[![LinkedIn](https://img.shields.io/badge/linkedin-blue?style=for-the-badge&logo=linkedin)](www.linkedin.com/in/alemcar)
[![GitHub](https://img.shields.io/badge/GitHub-purple?style=for-the-badge&logo=github)](https://github.com/Alessandro1979-itac)
[![Instagram](https://img.shields.io/badge/Instagram-blue?style=for-the-badge&logo=instagram)](https://www.instagram.com/alemcar.dev)


### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Alessandro1979-itac&theme=transparent&bg_color=ec63a1&border_color=ec63a1&show_icons=true&icon_color=000&title_color=000&text_color=FFF)