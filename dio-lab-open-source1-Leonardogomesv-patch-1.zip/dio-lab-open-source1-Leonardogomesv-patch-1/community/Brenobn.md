## Hi there, I'm Breno Leonardo 👋

## About

I'm a web developer. And, I'm studying web development.

* Current stack
* Main language: JavaScript
* Backend: NodeJs
* Frontend: HTML5, CSS3, JavaScript
* Layout Design: Figma
* Version code control: Git & Github
* Tools: VsCode, Markdown
I'am mostly active with the DIO Community

## Contacts

email: brenobragabn@gmail.com
Linkedin: https://www.linkedin.com/in/breno-braga-baa951242/
