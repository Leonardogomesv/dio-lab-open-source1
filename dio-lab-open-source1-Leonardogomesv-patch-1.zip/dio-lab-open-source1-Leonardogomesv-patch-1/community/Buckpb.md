## <strong>Buckpb

<p style="color:green"><strong>Iniciante na área de programação.

<p style="color:red"><strong>Onde Me encontrar.


[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/rafael-gon%C3%A7alves-a2326365/) 

[![Facebook](https://img.shields.io/badge/Facebook-000?style=for-the-badge&logo=facebook)](https://www.facebook.com/antoniorafaelgoncalves/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/rafael_buck_bjj/)

## <strong>Habilidades

[![Git](https://img.shields.io/badge/git-000?style=for-the-badge&logo=git)](https://git-scm.com/)

[![Github](https://img.shields.io/badge/github-000?style=for-the-badge&logo=git)](https://github.com/)

##  <strong> Contribuição
[![GitHub Streak](https://streak-stats.demolab.com/?user=Buckpb&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)

## <strong>Repositorios

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Buckpb&repo=dio-curso-git-github&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Buckpb/dio-curso-git-github)

