# Brunno Viotto
Olá,tudo bem? Me chamo Brunno curso Segurança Cibernética e o faço o bootcamp santander.
## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/brunnoviotto/)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/ilbrunnoviotto/)
[![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord)](discordapp.com/users/1085984836600205313)

## Habilidades
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![Cybersecurity](https://img.shields.io/badge/Cybersecurity-000?style=for-the-badge&logo=hackthebox)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=BrunnoViotto&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94DF&text_color=FFF)

## Minhas contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=BrunnoViotto&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E9D5F&text_color=FFF)](https://github.com/Amandasouza332/dio-lab-open-source.git)
