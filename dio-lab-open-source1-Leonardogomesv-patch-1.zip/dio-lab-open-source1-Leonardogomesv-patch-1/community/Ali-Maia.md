<div>
  <h1> 😉Oiii, eu sou Alícia Maia! </h1><br>
  <h2> Neste repositório estão meus projetos pessoais feitos com o intuito de desenvolver minhas habilidades com desenvolvimento Mobile.</h2>
</div>

<div  align="center">
<!--   <img align="right" alt="Rafa-pic" height="150" style="border-radius:50px;" src="https://i.picasion.com/pic92/ced460c44fc5e63567705bfefec57c0c.gif"/> -->
  <br><img height="150" style="border-radius:50px;" src="https://i.picasion.com/pic92/ced460c44fc5e63567705bfefec57c0c.gif"></br>
  <a href = "mailto:aliciaengcomp@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/al%C3%ADcia-maia-088aa123a" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
</div>

## 💻 Tecnologias e ferramentas

<div style="display: inline_block" align="center"><br>
  
  <img align="center" alt="Maia-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Maia-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Maia-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" alt="Maia-Python" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">
  <img src = "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/canva/canva-original.svg" height="30" width='40' align="center" />
  <img src = "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/figma/figma-original.svg" height="30" width='40' align="center" />
  <img src = "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vscode/vscode-original-wordmark.svg" height="30" width='40' align="center" />
  <img src = "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/trello/trello-plain-wordmark.svg"   height="30" width='40' align="center" />
  </br>
</div>
  
  ##

  <div align="center">
  <a href="https://github.com/Ali-Maia">
  <img height="180em" width="42%" src="https://github-readme-stats.vercel.app/api?username=Ali-Maia&show_icons=true&theme=tokyonight&include_all_commits=true&count_private=true"/>
  <img height="180em" width="50%" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Ali-Maia&layout=compact&langs_count=7&theme=tokyonight"/>
</div>
 
<div> 
  
 
  ![Snake animation](https://github.com/Ali-Maia/Ali-Maia/blob/output/github-contribution-grid-snake.svg)
 
</div>
