# About Me (PT/BR)

Olá 👋! Eu sou o André Fernandes. 

Sou desenvolvedor Android mas já tive experiências com iOS e Windows Phone 😅.

Escolhi a área de programação depois de uma palestra sobre sistemas e um quadrinho em específico me inspirou bastante para poder escolher essa carreira. 💻 

## Hobbies

    ⚽ Futebol
    📚 Ler livros
    🎮 Video game
    🍔 Cozinhar/Comer

# Languages & Frameworks

![Android](https://img.shields.io/badge/Android-3DDC84?style=for-the-badge&logo=android&logoColor=white)
![Kotlin](https://img.shields.io/badge/kotlin-%237F52FF.svg?style=for-the-badge&logo=kotlin&logoColor=white)
![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=white)
![iOS](https://img.shields.io/badge/iOS-000000?style=for-the-badge&logo=ios&logoColor=white)
![C#](https://img.shields.io/badge/c%23-%23239120.svg?style=for-the-badge&logo=c-sharp&logoColor=white)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AndreFRSales&layout=compact&bg_color=000&border_color=512DA8&title_color=512DA8&text_color=FFF&hide_title=true)

# Social

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/andrefrsales/)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.linkedin.com/in/andrefrsales/)
[![Medium](https://img.shields.io/badge/Medium-000?style=for-the-badge&logo=medium)](https://medium.com/@andrefernandes.sales)

# Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AndreFRSales&theme=transparent&bg_color=000&border_color=512DA8&show_icons=true&icon_color=536DFE&title_color=512DA8&text_color=FFF&hide_title=true)

[![GitHub Streak](https://streak-stats.demolab.com/?user=AndreFRSales&theme=bear&background=000&border=512DA8&dates=FFF&mode=weekly&fire=536DFE&ring=536DFE&currStreakNum=512DA8&currStreakLabel=536DFE&sideNums=512DA8&sideLabels=536DFE)](https://git.io/streak-stats)