## Meu Perfil

### Sobre

🎯 Analista de suporte técnico (NOC) | CCNA 200-301 em progresso... | Linux | Apaixonado por tecnologia


👨🏽‍💻Eu sou o Caetano e sou apaixonado por tecnologia. Estou atualmente buscando oportunidades na área de computação para aplicar e aprimorar minhas habilidades, ao mesmo tempo em que contribuo para o crescimento e inovação.

🟢 Futura faculdade de Análise e Desenvolvimento de Sistemas 

🟢 Comprometido com a aprendizagem contínua na área

🟢 CCNA em progresso...

🟢 Dedicado a melhorar as habilidades em inglês e fazendo curso privado

🟢 Motivado e aberto a novos desafios

🎯 Se você está procurando por um profissional dedicado, com paixão pela tecnologia, vamos nos conectar e construir o futuro juntos! 

Sinta-se à vontade para entrar em contato comigo por e-mail em (Caetano_silva9177@outlook.com)


<a href="linkedin.com/in/caetano-silva-997b89249" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white"></a> 



### Formações 


 Formação Redes de computadores | Alura 

Linux Fundamentos | Fiap


### Skils 


Internet Protocol Suite (TCP/IP)
Suporte para Help Desk 
Resolução de problemas 
LAN-WAN
Internet Protocol (IP)
Information Technology
Office Administration
Networking
internet
Technical Support
IP VPN
Domain Name System (DNS)