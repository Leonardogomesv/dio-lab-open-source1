# Amanda Maffini
Olá, meu nome é Amanda!

Sou formada em Ciências Contábeis, hoje trabalho na área da educação, nivel superior, e estou entrando em transição de carreira, tentando me encontrar na área da tecnologia.

Logo abaixo está meu Linkedin, sinta-se a vontade para conectar.


## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/amanda-gon%C3%A7alves-nobrega-maffini-4011b414a/)



