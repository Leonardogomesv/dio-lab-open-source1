
# 💎 Bruna Felix 

Bacharel em Administração de Empresas e Iniciante em Desenvolvimento de Sotware. Meu primeiro contato com programção foi com HTML, CSS para construção de sites, mas comecei a me aventurar de fato neste 'novo mundo' com estudos de Java Script e Angular.




## ➔ Solt Skills
Comunicação assertiva, análise crítica, organização e planejamento, resiliente, gestão do tempo, trabalho em equipe, facilidade em aprender.

## ➔ Hard Skills
Treinamento de equipes, Recursos Humanos, Java Script




## 🎯 Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/linkedin-%230077B5.svg?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/bruna-felix-b32005289/)



## Interesses

 - Front end
 - Java Script
 - Angular
 - Python
## GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Bruna81&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

