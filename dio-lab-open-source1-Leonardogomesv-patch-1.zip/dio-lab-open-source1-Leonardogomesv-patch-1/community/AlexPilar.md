# AlexPilar

Olá, meu nome é Alex, tenho 24 anos e este é meu perfil DIO.   

Sou formado em engenharia mecânica pela Universidade Federal do Paraná e já trabalhei com projetos relacionados a modificação de peças em carros.  
  
Há alguns meses ingressei no mundo da análise de dados e, desde então, tenho estudado as principais ferramentas (Power BI, MySQL, Python e Excel). No momento, comecei meu primeiro BootCamp pelo Santander, de análise de dados e estou me aventurando neste mundo da programação.

Gosto de trabalhar em equipe, tenho facilidade em aprender, sou bem proativo e gosto de bater um papo aleatório nas horas livres. Estou disposto a me conectar contigo para que possamos compartilhar conhecimento juntos. Deixo meus contatos abaixo caso queira conversar / se conectar comigo.


## Conecte-se comigo


LinkedIn             |  Discord | GitHub
:-------------------------:|:-------------------------:|:-------------------------:
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0E76A8?style=for-the-badge&logo=linkedin&logoColor=FFFFFF)](https://www.linkedin.com/in/alex-pilar/)  |  [![Discord](https://img.shields.io/badge/Discord-9E1EA8?style=for-the-badge&logo=discord&logoColor=FFFFFF)](discordapp.com/users/alekaolindo) | [![Twitter](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github)](https://github.com/AlexPilar)


## Habilidades
![Python](https://img.shields.io/badge/Python-FFF?style=for-the-badge&logo=python)![MySQL](https://img.shields.io/badge/MySQL-fff?style=for-the-badge&logo=mysql&logoColor=000) ![Power BI](https://img.shields.io/badge/PowerBI-fff?style=for-the-badge&logo=powerbi)  ![Excel](https://img.shields.io/badge/EXCEL-fff?style=for-the-badge&logo=microsoftexcel&logoColor=1D6F42) 