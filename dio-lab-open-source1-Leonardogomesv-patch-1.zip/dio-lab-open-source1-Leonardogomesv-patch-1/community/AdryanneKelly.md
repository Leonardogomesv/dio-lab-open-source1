## Welcome!! :3

- 🔭 **Systems Analyst** in **Orbe Telecom**
- 📚 Graduated - **System Analysis and Development** at Faculdade Tecnológica Lourenço Filho - FLF (Dec 2022).</li>
- 👩🏻‍💻 I have a good knowledge of **PHP, Laravel and MySQL**
- 📚 Currently a graduate student in **Software Engineering** (*Lato sensu*) at Cruzeiro do Sul Virtual
- 🌱 And I'm introducing my studies in **Flutter**

##

### Stats:

<div style="display: inline;">
  <img src="https://github-readme-stats.vercel.app/api?username=AdryanneKelly&show_icons=true&theme=tokyonight" />
  <img width='272em' src="https://github-readme-stats.vercel.app/api/top-langs/?username=AdryanneKelly&langs_count=10&layout=compact&theme=tokyonight" />
</div>

##

### Languages and tools:

| <img width='40' heigth='40' src="https://avatars.githubusercontent.com/u/64450473?s=48&v=4" /> | <img width='40' heigth='40' src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/laravel/laravel-plain-wordmark.svg" /> | <img width='40' heigth='40' src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg" /> | <img width='45' heigth='45' src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/php/php-plain.svg" /> |
| :--------: | :------: | :-------: | :-------------: |
| <img width='40' heigth='40' src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-plain.svg" /> | <img width='40' heigth='40' src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/bootstrap/bootstrap-original.svg" /> | <img width='40' heigth='40' src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg" /> | <img width='40' heigth='40' src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg" /> | 




<!-- <div style="display: inline;">
<img width='45' heigth='45' src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-plain.svg" />
<img width='45' heigth='45' src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg" />
<img width='45' heigth='45' src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg" />
<img width='45' heigth='45' src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/bootstrap/bootstrap-original.svg" />
<img width='45' heigth='45' src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/php/php-plain.svg" />
<img width='45' heigth='45' src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg" />
<img width='45' heigth='45' src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/laravel/laravel-plain-wordmark.svg" />  
</div>
-->

##

### Profiles:

If you want to contact me, my social networks are here

<a href="https://www.linkedin.com/in/adryanne-kelly/"><img src="https://img.shields.io/badge/linkedin-%230077B5.svg?style=for-the-badge&logo=linkedin&logoColor=white"/></a>
<a href="https://www.instagram.com/drysilva____/"><img src="https://img.shields.io/badge/Instagram-%23E4405F.svg?style=for-the-badge&logo=Instagram&logoColor=white"/></a>

