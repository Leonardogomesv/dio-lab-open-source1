# Olá! Eu sou Geison Bonaud 🫶

## Conecte-se comigo.
[![Linkedin](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/geison-bonaud-8173b8231/)
[![twitter](https://img.shields.io/badge/Twitter-1DA1F2?style=for-the-badge&logo=twitter&logoColor=white)](https://twitter.com/GBonaud)
[![twitter](https://img.shields.io/badge/Discord-7289DA?style=for-the-badge&logo=discord&logoColor=white)](https://discord.gg/3JMV4xEvG8)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/Bonand13/)


## Hard Skill

<div style ="display: inline_block"><br/>
 <img aling ="center" alt="html5" src="https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python"/>
 <img aling ="center" alt="html5" src="https://img.shields.io/badge/MySQL-00000F?style=for-the-badge&logo=mysql&logoColor=white"/>
 <img aling ="center" alt="html5" src="https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5"/>
 <img aling ="center" alt="html5" src="https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4"/>
</div><br/>

## GitHub Stats
![Bonaud13 GitHub stats](https://github-readme-stats.vercel.app/api?username=Bonaud13&show_icons=true&theme=radical)

Apaixonado por tecnologia, a educação e por mudar a vida das pessoas com a programação.
