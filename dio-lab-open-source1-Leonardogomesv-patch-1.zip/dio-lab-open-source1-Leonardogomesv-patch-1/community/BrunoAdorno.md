# Bruno Adorno Araujo

Olá, 

Atualmente estou estudando o segundo semestre em ciência da computação, estou focando meus estudos em Python, para explorar as fronteiras que ainda tenho pela frente.

Estou comprometido com meu desenvolvimento, realizando cursos, projetos pessoais para estar sempre por dentro das novidades.

## Conecte-se comigo

[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-000?style=for-the-badge)](https://web.dio.me/users/brunoa_dorno88?tab=skills) 
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=fff)](https://www.linkedin.com/in/bruno-a-171890206/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=fff)](https://github.com/BrunoAdorno)

## **📊 GitHub Stats**

<div align="center">

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=BrunoAdorno&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Habilidades

### <img src="https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white" alt="Python" style="zoom:150%;" />

### <img src="https://img.shields.io/badge/html5-E34F26.svg?style=for-the-badge&logo=html5&logoColor=white" alt="HTML5" style="zoom:150%;" /> 

#### <img src="https://img.shields.io/badge/css3-1572B6.svg?style=for-the-badge&logo=css3&logoColor=white" alt="CSS3" style="zoom:150%;" />  

### <img src="https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript" alt="JavaScript" style="zoom:150%;" /> 
