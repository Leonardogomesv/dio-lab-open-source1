# Desafio: Profile README - DIO Ifood

Contribua no diretório "Community", criando um Profile README.




## 🚀 Sobre mim
Atualmente estou cursando administração EAD e busco desenvolver habilidades tecnica. Possuo experiência em áreas como varejo, atacado e instituição financeira, tendo atuado em atendimento ao cliente, venda e pós-venda, suporte à equipe e cliente, diversas rotinas administrativas pertinentes aos cargos.

## Perfil Profissional
Angelo Cecilio M. L
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/angelocecilio/)

[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=007BFF)](mailto:angelocecilio@hotmail.com)

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Angelo-Cecilio&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)




## Contribuindo

[![GitHub Streak](https://streak-stats.demolab.com/?user=Angelo-Cecilio&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)
## 🛠 Habilidades
Excel, Power BI, Analise de dados.
