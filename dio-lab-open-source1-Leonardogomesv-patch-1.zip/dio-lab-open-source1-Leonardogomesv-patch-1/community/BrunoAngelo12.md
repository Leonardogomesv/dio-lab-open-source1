# Hi there 👋🏻, Welcome!
![img](https://i.imgur.com/a1pyWHP.png)

Olá! Meu nome é Bruno, sou noivo, cristão e tenho 25 anos, atualmente estou cursando o Santander Bootcamp 2023 - Backend Java. ☕♨️

Tenho uma grande paixão na linguagem desde que a conheci no primeiro Bootcamp que realizei o Programador de Software Iniciante em 2021, e desde lá venho me aprimorando na área realizando cursos EAD. ☕💓

Atualmente sou auxiliar adminstrativo na área de logística e anseio muito migrar minha área profissional. 🧑‍💻

Gosto muito de jogar tanto em console como em PC, assistir filmes/séries/desenhos, amante da natureza e pai de dois pets, um gato (Harry) e uma cachorra (Jully).🎮

## Vamos Conectar

[![LinkedIn](https://img.shields.io/badge/LinkedIn-059?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/bruno-angelo-089a62243/)

[![Instagram](https://img.shields.io/badge/Instagram-059?style=for-the-badge&logo=instagram)](https://www.instagram.com/filhododono_12)

[![GitHub](https://img.shields.io/badge/github-059?style=for-the-badge&logo=github)](https://github.com/BrunoAngelo12)

[![dio](https://img.shields.io/badge/perfil_dio-059?style=for-the-badge&logo=dio)](https://www.dio.me/users/bruno_trabalhos)
[![dio](https://lp.dio.me/wp-content/uploads/2023/04/diologo.png)](https://www.dio.me/users/bruno_trabalhos)

## Habilidades
![Java](https://img.shields.io/badge/Java-059?style=for-the-badge&logo=java)

![git](https://img.shields.io/badge/git-059?style=for-the-badge&logo=git)

![git](https://img.shields.io/badge/github-059?style=for-the-badge&logo=github)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=BrunoAngelo12&bg_color=059&border_color=000&title_color=FFF&text_color=FFF)

## GitHub Status

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=BrunoAngelo12&theme=transparent&bg_color=059&border_color=000C&show_icons=true&icon_color=000&title_color=FFF&text_color=FFF)

## Principais Projetos
[![jogoDaVelha](https://img.shields.io/badge/Jogo_da_velha_-059?style=for-the-badge&logo=java)](https://github.com/BrunoAngelo12/jogodavelha)