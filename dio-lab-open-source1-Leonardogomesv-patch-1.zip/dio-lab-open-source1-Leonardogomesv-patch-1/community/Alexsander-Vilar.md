# Alexsander Vilar Pereira

Atualmente, estou no processo de transição de carreira. Iniciei no curso de análise e desenvolvimento de sistemas e estou em busca de oportunidades de iniciar como desenvolvedor. 

# Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-fff?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/alexsander-vilar-pereira-a5173b131/) [![DIO](https://img.shields.io/badge/Meu_perfil_na_DIO-fff?style=for-the-badge)](https://www.dio.me/users/alexandervilar) [![gmail](https://img.shields.io/badge/email-fff?style=for-the-badge&logo=gmail&logoColor=00)](https://mail.google.com/mail/u/0/?fs=1&tf=cm&source=mailto&to=alexsandervilar@gmail.com) 



# Habilidades

![Java](https://img.shields.io/badge/Java-fff?style=for-the-badge&logo=java) ![SpringBoot](https://img.shields.io/badge/SpringBoot-fff?style=for-the-badge&logo=SpringBoot)  ![MySQL](https://img.shields.io/badge/Mysql-fff?style=for-the-badge&logo=Mysql) ![Postgresql](https://img.shields.io/badge/Postgresql-fff?style=for-the-badge&logo=Postgresql)  ![Git](https://img.shields.io/badge/Git-fff?style=for-the-badge&logo=Git)  ![GitHub](https://img.shields.io/badge/GitHub-fff?style=for-the-badge&logo=GitHub)



# GitHub Status

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Alexsander-Vilar&theme=transparent&bg_color=fff&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=000)![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Alexsander-Vilar&bg_color=fff&border_color=30A3DC&title_color=E94D5F&text_color=000)



# Meus Principais Projetos

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Alexsander-Vilar&repo=aula-de-spring-boot-api-michelli-brito-parking-control&bg_color=fff&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=000)](https://github.com/Alexsander-Vilar/aula-de-spring-boot-api-michelli-brito-parking-control) 

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Alexsander-Vilar&repo=spring-boot-2-essentials&bg_color=fff&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=000)](https://github.com/Alexsander-Vilar/spring-boot-2-essentials)