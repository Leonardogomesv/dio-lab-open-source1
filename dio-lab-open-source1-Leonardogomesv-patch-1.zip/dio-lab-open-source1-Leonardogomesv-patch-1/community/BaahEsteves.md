# BaahEsteves 
Olá, meu nome é Bárbara, estou em transição de carreira para a área de tecnologia e estou aqui na DIO em busca de aprendizado e conhecimento. Atualmente estou cursando Informática para Negócios.

## Conecte-se Comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/barbaraestevess/)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=BaahEsteves&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)