<div>

  <h1 align="center">
    Oi Tudo bem? Eu sou o 
    <a href="https://www.linkedin.com/in/caio-henrique-8619a2232/">Caio Henrique 😃️</a>
  </h1>

  <p align="center">
    Sou Desenvolvedor Front End, procurando sempre expandir meus conhecimentos a cada dia
  </p>

</div>

<div align="center">
  <a href="https://github.com/CaioSiqueira01">
    <img height="150em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=CaioSiqueira01&theme=dracula&hide_border=false&&layout=compact"/>
  </a>
</div>

<div align="center" valign="top"><br>
  <img align="center" alt="React" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original.svg">
  <img align="center" alt="Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Ts" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/typescript/typescript-plain.svg">
  <img align="center" alt="HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" alt="nodejs" height="30" width="40" src="https://cdn.worldvectorlogo.com/logos/nodejs-icon.svg">
</div><br>

<div align="center">
  <a href="https://www.instagram.com/rs_caio/" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/caio-henrique-8619a2232/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
  <a href="mailto:caiohenriquessiqueira.caike@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
</div>

<div align="center">
  <p>Feito com :heart: e JavaScript.</p>
</div>


