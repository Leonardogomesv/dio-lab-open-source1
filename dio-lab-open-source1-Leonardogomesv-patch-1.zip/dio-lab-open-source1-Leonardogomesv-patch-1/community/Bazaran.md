### Hello Word
Sou estudante de Ciência da Computação, atualmente estou no 4° semestre,com habilidades em C,Python,banco de dados.
Curioso em CyberSecurity.
## Link 🔗
[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/joão-carlos-847a0b1a8/)

## 🛠 Habilidades
C,Python, HTML, CSS, MYSQL ...
