# Olá! 👋🏻

Bem-vindo(a) ao meu perfil no GitHub! :octocat:

Fico feliz em compartilhar um pouco mais sobre mim e minhas atividades por aqui. Explore meu trabalho e descubra mais sobre meus projetos e contribuições! :mag:

# Sobre mim

- 📍 Resido em Cabo Frio, no estado do Rio de Janeiro;
- 🎓 Atualmente, estou cursando Tecnologia em Ciência de Dados na UNINTER;
- 💡 Após descobrir a área de dados, percebi meu objetivo profissional e desde então tenho me dedicado a resolver problemas de negócios utilizando visualização de dados, algoritmos de machine learning e estatística;
- 🌟 Meu principal objetivo é aplicar meus conhecimentos na área de dados, de forma orientada por dados (data driven), para solucionar desafios empresariais, especialmente nas áreas de Análise de Dados e Ciência de Dados.

# Contatos

Fique à vontade para entrar em contato, seja pra tirar dúvidas ou dar sugestões. Estou sempre disponível para ajudar!

| 📬 Email: cesar.jcm@outlook.com

| 🔗 [LinkedIn](https://www.linkedin.com/in/caesar-duarte/)

| ✍🏻 [Medium](https://caesarduarte.medium.com/)

| 💼 [Portfólio (Em construção)](https://caesarduarte.github.io/projects-portfolio/)

