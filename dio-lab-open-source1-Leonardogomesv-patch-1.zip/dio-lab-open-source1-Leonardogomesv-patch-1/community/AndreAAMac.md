# Ola 

Meu nome é André, estou curso Sistemas de informação na UEMG, sou de Minas Gerias, estou migrando para o desenvolvimento mobile.

Teste.