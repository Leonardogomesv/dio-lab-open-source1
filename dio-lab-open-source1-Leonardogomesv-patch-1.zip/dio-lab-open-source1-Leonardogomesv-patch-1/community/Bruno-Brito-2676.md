Meu nome é Bruno, tenho 23 anos, atualmente trabalho como QA na mesa do pix do Santander!
Estou em migração de carreira e pretendo me tornar dev BackEnd

![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/bruno-brito-9a1427223/)
[![WhatsApp](https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/https://wa.me/+5511969952751)