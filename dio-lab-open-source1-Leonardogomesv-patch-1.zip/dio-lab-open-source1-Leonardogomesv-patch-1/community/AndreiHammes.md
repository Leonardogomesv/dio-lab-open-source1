
<h1 align="center">
  <img src="https://media.giphy.com/media/vGWZEktceb6HS/giphy.gif" width="30">
 Olá, meu nome é Andrei Hammes e esta é minha contribuição ao projeto! <img src="https://media.giphy.com/media/vGWZEktceb6HS/giphy.gif" width="30">
</h1>


<div align="center">
  
  <img height="150em" src="https://github-readme-stats-sigma-five.vercel.app/api?username=andreihammes&show_icons=true&theme=midnight-purple&include_all_commits=true&count_private=true"/>
  <img height="150em" src="https://github-readme-stats-sigma-five.vercel.app/api/top-langs/?username=andreihammes&theme=midnight-purple&hide_border=false&&layout=compact"/>
</div>


<h1 align="center">
  <img src="https://media.giphy.com/media/mPJZA10THoWoTbW8uV/giphy.gif" width="30">
  Melhores Tecnologias
  <img src="https://media.giphy.com/media/mPJZA10THoWoTbW8uV/giphy.gif" width="30">
</h1>

<div  align="center"> 
  <div style="display: inline_block"><br>
    <img align="center" height="40" width="50" alt="html-icon" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
    <img align="center" height="40" width="50" alt="css-icon" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
    <img align="center" height="40" width="50" alt="js-icon"  src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
    <img align ="center" height="40" width="50" alt="figma-icon" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/figma/figma-original.svg" />
    <img align="center" alt="Dart-icon" height="40" width="50"  src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/dart/dart-original.svg">
    <img align="center" alt="Dart-icon" height="40" width="50" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-original.svg" />  
   </div>

<br>

  <img src="https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExbjlkOXZjczl1Z2c0cmdxdXg0bHFmdW9tYnlqd2hycXV2Ynd1c3ZleCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9cw/WFZvB7VIXBgiz3oDXE/giphy.gif" width="80">

  

  





