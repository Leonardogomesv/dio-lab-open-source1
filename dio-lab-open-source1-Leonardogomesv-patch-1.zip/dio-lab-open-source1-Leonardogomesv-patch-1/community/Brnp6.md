# Meu nome é Bruno :rocket:
Tenho 26 anos, carioca apaixonado por tecnologia e inovação. Buscando se desenvolver para ser um profissional acima da 
média.

##  Tecnologias & Ferramentas  que estou Aprendendo 🛠️
![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![C++](https://img.shields.io/badge/C%2B%2B-000?style=for-the-badge&logo=c%2B%2B&logoColor=00599C)

## Aprendizado na plataforma (em desenvolvimento) :bookmark_tabs:
![Anurag's GitHub stats](https://github-readme-stats.vercel.app/api?username=Brnp6&theme=dark_icons=true)
## Contribuições :two_men_holding_hands:
 [![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Brnp6&repo=dio-lab-openb&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/SEUUSERNAME/SEUREPOSITORIO)

 ## Fale comigo :telephone_receiver:

 [![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/brunofelipepinheiro)
