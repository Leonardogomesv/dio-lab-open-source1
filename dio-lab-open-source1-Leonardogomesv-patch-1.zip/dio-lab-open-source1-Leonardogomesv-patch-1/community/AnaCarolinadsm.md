## Ana Carolina da Silva Mendes

### Olá, meu nome é Ana, tenho 24 e atualmente estou estudando JAVA. Tenho experiência com desenvolvimento web com a linguagem PHP, que desenvolvi no meu curso técnico em Informática, onde me apaixonei por progrmação.


**HABILIDADES**
|Nível: Básico|
|--------------|
|JAVA|
|JavaScript|
|Git|
|GitHub|

|Nível: Avançado|
|--------------|
|HTML|
|CSS|
|SQL|
|PHP|

