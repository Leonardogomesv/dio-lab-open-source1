# Gilmara Sousa  

Estou tentando migrar para área de dev bem como jogos, trabalho com TI porém voltado ao suporte à usuário e infraestrutura.
## ヾ(⌐■_■)ノ♪ Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue?style=for-the-badge&logo=linkedin&logoColor=fff)](https://www.linkedin.com/in/gilmara-sousa-754618133/)

[![LinkedIn](https://img.shields.io/badge/MEU_PERFIL_NA_DIO-blue?style=for-the-badge&logo=Dio&logoColor=0E76A8)](https://www.dio.me/users/sousagil/)

## Habilidades que estou aprendendo

| Em aprendizado | Links úteis |
|-------|---------|
C# - Unity | [Unity](https://unity.com/pt)
Git | [Git](https://git-scm.com/)
GitHub | [GitHub](https://github.com/)

## Caderno de estudos

Caso queiram olhar meu caderno de estudos que fiz com o bootcamp.

**Precisa ter conta no Notion :D**  

[![LinkedIn](https://img.shields.io/badge/CADERNO_DE_ESTUDOS-blue?style=for-the-badge&logo=Dio&logoColor=0E76A8)](https://www.notion.so/gil-dio/Caderno-de-Estudos-fac3653c7c724b3a86d80547c8025999?pvs=4)