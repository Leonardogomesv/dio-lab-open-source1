# AndrieleLange
Olá! Eu sou a Andriele. Sou estudante de Ciências da Computação e do Santander Bootcamp 2023 - Mobile Android com Kotlin.

## Conecte-se Comigo
[![LinkedIn](https://img.shields.io/badge/LinkedInd-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/andriele-barc%C3%A9-lange-83923715a/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=Github&logoColor=0E76A8)](https://github.com/AndrieleLange)

## Habilidades 
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)
