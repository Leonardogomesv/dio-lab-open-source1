# Arthur Gilberti Leite

## Olá, estou adicioando novos conhecimentos para meu curriculo e quem sabe seguir nessa area.

## Conecte-se comigo.
[![Static Badge](https://img.shields.io/badge/Digital_Innovation_One-badge?color=black)](https://web.dio.me/users/arthurgileite)
[![GitHub](https://img.shields.io/badge/GitHub-bagde?color=black)](https://github.com/ArthurGilbert)

## Habilidades

[![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python&logoColor=fff)](https://docs.python.org/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=fff)](https://docs.github.com/pt)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=fff)](https://git-scm.com/doc)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
