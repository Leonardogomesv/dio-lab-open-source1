# Hello, world! Its me Paola Borely!
### Pronta para os desafios!
<img src="https://i.ibb.co/428wxbK/Design-sem-nome.gif" alt="Design-sem-nome" border="0" height="128" width="128">

## ✨ Sobre mim

Formada em marketing e marketing digital & data science, decidi migrar de área durante asegunda graduação.
Abaixo estão listados os conhecimentos que tenho aprimorado até o momento

⭐ *Ciência de dados*

     🔹 Python
     🔹 SQL
     🔹 R
⭐ *Análise de dados*

    🔹Power BI
    🔹Excel


## 🔗 Links

[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/paolajoliveira/)