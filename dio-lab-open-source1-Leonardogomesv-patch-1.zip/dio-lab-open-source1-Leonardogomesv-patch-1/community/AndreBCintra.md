### Name:

# André Brizzante Cintra
## 🚀 About me
I'm a new developer, currently studying computer science at Universidade Federal do Ceará and looking forward to improve and develop skills.
I like technology, games and manga.


## 🛠 Hard Skills
![Java](https://img.shields.io/badge/Java-red)
![Python](https://img.shields.io/badge/Python-darkblue)

## 💡 Soft Skills

![Proactive](https://img.shields.io/badge/Proactive-blue)
![Organized](https://img.shields.io/badge/Organized-red)
![Empathetic](https://img.shields.io/badge/Empathetic-gree)

## 🔗 Links
[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/andre-b-cintra/)

