# Assis Junior
<code><img style="
border-radius: 5px" height="150" src="https://avatars.githubusercontent.com/u/62892419?v=4" alt="Javascript"/></code>
<br>
Hi, i am <strong>Assis Júnior!</strong>
I am 34 years old, I work for more than 10 years in the commercial sector as an Office Assistant, I am in the process of transitioning from career to Technology area, I am currently a FullStack Web Developer in training by <a href="https://www.growdev.com.br" target="_blank">Growdev</a>, student of the 9th Edition of the Starter Program.<br>

### 🚀 Hard Skills
<code><img height="32" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/javascript/javascript.png" alt="Javascript"/></code>
<code><img height="32" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/nodejs/nodejs.png" alt="Nodejs"/></code>
<code><img height="32" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/html/html.png" alt="HTML5"/></code>
<code><img height="32" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/css/css.png" alt="CSS"/></code>
<code><img height="32" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/bootstrap/bootstrap.png" alt="Bootstrap"/></code>
<code><img height="32" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/react/react.png" alt="React"/></code>
<code><img height="32" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/mysql/mysql.png" alt="MySQL"/></code>
</code><br>

### ⭐ Soft Skills
![Communicative](https://img.shields.io/badge/Communicative-red)
![Proactive](https://img.shields.io/badge/Proactive-blue)
![Organized](https://img.shields.io/badge/Organized-red)
![Empathetic](https://img.shields.io/badge/Empathetic-blue)

### Social Media
[![Perfil DIO](https://img.shields.io/badge/DIO/PERFIL-darkblue)](https://web.dio.me/users/assisjuniorcam)
[![LINKDIN](https://img.shields.io/badge/Linkdin-blue)](https://www.linkedin.com/in/assis-junior/)
[![GitHub](https://img.shields.io/badge/GitHub-black)](https://github.com/AssFerj)

### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AssFerj&theme=transparent&bg_color=013&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AssFerj&layout=compact&bg_color=013&border_color=30A3DC&title_color=E94D5F&text_color=FFF)