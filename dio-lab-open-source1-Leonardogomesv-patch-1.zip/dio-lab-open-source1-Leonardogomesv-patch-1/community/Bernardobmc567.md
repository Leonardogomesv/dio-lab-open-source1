# Bernardobmc567

Olá! Sou estudante de programação e quero ser um futuro desenvolvedor de jogos.

## Conecte-se comigo

[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=GitHub&logoColor=0E76A8)](https://github.com/Bernardobmc567)

## Habilidades
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=white)](https://docs.github.com/)

[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=white)](https://git-scm.com/doc)


![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Bernardobmc567&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Minhas Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Bernardobmc567&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Bernardobmc567/dio-lab-open-source)