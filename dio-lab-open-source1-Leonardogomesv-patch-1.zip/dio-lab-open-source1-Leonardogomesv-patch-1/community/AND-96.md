<img src="https://raw.githubusercontent.com/MicaelliMedeiros/micaellimedeiros/master/image/computer-illustration.png" min-width="400px" max-width="400px" width="400px" align="right">

```js
import Desenvolvedor from "AND-96";

class SobreMim extends Desenvolvedor {
  nome = "Andreza";
  area = "Backend";
  local = "São Paulo";
}

class Skills extends Desenvolvedor {
  linguagens = ["HTML5", "CSS3", "JavaScript", "Java"];
  frameworks = ["Angular", "Spring"];
  bibliotecas = ["MySQL", "MongoDB"];
}
```