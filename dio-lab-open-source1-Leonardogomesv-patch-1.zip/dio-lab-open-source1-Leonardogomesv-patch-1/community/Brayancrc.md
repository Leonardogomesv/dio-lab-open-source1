### Olá! Eu sou o Brayan Robson 👋
- 🔭 Um desenvolvedor .Net & MuleSoft apaixonado por integração de sistemas e resolução de problemas complexos. Minha abordagem orientada a soluções me permite analisar requisitos complexos, identificar oportunidades de otimização e propor soluções inovadoras. Tenho facilidade em aprender novas tecnologias e estou sempre em busca de atualizações para aprimorar minhas habilidades técnicas.

- 🌱 Estudando também inglês e espanhol 

<div align="center">
  <a href="https://github.com/Brayancrc">
  <img height="170em" src="https://github-readme-stats.vercel.app/api?username=Brayancrc&show_icons=true&theme=dark&include_all_commits=true&count_private=true"/><img height="170em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Brayancrc&layout=compact&langs_count=7&theme=dark"/>
</div>
  
   ##

<div style="display: inline_block" align="center"><br>
  <img align="center" alt="Azure" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/azure/azure-original-wordmark.svg">
  <img align="center" alt="SQL" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/microsoftsqlserver/microsoftsqlserver-plain-wordmark.svg">
  <img align="center" alt="VSCode" height="40" width="50" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vscode/vscode-original.svg">
  <img align="center" alt="C#" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/csharp/csharp-original.svg">
  <img align="center" alt=".Net" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/dot-net/dot-net-original-wordmark.svg">
  <img align="center" alt="NetCore" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/dotnetcore/dotnetcore-original.svg">
  <img align="center" alt="Salesforce" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/salesforce/salesforce-original.svg">
  
</div>
  
   ##

  <div align="center">
      <a href = "mailto:brayancrc@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/brayan-robson-09329b111/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>
  <a href="https://instagram.com/brayancrc" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
 
 
  </div>
