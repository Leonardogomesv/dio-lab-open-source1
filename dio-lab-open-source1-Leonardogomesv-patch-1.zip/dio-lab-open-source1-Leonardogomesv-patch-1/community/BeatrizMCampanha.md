
# Beatriz Campanhã

Olá, me chamo Beatriz. 

## Conecte-se comigo

- [![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com)
- 	[![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord)](https://https://discord.com/)
-   [![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=007BFF)]()


## Habilidades
![Linux](https://img.shields.io/badge/Linux-000?style=for-the-badge&logo=linux&logoColor=FCC624) ![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript) ![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python) 	![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5) ![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)


## GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=BeatrizMCampanha&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FF&hide_title=true&hide=stars)

## Minhas Contribuições

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=BeatrizMCampanha&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/BeatrizMCampanha/dio-lab-open-source)


