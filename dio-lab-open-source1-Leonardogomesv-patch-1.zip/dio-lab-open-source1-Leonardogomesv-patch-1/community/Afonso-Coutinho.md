# Olá! Eu sou Afonso Coutinho ✌️

- 📖 Cursando Engenharia da Computação
- 👨‍💻 Apaixonado por front-end e Mobile
- 😄 Pronomes: ele/dele

[![Anurag's GitHub stats](https://github-readme-stats.vercel.app/api?username=Afonso-Coutinho&show_icons=true&theme=transparent)](https://github.com/anuraghazra/github-readme-stats)

[![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=Afonso-Coutinho&layout=donut)](https://github.com/anuraghazra/github-readme-stats)

## Conecte-se Comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/afonso-coutinho/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/hen_rique.afonso/)