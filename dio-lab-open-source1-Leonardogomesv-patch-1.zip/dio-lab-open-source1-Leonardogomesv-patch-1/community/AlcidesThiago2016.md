### Olá! Eu sou Alcides Thiago 👋

- 🔭 Atualmente trabalho na área de infra em Administração de Redes, estou iniciando minha carreira em programação, sou amante da linguaguem Java e venho estudando a uns 2 anos, fiz alguns cursos de Python e recentemente conclui o curso de Cobol.

- 👨‍💻 CERTIFICAÇÕES CONCLUIDAS:

- 🌱 Bootcamp da Spread Java Developer na Digital Innovation One Concluido em 2022.
- 🌱 Santander Bootcamp Fullstack Developer na Digital Innovation Concluido em 2022.
- 🌱 Bootcamp Banco PAN Java Developer na Digital Innovation Concluido em 2023.

- 👨‍💻 CERTIFICAÇÕES EM ANDAMENTO:

- 🌱 Curso Desenvolvedor Moderno - Escola DevSuperior(Nélio Alves).
- 🌱 Curso Avançado de Inglês - Cilc(Presencial).
- 🌱 Santander Bootcamp 2023 - Fullstack Java+Angular

- 📫 Contate-me no email : alcides_thiago@hotmail.com
- 😄 Pronouns: ele/dele
 <div>
  <a href="https://github.com/AlcidesThiago2016">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=alcidesthiago2016&show_icons=true&theme=dark&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=alcidesthiago2016&layout=compact&langs_count=7&theme=dark"/>
</div>

##

  <div style="display: inline_block"><br>
  <img align="center" alt="Alcides-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Alcides-Spring" height="30" width="40" src="https://github.com/devicons/devicon/blob/master/icons/spring/spring-original.svg">
  <img align="center" alt="Alcides-React" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original.svg">
  <img align="center" alt="Alcides-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Alcides-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" alt="Alcides-Python" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">
  <img align="center" alt="Alcides-Java" height="30" width="40" src="https://github.com/devicons/devicon/blob/master/icons/java/java-original.svg">   
  <img align="center" alt="Alcides-Angular" height="30" width="40" src="https://github.com/devicons/devicon/blob/master/icons/angularjs/angularjs-original.svg">   
  <img align="center" alt="Alcides-Ubuntu" height="30" width="40" src="https://github.com/devicons/devicon/blob/master/icons/ubuntu/ubuntu-plain.svg">
</div>

##

<div> 
  <a href="https://instagram.com/wilismarthiago" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
 <a href="https://discord.gg/" target="_blank"><img src="https://img.shields.io/badge/Discord-7289DA?style=for-the-badge&logo=discord&logoColor=white" target="_blank"></a> 
  <a href = "mailto:alcides_thiago@hotmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/alcides-thiago-9939b88a/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 

</div>
