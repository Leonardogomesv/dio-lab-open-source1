<h1 align="center">Olá, Mundo!</h1>


<div align="center"> 

[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Jetbrains+Mono&size=30&duration=2000&pause=1000&center=true&color=ff0089&width=700&lines=Oi%2C+eu+sou+a+Annie;Desenvolvedora+Front-End;Estudante+de+Back-End%2C+Unity+e+Mobile)](https://git.io/typing-svg) 


![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AnnieAlves&bg_color=130017&border_color=d442f5&title_color=c800ff&text_color=ff0073)


</div>
  
  
  

<h2 align="center">Sobre mim</h2>

  

* Autista e TDAH

* 29 anos

* Meu primeiro contato com a programação foi com a linguagem C#, usada para games com Unity. Desde então me dediquei a estudar outras linguagens e tecnologias.

* Atualmente curso ADS pela Faculdade São Francisco de Assis.

  
  
  

<h2 align="center">Tecnologias</h2>

  

<div align="center">

  

<img  height="45"  src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/csharp/csharp-plain.svg"  />

<img  height="45"  src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-plain.svg"  />

<img  height="45"  src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-plain.svg"  />

<img  height="45"  src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-plain.svg"  />

<img  height="45"  src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/unity/unity-original.svg"  />

### Atualmente estudando:

  

<div>

<img  height="45"  src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/kotlin/kotlin-original.svg"  />

<img  height="45"  src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/android/android-original.svg"  />

<img  height="45"  src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg"  />

<img  height="45"  src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/django/django-plain.svg"  />

</div>
</div>

<h2 align="center">Contato</h2>


<div align="center"> 

[![Static Badge](https://img.shields.io/badge/Meu%20portf%C3%B3lio-purple)](https://anniealves.github.io/)

[![Github](https://img.shields.io/badge/Github-357?style=for-the-badge&logo=Github&logoColor=fffff)](https://www.github.com/AnnieAlves)

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/annie-alves/)

[![GMail](https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white)](mailto:annie.a.alves@gmail.com)

</div>
