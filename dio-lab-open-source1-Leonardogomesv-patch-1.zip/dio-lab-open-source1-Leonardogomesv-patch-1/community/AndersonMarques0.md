# Anderson da Silva Marques

Estou atualmente cursando Engenharia da Computação e descobri que gosto da área de programação. Meu objetivo é me tornar um desenvolvedor Android.

### Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/anderson_09marquez/)
[![E-mail](https://img.shields.io/badge/-Email-FFF?style=for-the-badge&logo=gmail)](mailto:anderson.silvamarques00@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-FFF?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/anderson-da-silva-marques/)

### Habilidades
[![Git](https://img.shields.io/badge/Git-FFF?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc) 
[![GitHub](https://img.shields.io/badge/GitHub-FFF?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)
![Kotlin](https://img.shields.io/badge/kotlin-FFF?style=for-the-badge&logo=kotlin)
![C++](https://img.shields.io/badge/C++-FFF?style=for-the-badge&logo=cplusplus&logoColor=30A3DC)

### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AndersonMarques0&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AndersonMarques0&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)