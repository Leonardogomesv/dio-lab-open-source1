<p align="center">
<img src="https://readme-typing-svg.herokuapp.com?font=Lucida+Sans&size=30&duration=8000&pause=3000&color=EAC006&background=4523FF00&center=true&vCenter=true&width=500&lines=Welcome+To+My+Profile+🖖🏾">


<h1>
     <img align="center" alt="Logo André Pinheiro" width="36px" src="https://media.discordapp.net/attachments/1159596741277008025/1159597153367367831/LOGO_AP.png?ex=65319a01&is=651f2501&hm=f7a7b88711b44166d9f20cd9387731de438624d1cdcf9a740c66645014acb52e&="></a>
    <span>André Pinheiro</span>
</h1>

<p align="justify">Front-end developer from Recife-PE, Brazil, Graduated in systems analysis and development. My first “Hello World” was when I came into contact with HTML, CSS and JavaScript.
<br>
 Passionate about technology and enthusiastic about nerd culture, some of my hobbies are gaming, watching, sports and going to the gym.

<h3 align="justify">Connect with me</h3>

[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=eac006&color:05070e)](https://www.linkedin.com/in/andrepinheiroo/)
[![Instagram](https://img.shields.io/badge/-Instagram-000?style=for-the-badge&logo=instagram&logoColor=eac006&color:05070e)](https://www.instagram.com/andre_pinheirooo/)

<div style="display: inline_block"><br>
  <img align="center" alt="Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Ts" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/typescript/typescript-plain.svg">
  <img align="center" alt="React" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original.svg">
  <img align="center" alt="HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">

</div>

<h3 align="justify">GitHub Stats</h3>

![GitHub stats](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api?username=Andrepinheiroo&hide_title=true&show_icons=true&include_all_commits=false&count_private=true&line_height=25&hide=issues&bg_color=05070e&title_color=eac006&text_color=FFF&border_radius=3&border_color=eac006&icon_color=eac006&theme=jolly)

###

![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=Andrepinheiroo&title_color=eac006&text_color=FFF&border_radius=3&border_color=eac006&icon_color=eac006&bg_color=05070e)
<br>

