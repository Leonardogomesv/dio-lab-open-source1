# Olá, pessoal! Sou [Anbuyyy9](https://github.com/Anbuyyy9), apaixonado pela tecnologia.

- 👨‍💻👨‍💻 Atuei como Analista de TI

- 🔥 Atualmente, estou mergulhando de cabeça no universo da programação:
  - Dominando **Python**
  - Explorando o mundo do **Front-end**
  - Iniciando minha jornada com **Java**

- 💻 Mas, o que realmente me empolga é a segurança da informação. Estou trilhando o caminho do pentest e do hacking ético, explorando ferramentas como:
  - **Nmap**
  - **BurpSuite**
  - Técnicas avançadas de **Web Hacking**

- 🕵️ Também sou um mestre em **OSINT** (Open-Source Intelligence), onde me sinto como um detetive digital à la Sherlock Holmes.

- 📱 Além disso, aplico minhas habilidades para análise de vulnerabilidades em dispositivos móveis.

[![LinkedIn](https://logosmarcas.net/wp-content/uploads/2020/04/Linkedin-Logo.png)](https://www.linkedin.com/in/gabriel-anthony-ab92211b5/)
