[![Typing SVG](https://readme-typing-svg.herokuapp.com/?color=c9d1d9&size=35&color=7115b1&center=true&vCenter=true&width=1000&lines=Hello!+My+name+is+Camila.;Be+Welcome!+:%29)](https://git.io/typing-svg)

<p align="center">Olá! Me chamo Camila e atualmente retornei aos meus estudos no mundo Tech.<br>Espero poder aprender e colaborar bastante por aqui ❤️</p>
<br>

<div align="center">  
  <img width="49%" height="195px" src="https://github-readme-stats.vercel.app/api?username=C4m0mila&show_icons=true&count_private=true&hide_border=false&title_color=461e91&icon_color=461e91&text_color=dbc8ee&bg_color=0d1117" alt="C4m0mila github stats" /> 
  <img width="41%" height="195px" src="https://github-readme-stats.vercel.app/api/top-langs/?username=C4m0mila&layout=compact&hide_border=false&title_color=461e91&text_color=dbc8ee&bg_color=0d1117" />
</div>

<br>

<img src="https://raw.githubusercontent.com/MicaelliMedeiros/micaellimedeiros/master/image/computer-illustration.png" min-width="400px" max-width="400px" width="400px" align="right" alt="Computador iuriCode">

<div style="display: inline_block" align="center">
  <h3>Main Skills</h3>
  <img align="center" alt="html5" src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white" />
  <img align="center" alt="css" src="https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white" />
  <img align="center" alt="js" src="https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black" />
 
  <div> 
  <h3>Studying in this moment</h3>
     <img align= "center" src="https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=white" />
  </div>
  
</div><br/>



