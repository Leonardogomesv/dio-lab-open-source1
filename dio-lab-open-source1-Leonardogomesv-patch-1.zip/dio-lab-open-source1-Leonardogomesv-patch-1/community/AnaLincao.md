# AnaLincao
Olá! 

## Tecnologias
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![MySQL](https://img.shields.io/badge/-MySQL-4479A1?style=flat-square&logo=mysql&logoColor=white)
![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AnaLincao&theme=transparent&bg_color=936&border_color=FFF&show_icons=true&icon_color=FFF&title_color=FFF&text_color=FFF)

## Minhas Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AnaLincao&repo=dio-lab-open-source&bg_color=936&border_color=fff&show_icons=true&icon_color=fff&title_color=fff&text_color=FFF)](https://github.com/AnaGand/dio-lab-open-source.git)
