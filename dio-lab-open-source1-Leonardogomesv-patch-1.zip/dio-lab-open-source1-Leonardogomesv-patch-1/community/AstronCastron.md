# Cristian Castro
Formado em Segurança da informação, atualmente estou estudando programação na DIO e planejo adquirir conhecimento suficiente para poder mudar para a carreira de TI. Sou fotografo nas horas vagas e apaixonado por tecnologia!
## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/soucastro/) [![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/chrismcastro/)
[![YouTube](https://img.shields.io/badge/YouTube-%23000000.svg?style=for-the-badge&logo=YouTube&logoColor=red)](https://www.youtube.com/@Omaestro367)
## Habilidades
![Git](https://img.shields.io/badge/git-%23000000.svg?style=for-the-badge&logo=git&logoColor=red) ![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5) ![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown) ![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4) ![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript) ![WordPress](https://img.shields.io/badge/WordPress-%23000.svg?style=for-the-badge&logo=WordPress&logoColor=white)
![Adobe Lightroom](https://img.shields.io/badge/Adobe%20Lightroom-000.svg?style=for-the-badge&logo=Adobe%20Lightroom&logoColor=blue) ![Adobe Photoshop](https://img.shields.io/badge/adobe%20photoshop-%23000.svg?style=for-the-badge&logo=adobe%20photoshop&logoColor=blue)

## Github stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AstronCastron&theme=transparent&bg_color=909&border_color=fff&show_icons=true&icon_color=fff&title_color=fff&text_color=FFF&hide_title=true&hide=stars)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AstronCastron&layout=compact&bg_color=000&border_color=fff&title_color=ff&text_color=FFF)
## Minhas Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AstronCastron&repo=dio-lab-open-source&bg_color=090&border_color=fff&show_icons=true&icon_color=fff&title_color=fff&text_color=FFF)](https://github.com/AstronCastron/dio-lab-open-source.git)