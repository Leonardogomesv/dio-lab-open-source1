##### Olá, meu nome é Giancarlo, sou técnico em manutenção e suporte em informática e estudante por conta própria de desenvolvimento de software. Além de programar e trabalhar com informática, pratico mountain bike e até participo de competições. Gosto de natureza de um modo geral e tenho grande interesse por iniciativas que visam a sustentabilidade e proteção ao meio ambiente. 

##### As principais linguagens ou tecnologias que estudo ou já estudei e tive contato são:

- ![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
- ![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
- ![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
- ![PHP](https://img.shields.io/badge/PHP-000?style=for-the-badge&logo=php&logoColor=777884)
- ![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
- ![Angular](https://img.shields.io/badge/Angular-000?style=for-the-badge&logo=angular&logoColor=C3002F)
- ![TypeScript](https://img.shields.io/badge/TypeScript-000?style=for-the-badge&logo=typescript)
- ![Git](https://img.shields.io/badge/git-%23F05033.svg?style=for-the-badge&logo=git&logoColor=white)
- ![GitHub](https://img.shields.io/badge/github-%23121011.svg?style=for-the-badge&logo=github&logoColor=white)

#### Sistemas Operacionais
- ![Windows](https://img.shields.io/badge/Windows-000?style=for-the-badge&logo=windows&logoColor=2CA5E0)
- ![Linux](https://img.shields.io/badge/Linux-000?style=for-the-badge&logo=linux&logoColor=FCC624)

#### Conecte-se comigo!
- 	[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/gian-rodrigues/)
- [![GitHub](https://img.shields.io/badge/GitHbt-000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/Bajan1408)

