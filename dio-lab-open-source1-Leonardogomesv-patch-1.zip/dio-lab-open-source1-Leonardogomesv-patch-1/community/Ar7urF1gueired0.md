<header>
<h1> <strong>Prazer, meu nome é Artur Figueiredo!</strong> </h1>

<p>

<i>* Estudante de Ciência da Computação em busca de aprendizado na área de dados.</i>

<i>* Aluno da Universidade Federal de São Paulo [(UNIFESP)](https://www.unifesp.br/).</i>
</header>


<div>
  <a href="https://github.com/Ar7urF1gueired0">
  <img height="160em" src="https://github-readme-stats.vercel.app/api?username=Ar7urF1gueired0&show_icons=true&theme=radical&include_all_commits=true&count_private=true"/>
</div>


<div style="display: inline_block"><br>

<h2 align = "left"> HardSkills </h2>
<p>

<i>SQL

<i>Python

<i>C
  
</p>
</div>

<div style="display: inline_block"><br>

<h2 align = "left"> SoftSkills </h2>
<p>

<i>Trabalhar em grupo.

<i>Comunicação.

<i>Lidar com prazos.

<i>Adaptatividade.
  
</p>
</div>

<div style="display: inline_block"><br>
  
<h2 align = "left"> Redes Sociais e contato </h2>
<p>
	
<i> Instagram: [artur_figueiredo_](https://www.instagram.com/artur_figueiredo_/)</i> 

<i> Email: arturfig.br@gmail.com</i>

<i> Whatsapp: +55 (11) 97500-2820</i>

</p>
</div>


