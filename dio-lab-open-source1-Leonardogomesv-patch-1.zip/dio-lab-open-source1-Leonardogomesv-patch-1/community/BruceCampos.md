# Bruce Campos 
<div align="center">
  <img style="border-radius:100px;" height="150" src="https://pm1.aminoapps.com/7018/35d28a27e2c593b87a7ae6e1a58fbad2277fe19br1-600-600v2_hq.jpg"  />
</div>

[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&width=435&lines=Oi%2C+meu+nome+%C3%A9+Bruce+;Bem+vindo+ao+meu+perfil+do+GitHub+%3AD)](https://git.io/typing-svg)
### Sobre mim
```javascript
const bruce = {
    nome: "Bruce Campos",
    idade: 33,
    cidade: "Novo Horizonte, SP",
    stack: ["JavaScript", "ReactJS", "Django", "NodeJS", "Python", "Pandas", "Numpy", "Matplotlib", "Seaborn", "Scikit-learn", "SQL", "MySQL", "MongoDB", "Git", "GitHub"],
    hobbies: ["Games", "Assistir séries", "Ouvir música", "Programar"]
}
```



## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/camposbruce/)


## Github Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=BruceCampos&&theme=codeSTACKr&show_icons=true)




## Linguagens mais usadas
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=BruceCampos&theme=codeSTACKr&show_icons=true)

