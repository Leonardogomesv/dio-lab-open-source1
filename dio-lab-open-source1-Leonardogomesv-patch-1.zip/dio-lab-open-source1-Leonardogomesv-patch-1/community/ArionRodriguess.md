# Arion Rodrigues

# Sobre mim

- 23 anos
- Formado em Ciência da Computação
- Apaixonado por Data Science
- Buscando ser um Analista de Dados

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)(https://www.linkedin.com/in/arionrodrigues/)

## Habilidades Principais

[![MYSQL](https://img.shields.io/badge/MYSQL-000?style=for-the-badge&logo=mysql&logoColor=30A3DC)]
[![PowerBi](https://img.shields.io/badge/-PowerBi-0D1117?style=for-the-badge&logo=powerbi&labelColor=0D1117&textColor=0D1117)&nbsp;]
[![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)]
[![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)]
[![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)]
[![AWS](https://img.shields.io/badge/AWS-%23FF9900.svg?style=for-the-badge&logo=amazon-aws&logoColor=30A3DC)]
