# Márcio's Prfile:

Hi, I am Márcio! Sou participante do Bootcamp Santander Ciência de Dados. Estudante do IF Sul de Minas no curso Técnico de Desenvolvimento de Sistemas.

# Conecte-se comigo:

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/mrcrvlh/)

# Habilidades:

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)

![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)

# Linguagens:

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
