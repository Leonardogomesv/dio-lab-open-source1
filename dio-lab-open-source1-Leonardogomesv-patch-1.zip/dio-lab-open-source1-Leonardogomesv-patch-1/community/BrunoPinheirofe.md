# Bruno Pinheiro

## Sobre mim:

### Atualmente  sou um estudante de Ciências da Computação, mas comecei meus estudos na área da tecnologia antes mesmo de entrar para faculdade. Primeiro aprendi Python e fiz um curso técnico de reparo de computadores. <br>Desde pequeno tenho uma admiração pela tecnologia e é uma gratificação ter a oportunidade de poder estudar e me aprofundar em aquilo que gosto.<br>
#### Meu objetivo é aperfeiçoar minhas habilidades no mundo da tecnologia e usa-la para melhorar a vida das pessoas ao meu redor. 

<br>

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=BrunoPinheirofe&repo=jogo_da_Forca&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/BrunoPinheirofe/Jogo_da_Forca)
<br>
Joguinho que fiz em uma tarde de tédio

## Conecte-se comigo
[![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord)](https://www.discordapp.com/users/490887700342374407/)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/bruno-pinheiro-ferreira-634480240/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=fff)](https://github.com/BrunoPinheirofe/)
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/bruno2013pinheiro)

## Habilidades
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c)
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)



