# Barbaracgpe

## Connecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/barbaracarvalho-babi/)

## Habilidades
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Barbaracgpe&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Git Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Barbaracgpe&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Minhas contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Barbaracgpe&repo=SEUREPOSITORIO&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Barbaracgpe/dio-lab-open-source)