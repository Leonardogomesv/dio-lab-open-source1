# Alerhyan

Ola tudo bem! 

Sou Alessandro Engenheiro Eletricista pós graduado em Engenharia de Segurança do Trabalho, Estou em busca de novos conhecimentos e de uma nova area para entrar no mercado de trabalho. Como sou iniciante vou precisar da ajuda de vocês e no que eu puder ajudar estarei a disposição!

## Conecte-se Comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/alessandro-andrade-92591b120/)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/sandrao_ferrugem/)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=007BFF)](mailto:alerhyan2007@gmail.com)
## Habilidades
[![GitHub](https://img.shields.io/badge/GitHbt-000?style=for-the-badge&logo=github&logoColor=white)](+https://github.com/Alerhyan)
## Github Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Alerhyan&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
## Minhas Contribuições

[![GitHub Streak](https://streak-stats.demolab.com/?user=Alerhyan&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)