# Caian Marcaccini Vieira   

Olá! Me chamo Caian, sou mineiro e estudante de tecnologia, não possuo formação acadêmica ainda mas estou me aprimorando através de bootcamps e cursos variados. 
Sou um aficcionado por tecnologia e meus hobbies incluem jogar online com os amigos e desenhar. 

## Meus conhecimentos atuais incluem: 
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)
![NodeJS](https://img.shields.io/badge/node.js-6DA55F?style=for-the-badge&logo=node.js&logoColor=white)

### Além dos meus conhecimentos estudo também: 
![MySQL](https://img.shields.io/badge/mysql-%2300f.svg?style=for-the-badge&logo=mysql&logoColor=white)


### Para me encontrar nas intineti:
[![Instagram](https://img.shields.io/badge/Instagram-%23E4405F.svg?style=for-the-badge&logo=Instagram&logoColor=white)](https://instagram.com/caianmarcaccini)
[![LinkedIn](https://img.shields.io/badge/linkedin-%230077B5.svg?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/caian-marcaccini-5a86a3131/)
