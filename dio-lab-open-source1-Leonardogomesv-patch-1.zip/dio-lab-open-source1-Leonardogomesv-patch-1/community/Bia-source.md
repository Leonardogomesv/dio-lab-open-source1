### Fala Dev meu nome é Beatriz 🔥🚀

<p>
 Um pouquinho sobre mim, sou  basicamente uma jovem desenvolvedora full stack apaixonada por programação e por aprender, seja novas tecnologias, novas ferramentas, jeitos diferentes de implementar a mesma funcionalidade com diferentes recursos, tecnologias, plataformas entre muitas outras coisas. Meu trabalho e estudos tem como foco o desenvolvimento de aplicativos mobile e a criação e sustentação de aplicações backend utilizando em ambas majoritariamente TypeScript. 
Para não me limitar falando apenas de linguagens de programação que tenho proficiência, gosto de utilizar o termo “tecnologia”. As tecnologias que fazem parte do meu dia a dia de trabalho e estudos são JavaScript, Typescript, MongoDB, PostgreSQL, MySQL, Nodejs, TypeORM, Sequelize, Knex, Prisma, Express, Jest, GraphQL, React-Native, Angular.
Acredito que ao ensinar/compartilhar também aprendemos e eu amo compartilhar o conhecimento que tenho, então sintam-se a vontade para pedir dicas de cursos, perguntas de código, ouvir aquele incentivo para persistir e insistir no mundo maravilhoso do desenvolvimento de softwares!
Como nem só de trabalho viverá o homem ou no meu caso a mulher, no meu tempo livre eu continuo estudando programação backend que é a minha atual paixão, sim eu estudo no meu tempo livre porque eu realmente amo estudar, desenvolver aplicações e melhorar as já existentes. Estudo também música pois toco violão, guitarra, cavaquinho, teclado e pouquíssima coisa de bateria até o momento. Também jogo volei em um time feminino adulto amador, esporte que é minha outra paixão e essa sou eu resumidamente, muito estudo, trabalho e esporte☺️
<p>

<div style="display: inline_block"><br>
  <img align="center" alt="Bia-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Bia-Ts" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/typescript/typescript-plain.svg">
   <img align="center" alt="Bia-Java" height="30" width="40" 
src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original-wordmark.svg" />
  <img align="center" alt="Bia-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Bia-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
   <img align="center" alt="Bia-Angular" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/angularjs/angularjs-original.svg" />
   <img align="center" alt="Bia-React" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original.svg">
   <img align="center" alt="Bia-Node" height="30" width="40"
src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-original.svg" />
   <img align="center" alt="Bia-MongoDB" height="30" width="40"
src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mongodb/mongodb-original.svg" />
   <img align="center" alt="Bia-Postgres" height="30" width="40"
src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/postgresql/postgresql-original.svg" />
   <img align="center" alt="Bia-MySql" height="30" width="40"
src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg" />
   <img align="center" alt="Bia-Express" height="30" width="40"
src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/express/express-original-wordmark.svg" />
   <img align="center" alt="Bia-Sequelize" height="30" width="40"
src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/sequelize/sequelize-original.svg" />
   <img align="center" alt="Bia-Jest" height="30" width="40"
src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/jest/jest-plain.svg" />
</div>
  
## 

<div> 
  <a href = "mailto:bia.ferreirads.santos@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/beatriz-ferreira-dos-santos-4b9ab0191/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
  
</div>

