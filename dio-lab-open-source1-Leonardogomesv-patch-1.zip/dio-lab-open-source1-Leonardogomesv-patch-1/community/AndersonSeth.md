
# Anderson Chagas da Silva
### 🚀 Sobre mim
Olá sou Anderson, profissional da área financeira em transição para a área de Tecnologia.
Durante minha carreira, participei de projetos estratégicos nas empresas, que atuei, com participação direta tanto na coordenação de equipes como na execução de atividades relacionadas à área de Tecnologia, como exemplo a modernização dos servidores fisicos para service cloud e atualização da telefonia fixa para VOIP. 
Estou me especializando na área através do curso de Analise e Desenvolviemento de Sistemas pela Faculdade Impacta e Bootcamp oferecido pelo Santander em parceiria com a DIO
Capacidade de planejamento e visão sistêmica fazem parte do meu perfil.


[![GitHub Streak](https://streak-stats.demolab.com/?user=AndersonSeth&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)

## 🛠 Habilidades em desenvolvimento

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=ANDERSONSETH&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Conecte-se comigo através:
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/anderson-chagas-da-silva-92445047/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/setpoint91)


