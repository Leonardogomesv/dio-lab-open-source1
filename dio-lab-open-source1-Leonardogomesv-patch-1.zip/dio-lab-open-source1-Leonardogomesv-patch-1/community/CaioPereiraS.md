# Caio Pereira

Olá a todos! Meu nome é Caio Pereira e estou animado para compartilhar um pouco sobre minha jornada como jovem desenvolvedor de software. Desde cedo, fui fascinado pela arte da programação e o mundo dos jogos. 
Sou um jovem entusiasta da tecnologia, com um amor incondicional pela programação. Desde o momento em que escrevi minha primeira linha de código.
Desde criança, os jogos sempre foram uma parte essencial da minha vida. Fui atraído para o universo da programação de jogos, onde poderia combinar minha paixão por jogos e habilidades de desenvolvimento de software.

### Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/caio-pereira-42967026a/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://github.com/CaioPereiraS)

## Habilidades

![HTML5](https://img.shields.io/badge/html5-0D1117.svg?style=for-the-badge&logo=html5&logoColor=CC6699)
![CSS3](https://img.shields.io/badge/css3-0D1117.svg?style=for-the-badge&logo=css3&logoColor=CC6699)
![JavaScript](https://img.shields.io/badge/javascript-0D1117.svg?style=for-the-badge&logo=javascript&logoColor=CC6699)
![Java](https://img.shields.io/badge/java-0D1117.svg?style=for-the-badge&logo=openjdk&logoColor=CC6699)
![Python](https://img.shields.io/badge/python-0D1117?style=for-the-badge&logo=python&logoColor=CC6699)

## Github Stats
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=CaioPereiraS&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)