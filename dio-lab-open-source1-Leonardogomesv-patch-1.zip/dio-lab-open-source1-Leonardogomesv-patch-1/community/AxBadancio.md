## Vinicius Meronho | AxBadancio
Sou um estudante de Gestão de TI na Fatec Jahu, estou no 4° semestre dos 6 presentes no curso.

Tenho como objetivo cursar Ciência de Dados logo após terminar minha atual faculdade.


### Sei o básico das linguagens
![HTML](https://img.shields.io/badge/HTML-red)
![CSS](https://img.shields.io/badge/CSS-blue)
![JS](https://img.shields.io/badge/JavaScript-yellow)
![PHP](https://img.shields.io/badge/PHP-darkblue)
![Python](https://img.shields.io/badge/Python-darkblue)
![C](https://img.shields.io/badge/C-blue)
![C#](https://img.shields.io/badge/C%23-purple)


### Redes Sociais

[![Perfil DIO](https://img.shields.io/badge/DIO/PERFIL-darkblue)](https://www.dio.me/users/vinimeronhi)
[![GitHub](https://img.shields.io/badge/GitHub-black)](https://github.com/AxBadancio)

### Status GitHub
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AxBadancio&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=SEUUSERNAME&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)



