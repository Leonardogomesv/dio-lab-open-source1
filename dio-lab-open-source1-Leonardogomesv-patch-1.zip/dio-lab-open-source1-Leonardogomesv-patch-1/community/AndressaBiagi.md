<h1 align="center">Hi 👋, I'm Andressa Biagi</h1>
<h3 align="center">A Self-taught Software Developer</h3>

## 🚀 About me
I am passionate about technology and learning. I started my study path through free courses and now I dedicate myself to personal projects to build a portfolio that demonstrates my experience. I've always been curious about how things happened behind screens and today, not only do I understand, but I also know how to develop my own applications.

## 🌱 I’m currently learning 
- **JAVA**, **relational and non-relational database** and **OOP** with the Johnsons&Johnsons MedTech and mesttra training program. I'm also delving into **CSS** through projects and i intend to learn **REACT** as soon as possible!

- 👨‍💻 Soon all of my projects will be available at my website.


## 🛠 Languages and Tools that I'm Familiar With:
<p align="left"> <a href="https://getbootstrap.com" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/bootstrap/bootstrap-plain-wordmark.svg" alt="bootstrap" width="40" height="40"/> </a> <a href="https://www.w3schools.com/css/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original-wordmark.svg" alt="css3" width="40" height="40"/> </a> <a href="https://git-scm.com/" target="_blank" rel="noreferrer"> <img src="https://www.vectorlogo.zone/logos/git-scm/git-scm-icon.svg" alt="git" width="40" height="40"/> </a> <a href="https://www.w3.org/html/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original-wordmark.svg" alt="html5" width="40" height="40"/> </a> <a href="https://www.java.com" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg" alt="java" width="40" height="40"/> </a> <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg" alt="javascript" width="40" height="40"/> </a> <a href="https://www.typescriptlang.org/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/typescript/typescript-original.svg" alt="typescript" width="40" height="40"/> </a> </p>




## 🔗 Links
[![portfolio](https://img.shields.io/badge/my_portfolio-000?style=for-the-badge&logo=ko-fi&logoColor=white)](#)
[![whatsapp](https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/qr/FQYKVMMQZFBUA1)

<h3 align="right">Connect with me:</h3>
<p align="right">
<a href="https://linkedin.com/in/andressa biagi" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/linked-in-alt.svg" alt="andressa biagi" height="30" width="40" /></a>
<a href="https://www.hackerrank.com/@andressajbiagi" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/hackerrank.svg" alt="@andressajbiagi" height="30" width="40" /></a>
<a href="https://discord.gg/#0010" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/discord.svg" alt="#0010" height="30" width="40" /></a>
<a href="https://www.beecrowd.com.br/judge/pt/profile/695459" target="blank"><p align="right">BEECROWD</p></a>
</p>
