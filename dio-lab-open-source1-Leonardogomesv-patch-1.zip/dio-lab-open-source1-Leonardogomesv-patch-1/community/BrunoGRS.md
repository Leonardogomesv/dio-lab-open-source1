# Olá Devs 🤟🏻

Me chamo Bruno e sou um entusiasta da tecnologia e programação. Meu foco é back-end e pretendo me tornar um programador inovador, fora da casinha.



## 👨🏻‍💻 Sobre Mim

Me encontro na área de TI a aproximadamente a quase 2 anos já, atuando principalmente com suporte de usuários e sistemas. Nesses dois anos já colecionei muitas experiências e erros pelo caminho, tudo o que me fez evoluir e crescer como profissional dentro da minha carreira. Atualmente ocupo o lugar de Analista de Suporte de TI porém pretendo migrar para a carreira 100% dev nos próximos anos.



Curso Atualmente Análise e Desenvolvimento de Sistemas, com previsão de terminar no fim do ano de 2025. Já pratico em  vários projetos e tenho muitos futuros planos para desenvolver e consolidar neste âmbito, como também a confecção de um aplicativo totalmente novo que farei no meu TCC.



## Tecnologias

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c)

![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=BrunoGRS&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)



## Conecte-se Comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/bruno-gabriel-rodrigues/)



