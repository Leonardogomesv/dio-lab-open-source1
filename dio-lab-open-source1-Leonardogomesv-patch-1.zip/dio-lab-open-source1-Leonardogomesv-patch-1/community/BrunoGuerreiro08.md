<div align="center">
<img src="https://media0.giphy.com/media/v1.Y2lkPTc5MGI3NjExYmM3YmM2Nzc3NzZjYjU2NjNiZDM0NTEyZDliNDc5OTk1YzQ0OWUzNyZjdD1z/cMPNojQH2tB3v7NnCt/giphy.gif" width="100">
</br>

[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&color=00F716&center=true&vCenter=true&repeat=false&width=1000&lines=Hi%2C+I+am+Bruno!+)](https://git.io/typing-svg)


I am a brazilian Computer Engineeering student at UFTPR-PB, currently studying backend development using <a href="https://www.python.org" target="_blank" rel="noreferrer"> 
<img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="20" height="20"/> </a>

### Some of my stats!
[![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=BrunoGuerreiro08&layout=compact&theme=merko&hide_border=True)](https://github.com/anuraghazra/github-readme-stats)
[![Anurag's GitHub stats](https://github-readme-stats.vercel.app/api?username=BrunoGuerreiro08&show_icons=true&theme=merko&hide=contribs&hide_border=True)](https://github.com/anuraghazra/github-readme-stats)

## Looking for intership oportunities! 

### Find me on:
<p align="left">
<a href="https://linkedin.com/in/bruno-guerreiro-9431a926a/" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/linked-in-alt.svg" alt="https://www.linkedin.com/in/bruno-guerreiro-9431a926a/" height="30" width="40" /></a>
</p>
