### Olá! Me Chamo Caio Souza 💻

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/caiosouzads/)
[![DIO](https://img.shields.io/badge/Perfil-DIO-blue?style=for-the-badge)](https://www.dio.me/users/caio_tito)

Desenvolvedor .Net com background em engenharia mecânica e pós-graduação em projetos. Cursando Sistemas de Informação, migrei para área de tecnologia que sempre foi minha paixão. 

![Caio Souza GitHub stats](https://github-readme-stats.vercel.app/api?username=caiotito&show_icons=true&theme=highcontrast)

[![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=caiotito&layout=compact)](https://github.com/anuraghazra/github-readme-stats)

## Tecnologias utilizadas no dia-dia:

<div style="display: inline_block"<br/>>
  <img align="center" alt = "C#" src="https://img.shields.io/badge/C%23-239120?style=for-the-badge&logo=c-sharp&logoColor=white"/>
  <img align="center" alt = ".Net" src="https://img.shields.io/badge/.NET-5C2D91?style=for-the-badge&logo=.net&logoColor=white"/>
  <img align="center" alt = "HTML" src="https://img.shields.io/badge/HTML-239120?style=for-the-badge&logo=html5&logoColor=white"/>
  <img align="center" alt = "CSS" src="https://img.shields.io/badge/CSS-239120?&style=for-the-badge&logo=css3&logoColor=white"/>
  <img align="center" alt = "Javascript" src="https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black"/>
  <img align="center" alt = "SQL Server" src="https://img.shields.io/badge/Microsoft_SQL_Server-CC2927?style=for-the-badge&logo=microsoft-sql-server&logoColor=white"/>
  <img align="center" alt = "MongoDB" src="https://img.shields.io/badge/MongoDB-4EA94B?style=for-the-badge&logo=mongodb&logoColor=white"/>
  <img align="center" alt = "Azure DevOps" src="https://img.shields.io/badge/Azure_DevOps-0078D7?style=for-the-badge&logo=azure-devops&logoColor=white"/>
  <img align="center" alt = "Azure Function" src="https://img.shields.io/badge/Azure_Functions-0062AD?style=for-the-badge&logo=azure-functions&logoColor=white"/>
  <img align="center" alt = "RabbitMQ" src="https://img.shields.io/badge/rabbitmq-%23FF6600.svg?&style=for-the-badge&logo=rabbitmq&logoColor=white"/>
  <img align="center" alt = "Git" src="https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white"/>
</div><br/>

## Tecnologias em Desenvolvimento

<div style="display: inline_block"<br/>>
  <img align="center" alt = "Angular" src="https://img.shields.io/badge/Angular-DD0031?style=for-the-badge&logo=angular&logoColor=white"/>
  <img align="center" alt = "PL/SQL" src="https://img.shields.io/badge/Oracle-F80000?style=for-the-badge&logo=Oracle&logoColor=white"/>
  <img align="center" alt = "PL/SQL" src="https://img.shields.io/badge/redis-%23DD0031.svg?&style=for-the-badge&logo=redis&logoColor=white"/>
</div><br/>
