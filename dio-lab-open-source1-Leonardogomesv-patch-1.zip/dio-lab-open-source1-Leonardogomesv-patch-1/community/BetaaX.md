<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=FFEEC3&height=120&section=header"/>

[![Typing SVG](https://readme-typing-svg.herokuapp.com/?color=FFF2D2&size=35&center=true&vCenter=true&width=1000&lines=Hi+there,+my+name+is+João.;I'm+18+years+old;and+I’m+enhancing+my+skills+in+Front-End.;Feel+free+to+explore+my+GitHub!)](https://git.io/typing-svg)

<div align="center">
  <img width="49%" height="195px" src="https://github-readme-stats.vercel.app/api?username=BetaaX&show_icons=false&theme=moltack&include_all_commits=true&count_private=false"/>
  <img width="41%" height="195px" src="https://github-readme-stats.vercel.app/api/top-langs/?username=BetaaX&layout=compact&langs_count=6&theme=moltack"/>
</div>

### Top skills:
![HTML5](https://img.shields.io/badge/html5-0D1117?style=for-the-badge&logo=html5&logoColor=23E34F26)&nbsp;
![CSS3](https://img.shields.io/badge/css3-0D1117?style=for-the-badge&logo=css3&logoColor=blue)&nbsp;
![JavaScript](https://img.shields.io/badge/JavaScript-0D1117?style=for-the-badge&logo=javascript&logoColor=F0DB4F)&nbsp; 
![jQuery](https://img.shields.io/badge/jQuery-0D1117?style=for-the-badge&logo=jquery&logoColor=0769AD)&nbsp;
![Bootstrap](https://img.shields.io/badge/BootStrap-0D1117?style=for-the-badge&logo=bootstrap&logoColor=#563d7c)&nbsp;
<br>

![](https://komarev.com/ghpvc/?username=BetaaX&color=lightgrey&style=flat-square&label=PROFILE+VIEWS)

<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=FFEEC3&height=120&section=footer"/>
