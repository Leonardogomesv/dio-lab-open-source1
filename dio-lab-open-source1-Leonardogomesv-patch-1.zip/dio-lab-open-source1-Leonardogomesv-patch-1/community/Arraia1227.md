[![Typing SVG](https://readme-typing-svg.herokuapp.com?duration=5011&color=CFCECB&center=falso&vCenter=falso&lines=👋+Olá+meu+nome+é+Kauê;)](https://git.io/typing-svg)
<h1>
    <a href="https://web.dio.me/users/kauedasilvajesus26?tab=skills">
     <img align="center" width="40px" src="https://hermes.digitalinnovation.one/assets/diome/logo-minimized.png">
 Kauê
</a></h1>

<h2><strong>Biografia sobre mim:</strong></h2>
<p>Sou o Kauê, tenho 18 anos, tenho um conhecimento basico com front-end com HTML, CSS e Javascript.</p>
<h2><strong>Minha formação acadêmica</strong></h2>
<p>Ensino Medio - Completo</p>

<h2><strong>Cursos</strong></h2>
<ul>
<li>HTML, CSS e logica de programação - Liga Solitária - Completo </li>
<li>Formação Humana, Autoconhecimento, Inteligência emocional, Diversidade, Comunicação não violenta - Liga Solitárian - Completo</li>
<li>Backend Java - Bootcamp DIO & Santander - Em andamento </li>
</ul>

<h2><strong>Tecnologia</strong></h2>
<p>Intermediário:</p>

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
<p>Intermediário:</p>

[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc)

 <p>Iniciante:</p>

![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)

<h2><strong>Conecte-se comigo:</strong></h2>

[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/kauedasilvajesus26/)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](kauedasilvajesus26@gmail.com)
[![Instagram](https://img.shields.io/badge/Instagram-%23E4405F.svg?style=for-the-badge&logo=Instagram&logoColor=white)](https://www.instagram.com/_kaue_011sp/)

