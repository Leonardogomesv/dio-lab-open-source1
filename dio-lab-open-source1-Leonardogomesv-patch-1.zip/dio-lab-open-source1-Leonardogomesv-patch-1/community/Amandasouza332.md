# Amanda
Olá,tudo bem? Me chamo Amanda curso ciência da computação e o bootcamp santander.
## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/amanda-let%C3%ADcia-7353b312a)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://instagram.com/mandy_yuki?igshid=YTQwZjQ0NmI0OA==)
[![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord)](https://discord.com/channels/@me)

## Habilidades
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![C++](https://img.shields.io/badge/C%2B%2B-000?style=for-the-badge&logo=c%2B%2B&logoColor=00599C)
![C++](https://img.shields.io/badge/C%2B%2B-000?style=for-the-badge&logo=c%2B%2B&logoColor=00599C)
## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Amandasouza332&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94DF&text_color=FFF)

## Minhas contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Amandasouza332&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E9D5F&text_color=FFF)](https://github.com/Amandasouza332/dio-lab-open-source.git)