
# Participando da DIO!

Olá meu nome é Caio, comecei a desenvolver em 2020 com portugol utilizando o Visualg, a partir daí fui me aprofundando um pouco mais e foi intuitivo o aprendizado de HTML CSS3 e JS, depois me apaixonei por back-end e aprendi node.js e fiz alguns pequenos projetos utitilizando mysql e sequelize junto express.

Atualmente estudo java, e gostaria de aprender angular que é um framework muito poderoso pra quem sabe usar. Com a DIO oferecendo essa oportunidade achei conveniente aproveitar, mas confesso que o prazo de término é meio curto eu to meio preguiçoso.

## Tecnologias

![HTML](https://img.shields.io/badge/HTML-000?style=for-the-badge&logo=html5&logoColor=30A3DC)
![CSS](https://img.shields.io/badge/CSS-000?style=for-the-badge&logo=css3&logoColor=30A3D)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript&logoColor=30A3DC)
![NODEJS](https://img.shields.io/badge/NODEJS-000?style=for-the-badge&logo=node.js&logoColor=30A3DC)
![MYSQL](https://img.shields.io/badge/MYSQL-000?style=for-the-badge&logo=mysql&logoColor=30A3DC)
![JAVA](https://img.shields.io/badge/JAVA-000?style=for-the-badge&logo=Java&logoColor=30A3DC)
![GIT](https://img.shields.io/badge/GIT-000?style=for-the-badge&logo=git&logoColor=30A3DC)

Bom é isso, provavelmente ninguém vai ver o meu perfil, tem muita gente aqui haha.

Por via das dúvidas:

[![LINKEDIN](https://img.shields.io/badge/Preview-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](linkedin.com/in/caio-sampaio-704a381b2/)




