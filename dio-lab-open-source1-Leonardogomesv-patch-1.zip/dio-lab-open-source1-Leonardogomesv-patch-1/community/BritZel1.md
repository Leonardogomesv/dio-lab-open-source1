# Britney Nascimento

### Sobre mim
Olá pessoal! Sou Britney Nascimento, atualmente trabalho como desenvolvedora fullstack JAVA e Angular.js. Acredito nunca ser tarde demais pra aprender algo novo e sempre podemos nos aperfeiçoar, Qualquer conhecimento e melhoria são sempre bem vindos.

### Conecte-se comigo!
[![LinkedIn](https://img.shields.io/badge/LinkedIn-FFB6C1?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/britney-nascimento-1445b820a/)<a href="https://web.dio.me/users/britneyisabel42">
           <img align="" alt="Perfil dio" src="https://img.shields.io/badge/Meu%20perfil%20DIO-pink">
        </a>

### Algumas tecnologias familiarizadas:
![MySQL](https://img.shields.io/badge/MySQL-FFB6C1?style=for-the-badge&logo=mysql&logoColor=005C84)![PostgreSQL](https://img.shields.io/badge/PostgreSQL-FFB6C1?style=for-the-badge&logo=postgresql)![Angular](https://img.shields.io/badge/Angular-FFB6C1?style=for-the-badge&logo=angular&logoColor=C3002F)![C](https://img.shields.io/badge/C-FFB6C1?style=for-the-badge&logo=c)![Java](https://img.shields.io/badge/Java-FFB6C1?style=for-the-badge&logo=java)![JavaScript](https://img.shields.io/badge/JavaScript-FFB6C1?style=for-the-badge&logo=javascript)![TypeScript](https://img.shields.io/badge/TypeScript-FFB6C1?style=for-the-badge&logo=typescript)
