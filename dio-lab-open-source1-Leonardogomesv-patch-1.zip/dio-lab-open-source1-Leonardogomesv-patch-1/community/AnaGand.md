
# Ana Maria Gandini Manoel

## Bem vindo ao meu perfil 
Me chamo Ana, tenho 26 anos e estou começando agora na área de programação. Estou descobrindo um ambiente nunca explorado por mim, e surpreendentemente, **estou amando**! Atualmente sou estudante de Design de Moda e tenho interesse em juntar Moda com Programação. 


## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-936?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/ana-maria-gandini-manoel-4116a0150/)

[![Instagram](https://img.shields.io/badge/Instagram-936?style=for-the-badge&logo=instagram)](https://www.instagram.com/anagand/)
## Habilidades 
![Python](https://img.shields.io/badge/Python-936?style=for-the-badge&logo=python)

![Git](https://img.shields.io/badge/git-936?style=for-the-badge&logo=git&logoColor=white)

![GitHub](https://img.shields.io/badge/github-936?style=for-the-badge&logo=github&logoColor=white)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AnaGand&theme=transparent&bg_color=936&border_color=FFF&show_icons=true&icon_color=FFF&title_color=FFF&text_color=FFF)

## Minhas Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AnaGand&repo=dio-lab-open-source&bg_color=936&border_color=fff&show_icons=true&icon_color=fff&title_color=fff&text_color=FFF)](https://github.com/AnaGand/dio-lab-open-source.git)
