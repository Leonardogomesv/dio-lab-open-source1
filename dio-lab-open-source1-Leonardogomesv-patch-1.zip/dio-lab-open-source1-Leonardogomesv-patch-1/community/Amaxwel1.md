
# Alex Maxwel


#### Breve descrição sobre min:

Sou o Alex, tenho 19 anos e atualmente estou cursando Engenharia de Software, venho trabalhando no meio de DevOps a um tempo, com as tecnologias de Kubernetes, OpenShift, Docker, Argo CD, Tekton, Terraform entre outras. Estou em constante busca por conhecimento e desafios emocionantes no mundo da tecnologia.



### Conecte-se comigo:
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=30A3DC)](alex:alexmaxwellbg@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/alex-maxwel-7901841ba/)


### Habilidades:
![OpenShift](https://img.shields.io/badge/Openshift-000?style=for-the-badge&logo=redhat&logoColor=red)
![AWS](https://img.shields.io/badge/AWS-000.svg?style=for-the-badge&logo=amazon-aws&logoColor=yellow)
![Tekton](https://img.shields.io/badge/Tekton-000.svg?style=for-the-badge&logo=tekton&logoColor=purple)
![Argo CD](https://img.shields.io/badge/Argo_CD-000.svg?style=for-the-badge&logo=argo&logoColor=orange)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=30A3DC)](https://docs.github.com/)
[![kubernets](https://img.shields.io/badge/Kubernetes-000?style=for-the-badge&logo=kubernetes&logoColor=30A3DC)](https://docs.github.com/)
[![OCI](https://img.shields.io/badge/OCI-000?style=for-the-badge&logo=oracle&logoColor=red)](https://docs.github.com/)
[![Helm](https://img.shields.io/badge/helm-000?style=for-the-badge&logo=helm&logoColor=blue)](https://docs.github.com/)

### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Amaxwel1&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

### GitHub Streak Stats

[![GitHub Streak](https://streak-stats.demolab.com/?user=Amaxwel1&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)

### Meus Principais Desafios de Projeto DIO
[![Repo DIO Versionamento de Código com Git e GitHub](https://github-readme-stats.vercel.app/api/pin/?username=elidianaandrade&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Amaxwel1/dio-lab-open-source.git)

