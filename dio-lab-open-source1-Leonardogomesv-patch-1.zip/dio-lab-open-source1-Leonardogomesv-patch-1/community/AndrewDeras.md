### Olá, eu sou o Andrew Barbosa 👋

* Cursando Tecnologia em Sistemas de Computação - Universidade Federal Fluminense ( 1/6 ). 💻
* Técnico em Desenvolvimento Web - Prefeitura do Rio de Janeiro em parceria com SenacRJ e Resilia educação 2022/23. 💻
* Principais tecnologias: Javascript - ReactJs - NodeJs - ExpressJs - API-  mySQL - GIT - HTML - CSS - Bootstrap. ⌨️
* Idiomas:  
  * Espanhol Nativo 🇪🇸   
  * Português Nativo 🇧🇷.

<div align="center">
  <a href="https://www.linkedin.com/in/andrewderas/">
  <img height="150em" src="https://github-readme-stats.vercel.app/api?username=AndrewDeras&show_icons=true&theme=tokyonight&include_all_commits=true&count_private=true"/>
  <img height="150em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=AndrewDeras&layout=compact&langs_count=7&theme=tokyonight"/>
</div>
  <div style="display: inline_block"><br>
   <img align="center" alt="Andrew-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/typescript/typescript-plain.svg">
  <img align="center" alt="Andrew-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
   <img align="center" alt="Andrew-NODE" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-original.svg">
     <img align="center" alt="Andrew-React" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original.svg">
        <img align="center" alt="Andrew-MYSQL" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mysql/mysql-original.svg">
   <img align="center" alt="Andrew-VSCODE" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vscode/vscode-original.svg">
   <img align="center" alt="Andrew-GIT" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-original.svg">
  <img align="center" alt="Andrew-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Andrew-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">

</div>
  
   ##
  
<div> 
  <a href="https://www.linkedin.com/in/andrewderas/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>
  <a href = "mailto:andrewderas7@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
</div>
