# Olá, eu me chamo Bruno

## Uma breve descrição da minha Jornada:

### Sou formado em Análise e Desenvolvimento de Sistemas, porém, decidi ingressar na área de Ilustração Digital. Consegui trabalhar para vários jogos de RPG, porém, hoje estou de volta às minhas origens. Sou apaixonado por tecnologia, conhecer pessoas e me desenvolver profissionalmente.

### Atualmente estou estudando muito ![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)

## Minhas Redes
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/bruno-senigalha/) 

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/bruno.senigalha/)



![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=BrunoSenigalha&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=BrunoSenigalha&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

