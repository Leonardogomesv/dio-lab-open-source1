# Biaizinha

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com//in/beatriz-cardoso-b47417a4/)

## Habilidades
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)

## GutHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?usernamer-Biazinha26&theme=transparent&bg_color=ec63a18border_color=fff&show_icons=true&icon_color=fff&title_color=fff&text_color=fff&hide_title=true&hide=stars)