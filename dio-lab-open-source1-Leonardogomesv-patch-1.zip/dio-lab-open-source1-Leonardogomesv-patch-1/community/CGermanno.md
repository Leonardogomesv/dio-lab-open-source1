# Carlos Germano

👨‍💻 Estudante de Análise e Desenvolvimento de Sistemas (ADS) no terceiro semestre.

🔭 Atualmente, estou explorando diferentes tecnologias e projetos, buscando aprimorar minhas habilidades de desenvolvimento.

🌱 Tenho interesse em programação, desenvolvimento web, mobile e muito mais. Sempre em busca de aprender algo novo.

📚 No momento, estou estudando estruturas de dados e desenvolvimento web.

💬 Fique à vontade para entrar em contato comigo para discutir projetos, colaborações ou apenas para trocar conhecimento!
