# Bernardo Alves

Material desenvolvido para Estudos de Git e GitHub em [Digital Innovation One](https://web.dio.me/)


## Minhas Redes
```
Links meramente ilustrativos
```

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/SEUUSERNAME/)
[![Facebook](https://img.shields.io/badge/Facebook-000?style=for-the-badge&logo=facebook)](https://www.facebook.com/SEUUSERNAME/)
[![WhatsApp](https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/DDI+DDD+SEU_NUMERO_WHATSAPP)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/SEUUSERNAME/)
[![Twitter](https://img.shields.io/badge/Twitter-000?style=for-the-badge&logo=twitter)](https://twitter.com/SEUUSERNAME)

## Por onde já tropecei na jornada de estudos
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![R](https://img.shields.io/badge/R-000?style=for-the-badge&logo=R&logoColor=30A3DC)
![MySQL](https://img.shields.io/badge/MySQL-000?style=for-the-badge&logo=mysql&logoColor=005C84)
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![git](https://img.shields.io/badge/git-000?style=for-the-badge&logo=git)
[![GitHub](https://img.shields.io/badge/GitHbt-000?style=for-the-badge&logo=github&logoColor=white)](+https://github.com/SEUUSERNAME)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![.net](https://img.shields.io/badge/.net-000?style=for-the-badge&logo=.net)
![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)


## Meu Histórico de Contribuição por Aqui

[![GitHub Streak](https://streak-stats.demolab.com/?user=BredAlves&theme=dark&background=000&border=1589&dates=380)](https://git.io/streak-stats)