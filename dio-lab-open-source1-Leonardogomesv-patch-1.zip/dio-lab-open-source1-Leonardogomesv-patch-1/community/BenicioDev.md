## Gabriel Benicio 
Olá! Me chamo Gabriel Benicio, sou torcedor assíduo do Fortaleza Esporte Clube e fã incontestável da banda Creed. Sou estudante de Análise e Desenvolvimento de Sistemas e minha principal área de estudo é a linguagem Java, juntamente com o framework Spring Boot!

## Minha Stack
  ![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
  ![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)


## Status & Atividades
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=BenicioDev&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=beniciodev&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Meus Contatos ↓↓
  → Email: gabrielvitor083@gmail.com
 
  → Linkedin: https://www.linkedin.com/in/vitor-gabriel-09a924179
 
  → GitHub: https://github.com/BenicioDev

## "+" Sobre mim: 
 → Minha Playlist: https://music.youtube.com/playlist?list=PLf7mVrJgSh5YTrSO9lIbXdYlKY-uaJ60N&feature=share
