Black Edson

## conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin)](https://www.linkedin.com/in/edson-kremek-) 

## Habilidades 
[![GitHub](https://img.shields.io/badge/GitHub-black)](https://github.com/BlackEdson) 

![Git](https://img.shields.io/badge/Git-black)

![UnrealEngine](https://img.shields.io/badge/Unreal--Engine-black) 
 
 ## GitHub Stats

 ![GitHub Stats](https://github-readme-stats.vercel.app/api?username=BlackEdson&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=fff&text_color-fff&hide_title=true&hide=stars) 

 ## Minhas Contribuições 

 [![GitHub](https://img.shields.io/badge/GitHub-black)](https://github.com/BlackEdson/dio-lab-open-source)

