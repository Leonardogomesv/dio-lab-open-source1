# Brenno-PP
Hello, world! 
## Sobre mim
Sou engenheiro civil e comecei a pouco tempo desbravar o universo da programação, e tem sido uma jornada desafiadora, porém gratificante em perceber uma evolução gradativa. 
## Contatos
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/brennopercy/) [![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github)](https://www.discord.com/in/Brenno-PP/)

## Conhecimentos
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python) ![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)

## Github Stats
[![GitHub Streak](https://streak-stats.demolab.com/?user=Brenno-PP&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)
