
# CaioCesarMDS


### 🚀 Sobre mim

Olá! , sou um admirador da programação, da inovação, da área de TI, da tecnologia no geral. Meu objetivo é aprender e sempre melhorar, para que eu possa contribuir com a propagação da tecnologia em todos os âmbitos.

Atualmente faço o curso de Análise e Desenvolvimento de Sistemas (ADS), no IFPE Campus Paulista.

# Conecte-se comigo

 * [![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/caiocesarsts)
 * [![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/caio-cesar-aa935425a/)
 * [![Github](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=Github&logoColor=00000)](https://www.github.com/CaioCesarMDS)

# Linguagens e Tecnologias

### Linguagens de Programação
 * ![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

 ### Linguagens de Marcação / Tecnologias
 * ![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
 * ![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
 * ![GIT](https://img.shields.io/badge/git-000?style=for-the-badge&logo=git)
 * ![GITHUB](https://img.shields.io/badge/github-000?style=for-the-badge&logo=github)


# Status

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=CaioCesarMDS&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=CaioCesarMDS&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

# Aprendizados

Neste projeto eu aprendi como contribuir em um projeto open-source

