# OII
## Meu nome é Arthur
### Tenho 16 e estou começando a estudar programação💻
Descupem se estiver muito curto, mas isso vai melhorar com o tempo
