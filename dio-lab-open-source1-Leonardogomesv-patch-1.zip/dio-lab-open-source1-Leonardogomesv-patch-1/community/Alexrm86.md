***********************************

### Hi there 👋

<!--
**Alexrm86/Alexrm86** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.-->
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>About me</b> <br>
- <img src ="https://s3.amazonaws.com/pix.iemoji.com/images/emoji/apple/ios-12/256/boy-light-skin-tone.png" height= 15px width = 15px> Eu sou Alex Resende Machado, tenho 36 anos sou de Salvador - Bahia -Brasil 🇳🇵.
- 🔭 Eu estudei na Trybe,e acabei de me  tornar me tornar um Full Stack Jr.
- 🌱 Atualmente estou me atualizando em outras linguadens sempre buscando aprender mais .
- 👯 Estou procurando colaborar em projetos de código aberto.
- 💬 Pergunte-me sobre tecnologias Web.
- Eu também cursei 6 semestres de engenharia da computação na UNIFACS.
- Eu tenho  muita expreriencia de soft Skills desenvolvido muito na Trybe onde estudei , antes  tive uma copiadora onde tive que estabelecer organização planejamento ,empatia e paciência para atendimento ao publico pois existia muita demanda.  

<div>
<img height="150em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Alexrm86&layout=compact&langs_count=7&theme=github_dark"/>
<img height="150em" src="https://github-readme-stats.vercel.app/api?username=Alexrm86&show_icons=true&theme=github_dark&include_all_commits=true&count_private=true"/>
</div>

### Linguagens
<div>
  <img src="https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black" />
    <img src="https://img.shields.io/badge/Node.js-43853D?style=for-the-badge&logo=node.js&logoColor=white" />

  <img src="https://img.shields.io/badge/Python-14354C?style=for-the-badge&logo=python&logoColor=white" />
  <img src="https://img.shields.io/badge/C-00599C?style=for-the-badge&logo=c&logoColor=white" />
  
</div>

<hr />

### Front-end
<div>
  <img src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white" />
  <img src="https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white" />
  <img src="https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB" />
  <img src="https://img.shields.io/badge/React_Router-CA4245?style=for-the-badge&logo=react-router&logoColor=white" />
  <img src="https://img.shields.io/badge/Redux-593D88?style=for-the-badge&logo=redux&logoColor=white" />
  <img src="https://img.shields.io/badge/Bootstrap-563D7C?style=for-the-badge&logo=bootstrap&logoColor=white" />
  <img src="https://img.shields.io/badge/Jest-323330?style=for-the-badge&logo=Jest&logoColor=white" />
  <img src="https://img.shields.io/badge/testing%20library-323330?style=for-the-badge&logo=testing-library&logoColor=red" />

  
<hr />

### Back-end
<div>
  <img src="https://img.shields.io/badge/TypeScript-000?style=for-the-badge&logo=typescript" />
  <img src="https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java" />
  <img src="https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python" />
  <img src="https://img.shields.io/badge/MySQL-E34F26?style=for-the-badge&logo=mysql">
  <img src="https://img.shields.io/badge/-Postgres-000?style=for-the-badge&logo=postgresql" />
  <img src="https://img.shields.io/badge/-Docker-000?style=for-the-badge&logo=docker" />
  <img src="https://img.shields.io/badge/Jest-323330?style=for-the-badge&logo=Jest&logoColor=white" />
  <img src="https://img.shields.io/badge/testing%20library-323330?style=for-the-badge&logo=testing-library&logoColor=red" />

### Ferramentas
<div>
  <img src="https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white" />
  <img src="https://img.shields.io/badge/eslint-3A33D1?style=for-the-badge&logo=eslint&logoColor=white" />
  <img src="https://img.shields.io/badge/Linux-E34F26?style=for-the-badge&logo=linux&logoColor=black" />
  <img src="https://camo.githubusercontent.com/4004b2f7fa33c1cd04eef3e56a050c29463f9d613d00506464a4151edfca3d73/68747470733a2f2f736b696c6c69636f6e732e6465762f69636f6e733f693d6d7973716c" alt="jest" width="40" height="40" data-canonical-src="https://skillicons.dev/icons?i=mysql" style="max-width: 100%;">
<img src="https://camo.githubusercontent.com/e8fc9a2839603607b2fff572f049610924d4875486945f9556b8a015c68bcefd/68747470733a2f2f736b696c6c69636f6e732e6465762f69636f6e733f693d646f636b6572" alt="jest" width="40" height="40" data-canonical-src="https://skillicons.dev/icons?i=docker" style="max-width: 100%;">
</div>
- 📫 How to reach me:<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href = "https://www.facebook.com/alex.resende.165/"> <img src = "https://cdn1.iconfinder.com/data/icons/logotypes/32/square-facebook-256.png" height= 30px width = 30px></a>&nbsp;&nbsp;
<a href = "https://www.instagram.com/alexrmachado86/"><img src = "https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white"></a>&nbsp;&nbsp;
<a href = "https://www.linkedin.com/in/alexresende86/"><img src="https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white"></a>&nbsp;&nbsp;
