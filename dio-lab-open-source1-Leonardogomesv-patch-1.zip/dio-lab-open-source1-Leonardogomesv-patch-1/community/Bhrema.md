## 👋 Welcome to my profile!

<p align="justify"> ✋Olá! Meu nome é Bruno e sou estudante de Engenharia de Software na PUCPR. Sou apaixonado por tecnologia e gosto de explorar vários aspectos do desenvolvimento de software.<strong> Estudando Ciência de Dados e Desenvolvimento Web </p>

### Conecte-se comigo:
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://www.dio.me/users/brunohcrema)[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:brunohcrema@gmail.com)[![LinkedIn](https://img.shields.io/badge/LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/bruno-henrique-crema/)

### Skills:
![JAVA](https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=java&logoColor=white)
![Spring](https://img.shields.io/badge/Spring-6DB33F?style=for-the-badge&logo=spring&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript&logoColor=30A3DC)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc)
![MySQL](https://img.shields.io/badge/MySQL-00000F?style=for-the-badge&logo=mysql&logoColor=white)




### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=bhrema1&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=bhrema1&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)