### Hi there 👋   <img align="right" alt="code-pic" height="150" style="border-radius:50px;" src="https://i.pinimg.com/originals/e4/26/70/e426702edf874b181aced1e2fa5c6cde.gif">
 ##
 #### Welcome to my GitHub profile!
 I’m Brenne 👨‍💻
 
 #### What I’m doing:
- 🚀 I’m currently a student of the 8th period of graduation in Computer Science at UESPI
- 🌱 I’m currently learning Flutter
- 💬 Ask me anything and I’ll try to help you.
- 🔭 Fun fact: I love astronomy and things about space 
#### My technologies stack:
 ##
<div style="display: inline_block"><br>
 
   <img align="center" alt="Brenne-flutter" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/flutter/flutter-original.svg">
  <img align="center" alt="Brenne-DT" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/dart/dart-plain-wordmark.svg"> <img align="center" alt="Brenne-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Brenne-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" alt="Brenne-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Brenne-React" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original.svg">
    <img align="center" alt="Brenne-Csharp" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/csharp/csharp-original.svg">
   <img align="center" alt="Brenne-PS" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/postgresql/postgresql-plain.svg">
  <img align="center" alt="Brenne-MS" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-plain.svg">
  

</div>
 
 #### My stats:
  ##
  <a href="https://github.com/Brennez/">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=Brennez&show_icons=true&theme=algolia&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Brennez&layout=compact&langs_count=7&theme=algolia"/>
</div>

#### 📥 How to find me:
<div>
  <a href = "mailto:tchalisantos40@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%230077B5?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/tchalisson-brenne-27911421b/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
  <a href="https://github.com/Brennez" target="_blank"><img src="https://img.shields.io/badge/-GitHub-%230077B5?style=for-the-badge&logo=GitHub&logoColor=white" target="_blank"></a> 
<div/>
 

