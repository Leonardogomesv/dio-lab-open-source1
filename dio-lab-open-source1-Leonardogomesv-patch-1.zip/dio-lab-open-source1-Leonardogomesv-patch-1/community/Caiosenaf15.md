# Caio Sena
Estudante de Sistemas de Informação

### Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-0CB1F2?style=for-the-badge)](https://web.dio.me/users/Caiofreitas15/)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-FFF?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/caio-sena-freitas-ab1005277/)
[![GitHub](https://img.shields.io/badge/GitHub-ffffff?style=for-the-badge&logo=github&logoColor=000)](https://github.com/Caiosenaf15)


### Habilidades
![HTML5](https://img.shields.io/badge/HTML-ffffff?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-ffffff?style=for-the-badge&logo=css3&logoColor=30A3DC)
![JavaScript](https://img.shields.io/badge/JavaScript-ffffff?style=for-the-badge&logo=javascript&logoColor=FACE3C)
[![Git](https://img.shields.io/badge/Git-ffffff?style=for-the-badge&logo=git)](https://git-scm.com/doc) 
[![GitHub](https://img.shields.io/badge/GitHub-ffffff?style=for-the-badge&logo=github&logoColor=000)](https://docs.github.com/)

### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Caiosenaf15&theme=transparent&bg_color=FFF&border_color=0CB1F2&show_icons=true&icon_color=0CB1F2&title_color=E13B89&text_color=212121&hide=stars)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Caiosenaf15&layout=compact&bg_color=FFF&border_color=0CB1F2&title_color=E13B89&text_color=212121)
[![GitHub Streak](https://streak-stats.demolab.com/?user=Caiosenaf15&theme=bear&background=FFF&border=0CB1F2&dates=212121)](https://git.io/streak-stats)


### Meus Principais Desafios de Projeto DIO
[![Repo HTML-CSS](https://github-readme-stats.vercel.app/api/pin/?username=Caiosenaf15&repo=HTML-CSS&bg_color=FFF&border_color=0CB1F2&show_icons=true&icon_color=0CB1F2&title_color=E13B89&text_color=212121)](https://github.com/Caiosenaf15/HTML-CSS)
[![Repo DIO Git Github](https://github-readme-stats.vercel.app/api/pin/?username=Caiosenaf15&repo=dio-lab-open-source&bg_color=FFF&border_color=0CB1F2&show_icons=true&icon_color=0CB1F2&title_color=E13B89&text_color=212121)](https://github.com/Caiosenaf15/dio-lab-open-source)

### Meus Principais Projetos
<table>
  <thead>
    <tr align="left">
      <th>Título</th>
      <th>Link</th>
    </tr>
  </thead>
  <tbody align="left">
    <tr>
      <td>Site Cordel Moderno  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp</td>
      <td align="center">
        <a href="https://caiosenaf15.github.io/HTML-CSS/CursoEmVideo/desafios/Módulo%202/d012/d012.html">
           <img align="center" alt="Ver Projeto" src="https://img.shields.io/badge/Ver%20Projeto-0CB1F2?style=for-the-badge">
        </a>
      </td>
    </tr>
    <tr>
      <td>Site Android</td>
      <td align="center">
        <a href="https://caiosenaf15.github.io/HTML-CSS/CursoEmVideo/desafios/Módulo%202/d010/d010.html">
           <img align="center" alt="Ver Projeto" src="https://img.shields.io/badge/Ver%20Projeto-E13B89?style=for-the-badge">
        </a>
      </td>
    </tr>
    <tr>
      <td>Projeto Redes Sociais</td>
      <td align="center">
        <a href="https://web.dio.me/articles/destrave-seu-primeiro-desafio-de-codigo">
           <img align="center" alt="Ver Projeto" src="https://img.shields.io/badge/Ver%20Projeto-0CB1F2?style=for-the-badge">
        </a>
      </td>    
    </tr>
  </tbody>
  <tfoot></tfoot>
</table>