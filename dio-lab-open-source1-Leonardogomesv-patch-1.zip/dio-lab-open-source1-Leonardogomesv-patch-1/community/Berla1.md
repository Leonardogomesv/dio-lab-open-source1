[![Typing SVG](https://readme-typing-svg.herokuapp.com/?color=ffffff&size=35&center=true&vCenter=true&width=1000&lines=Olá,+Seja+Bem-Vindo!+:%29)](https://git.io/typing-svg)
# 👨🏽  **Gustavo Berlanga** 
### Tenho 18 anos de idade e estou terminando o ensino médio.

# *Sobre mim:*
- 👨🏾‍🎓 Estudante de programação
- 👨‍💻 Começando a cursar Engenharia de Software na FIAP
- 🌎 Inglês avançado 

<br>

# 🔗 *Conecte-se comigo:*


[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/gustavo-berlanga-915467164/)


[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/berla1__/)

[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=007BFF)](mailto:gustavoberlanga312@gmail.com)

<br>


# 📚 _Tecnologias em estudo:_

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python) ![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5) ![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)

[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc) [![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=GitHub&logoColor=0E76A8)](https://github.com/AdrianaCCampos)

# 🤹🏼 _Soft skills_

![Static Badge](https://img.shields.io/badge/Trabalho_em_equipe-badge?color=rgb(159%2C%200%2C%200))

![Static Badge](https://img.shields.io/badge/Cmunicativo-badge?color=rgb(215%2C%20125%2C%202))

![Static Badge](https://img.shields.io/badge/Proativo-badge?color=rgb(9%2C%20125%2C%20203))

![Static Badge](https://img.shields.io/badge/Adapt%C3%A1vel-badge?color=rgb(62%2C%20158%2C%202))
