# AlissonTZ
Olá! Eu sou o Alisson, tenho 24 anos e sou estudante de Análise e Desenvolvimento de sistemas.

## Conecte-se comigo
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=fff)](https://github.com/AlissonTZ)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/alissontuze7k/)

## Habilidades
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=fff)](https://docs.github.com/)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=fff)](https://git-scm.com/doc)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c) 

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=octoeli&theme=transparent&bg_color=000&border_color=fff&show_icons=true&icon_color=fff&title_color=fff&text_color=fff&hide_title=true&hide=stars)

## Minhas Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AlissonTZ&repo=dio-lab-open-source&bg_color=000&border_color=fff&show_icons=true&icon_color=fff&title_color=fff&text_color=fff)](https://github.com/AlissonTZ/dio-lab-open-source)