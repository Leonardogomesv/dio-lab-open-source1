# Caio Bonalume

### Sobre
Iniciei carreira profissional como designer gráfico, em seguida como modelador 3D. Mudei radicalmente de carreira para empreendedor, tive uma empresa de limpeza e manutenção de piscinas por 8 anos.

### Habilidades
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc) 
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)
![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)
![TypeScript](https://img.shields.io/badge/TypeScript-000?style=for-the-badge&logo=typescript)

![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=CaioBonalume&hide_progress=true&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=CaioBonalume&repo=nutri-next&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/CaioBonalume/nutri-next)

[![GitHub Streak](https://streak-stats.demolab.com/?user=CaioBonalume&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)

## Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-000?style=for-the-badge)](https://dio.me/users/caka_bonalume) 
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=fff)](https://www.linkedin.com/in/caio-bonalume-87b1974b/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=fff)](https://github.com/CaioBonalume)