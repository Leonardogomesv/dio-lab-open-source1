# Bianca Rezende

## Conecte-se Comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/bianca-rezende-845b4461/)

## Habilidades
![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)

## GitHub Status
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

## Minhas Contribuições
[![GitHub Streak](https://streak-stats.demolab.com/?user=SEUUSERNAME&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)