![octocat-1692319884575](https://github.com/Biiars00/Biiars00/assets/105985047/9e98c42e-0270-4e95-b9ba-1d67f149d4ef)

<h3 align="center">Olá, seja bem-vindo(a)!</h3>

  Aqui você encontra um pouco sobre os meus estudos e projetos.

# Beatriz Ribeiro
Graduanda em Análise e Desenvolvimento de Sistemas, sou apaixonada por tecnologia e sigo em busca de constante aprendizado.

### Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-320032?style=flat)](https://web.dio.me/users/biiaribeiro60?tab=skills)
[![E-mail](https://img.shields.io/badge/Gmail-320032?style=flat&logo=gmail&logoColor=red)](biiaribeiro60@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-320032?style=flat&logo=linkedin&logoColor=blue)](https://www.linkedin.com/in/beatriz-ribeiro-dev)
[![Github](https://img.shields.io/badge/-Github-320032?style=flat&logo=github&logoColor=white)](https://github.com/Biiars00)

### Habilidades
![HTML5](https://img.shields.io/badge/HTML-320032?style=flat&logo=html5&logoColor=orange)
![CSS3](https://img.shields.io/badge/CSS3-320032?style=flat&logo=css3&logoColor=blue)
![JavaScript](https://img.shields.io/badge/JavaScript-320032?style=flat&logo=javascript&logoColor=yellow)
![Typescript](https://img.shields.io/badge/Typescript-320032?style=flat&logo=typescript&logoColor=blue)
[![Git](https://img.shields.io/badge/Git-320032?style=flat&logo=git&logoColor=red)](https://git-scm.com/doc)
![Python](https://img.shields.io/badge/Python-320032?style=flat&logo=python&logoColor=yellow)
![NodeJS](https://img.shields.io/badge/Node.js-320032?style=flat&logo=node.js&logoColor=green)
![MongoDB](https://img.shields.io/badge/MongoDB-320032?style=flat&logo=mongodb&logoColor=green)
![MySQL](https://img.shields.io/badge/MySQL-320032?style=flat&logo=mysql&logoColor=blue)
![Docker](https://img.shields.io/badge/Docker-320032?style=flat&logo=docker&logoColor=blue)

### Aprendendo
![Java](https://img.shields.io/badge/Java-320032?style=flat&logo=openjdk&logoColor=yellow)
![Angular](https://img.shields.io/badge/Angular-320032?style=flat&logo=angular&logoColor=red)

### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Biiars00&theme=transparent&bg_color=320032&border_color=BD1550&show_icons=true&icon_color=BD1550&title_color=BD1550&text_color=FFF)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Biiars00&layout=compact&bg_color=320032&border_color=BD1550&title_color=BD1550&text_color=FFF)