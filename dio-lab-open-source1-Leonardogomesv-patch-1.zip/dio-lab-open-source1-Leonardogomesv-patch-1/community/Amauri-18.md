# Welcome! I'm Amauri Pereira.

My name is Amauri Pereira, 30 years old and i have a degree in Production Engineering.

### Skills:

![HTML](https://img.shields.io/badge/HTML-%23282C34.svg?style=for-the-badge&logo=html5)
![CSS](https://img.shields.io/badge/CSS-%23282C34.svg?style=for-the-badge&logo=css3)
![JavaScript](https://img.shields.io/badge/JavaScript-%23282C34.svg?style=for-the-badge&logo=javascript)
![C](https://img.shields.io/badge/C-%23282C34.svg?style=for-the-badge&logo=c)


### Get in touch:

[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/amauri-pereira-180b19289/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://github.com/Amauri-18)


