# Contribuição em um projeto open source da Elidiana;
Minha contribuição para o projeto do curso.

Como não tenho conhecimento nenhum e estou começando do zero, apenas irei fazer um readme simples.



## 🎀 Curso Java da DIO

[Digital Inovation One](https://web.dio.me/)


Quero deixar tambem um link util para ajudar os colegas do java, com codigos pré prontos.


[Java Sheet](https://overapi.com/java)
