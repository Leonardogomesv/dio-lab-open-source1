# Olá 👋

Meu nome é Bruna Vieira, estou aventurando pelo mundo da tecnologia, dando os primeiros passos em Python, mas com grande interesse em Ciências de Dados.

## 👩‍💻 Estudos

- Atualmente estou aprendendo Santander Bootcamp 2023 - Ciências de Dados com Python, na plataforma [DIO](https://web.dio.me/home)
- MBA em Gestão Financeira Estratégica Empresarial, na [Universidade Anhanguera Uniderp](https://www.uniderp.com.br/)
- Bacharel em Ciências Contábeis, na [Universidade Federal do Rio Grande](https://www.furg.br/)

## Conecte-se Comigo

[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=007BFF)](mailto:brunarvieiraa90@gmail.com)
[![GitHub](https://img.shields.io/badge/GitHbt-000?style=for-the-badge&logo=github&logoColor=white)](+https://github.com/BruhRV)