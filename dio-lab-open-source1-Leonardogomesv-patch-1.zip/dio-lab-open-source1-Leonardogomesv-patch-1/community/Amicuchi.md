# Olá, eu sou o Anderson! 👋

### Seja bem vindo(a) ao meu perfil!


## 🚀 Sobre mim

Sou estudante de Engenharia da Computação.

Estou fazendo o Bootcamp de Ciência de Dados do Santander.

Gosto de desenvolvimento Fron-end e sou um apaixonado por resolução de problemas.


## ⚡️Ainda sobre mim

👩‍💻 Trabalho atualmente como Desenhista Técnico na Secretaria de Segurança Pública.

👯‍♀️ Procuro colaborar em projetos que utilizem HTML5, CSS3, Javascript, React, Python 

💬 Gosto de falar de Tecnologia, Netflix, Muaythai e "unas cositas mas!"

## 🛠 Stack:
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

### Estou aprendendo: 
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

### Alguns frameworks:
![Bootstrap](https://img.shields.io/badge/Bootstrap-000?style=for-the-badge&logo=Bootstrap)
![Node.JS](https://img.shields.io/badge/Node.JS-000?style=for-the-badge&logo=Node.js) 
![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)

### Soft Skills
- Proativo
- Organizado
- Empático


## GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Amicuchi&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Amicuchi&layout=compact&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Principais Projetos

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=SEUUSERNAME&repo=SEUREPOSITORIO&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/SEUUSERNAME/SEUREPOSITORIO)

[![Donate](https://github-readme-stats.vercel.app/api/pin/?username=amicuchi&repo=FCamara_Squad22&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Amicuchi/FCamara_Squad22)
[![PhotoPet](https://github-readme-stats.vercel.app/api/pin/?username=amicuchi&repo=PhotoPet&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Amicuchi/PhotoPet)
[![21 Days To Code](https://github-readme-stats.vercel.app/api/pin/?username=amicuchi&repo=21DaysToCode&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Amicuchi/21DaysToCode)
[![ToDo App](https://github-readme-stats.vercel.app/api/pin/?username=amicuchi&repo=todo-app&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Amicuchi/todo-app)
[![Music Player](https://github-readme-stats.vercel.app/api/pin/?username=amicuchi&repo=MusicPlayer&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Amicuchi/MusicPlayer)
[![Tic Tac Toe](https://github-readme-stats.vercel.app/api/pin/?username=amicuchi&repo=TicTacToe&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Amicuchi/TicTacToe)


## 🔗 Onde me encontrar

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://github.com/Amicuchi/Amicuchi)
[![e-mail](https://img.shields.io/badge/email-000?style=for-the-badge&logo=ko-fi&logoColor=red)](mailto:AndersonAmicuchi@gmail.com)
[![GitHub](https://img.shields.io/badge/github-000?style=for-the-badge&logo=ko-fi&logoColor=green)](https://github.com/Amicuchi)
