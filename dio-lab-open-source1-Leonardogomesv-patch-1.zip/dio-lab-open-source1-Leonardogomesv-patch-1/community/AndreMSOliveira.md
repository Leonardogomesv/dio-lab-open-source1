# André Oliveira
<p> Me chamo André Oliviera, sou novo na área de programação, trabalho há 15 anos no ramo de telecomunicações, resolvi tentar uma nova área, me interessei pela programação e até o momento não me arrependi da escolha, sei que tenho muito a aprender e espero que possam me ajudar, assim como a DIO está me ajudando. 
</p>

## Conecte-se Comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/andr%C3%A9-oliveira-47ab35288/)

[![Instagram](https://img.shields.io/badge/Instragram-000?style=for-the-badge&logo=Instagram)](https://www.instagram.com/andre_ms_oliveira/)

[![Github](https://img.shields.io/badge/Github-357?style=for-the-badge&logo=Github&logoColor=fffff)](https://github.com/AndreMSOliveira)

## Habilidades

![HTML5](https://img.shields.io/badge/HTML-000?style=for-the-badge&logo=html5&logoColor=30A3DC)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc) 
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)

### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AndreMSOliveira&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AndreMSOliveira&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

### Meus Principais Desafios de Projeto DIO
[![Repo DIO Git GitHub](https://github-readme-stats.vercel.app/api/pin/?username=elidianaandrade&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/elidianaandrade/dio-lab-open-source)

<p> "Isso é tudo pessoal" </p>

