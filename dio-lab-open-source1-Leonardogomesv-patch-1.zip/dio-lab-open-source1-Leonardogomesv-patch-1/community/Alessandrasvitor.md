
# Alessandra Vitor
## Bem vindo ao meu Perfil.
Sou desenvolvedora fullstack atuando atualmente com java e angular.


## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/alessandra-silva-vitor/)    [![GitHub](https://img.shields.io/badge/github-%23121011.svg?style=for-the-badge&logo=github&logoColor=white)](https://github.com/Alessandrasvitor) [![Perfil DIO](https://img.shields.io/badge/DIO-000?style=for-the-badge)](https://www.dio.me/users/alessandrasilvav)

## Tecnologias
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java) ![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)

![TypeScript](https://img.shields.io/badge/TypeScript-000?style=for-the-badge&logo=typescript) ![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react) ![Angular](https://img.shields.io/badge/Angular-000?style=for-the-badge&logo=angular&logoColor=C3002F)

## Status
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Alessandrasvitor&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Alessandrasvitor&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)


