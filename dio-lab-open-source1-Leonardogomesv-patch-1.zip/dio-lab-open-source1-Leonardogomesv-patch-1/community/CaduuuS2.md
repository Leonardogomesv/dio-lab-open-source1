<div>
    <h1>Bem vindo(a) ao meu Perfil.</h2>
    <h2>Oi! Meu nome é Carlos Eduardo, mas pode me chamar de Cadu! 👋 </h1>
    <p> Atualmente sou um entusiasmado e apaixonado estudante desse maravilhoso mundo da tecnologias e suas incríveis inovacões que resolvem problemas reais de pessoas, trazendo bem estar e tranquilidade. Dentre as inúmeras áreas da tecnologia, me aprofundo na programação, mais especificamente a back-end, conhecendo e utilizando o framework .Net e a linguagem C#, além da área de QA, esta última visando compreender e construir boas soluções. Também busco enteder o framework Scrum, pois o trabalho em equipe é fundamental para que possamos desenvolver os grandes projetos que nos ajudaram a solucionar problemas reais de pessoas reais, trazendo assim bem estar às pessoas, elemento definidor de uma boa tecnologia.  
    </p>
</div>
<div>
    <h2>Conecte-se comigo</h2>
   <a href="https://www.linkedin.com/in/carlos-eduardo-s-oliveira-0528a01a0/" target="_blank"></a> 
   
</div>
<br>
<div align="center">
  <a href="https://github.com/CaduuuS2">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=CaduuuS2&show_icons=true&theme=tokyonight&include_all_commits=true&count_private=true"/>
</div>
<br>
<br>
