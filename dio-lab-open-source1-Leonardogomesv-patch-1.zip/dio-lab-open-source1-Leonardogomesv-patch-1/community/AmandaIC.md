# Amanda Ilucenki Ceola

<p align="justify">Sou estudante de Análise e Desenvolvimento de Sistemas com um entusiasmo especial pelo back-end. Estou determinada a aprimorar minhas habilidades em programação e me especializar na linguagem Java. Minha jornada na programação começou com a curiosidade de entender como os sistemas funcionam nos bastidores e como as aplicações podem ser otimizadas para desempenho e segurança. À medida que avancei nos estudos, descobri minha paixão pelo desenvolvimento back-end, onde posso projetar e construir sistemas robustos e escaláveis.</p> 

---
## Objetivos

Meu objetivo é me tornar uma desenvolvedora de software altamente competente em Java. Estou comprometida com o aprendizado contínuo e estou aberta a oportunidades de estágio ou colaboração em projetos que me permitam expandir minhas habilidades.

---
## Conecte-se comigo 


- [![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/amandaceola/)

- [![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=007BFF)](mailto:amandaceola@gmail.com)

- [![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/ilucenskiamanda/)

---
## Estatísticas

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=SEUUSERNAME&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)



