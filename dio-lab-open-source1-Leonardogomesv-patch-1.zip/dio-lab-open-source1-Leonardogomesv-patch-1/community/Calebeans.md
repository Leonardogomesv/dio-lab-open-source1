# Calebe

## Conecte-se Comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/calebe-ribeirodev/)


## Habilidades
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)

![C++](https://img.shields.io/badge/C%2B%2B-000?style=for-the-badge&logo=c%2B%2B&logoColor=00599C)

![R](https://img.shields.io/badge/R-000?style=for-the-badge&logo=R&logoColor=30A3DC)

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

![MySQL](https://img.shields.io/badge/MySQL-000?style=for-the-badge&logo=mysql&logoColor=005C84)

![PostgreSQL](https://img.shields.io/badge/PostgreSQL-000?style=for-the-badge&logo=postgresql)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Calebeans&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Calebeans&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)
