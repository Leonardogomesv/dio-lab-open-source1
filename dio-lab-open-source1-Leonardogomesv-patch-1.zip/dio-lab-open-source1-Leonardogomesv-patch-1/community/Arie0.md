# Olá! Me chamo Ariele, Sejam bem vindos ao meu ponto de partida!🚀

Tenho 24 anos, estou no 6º período do curso Análise de desenvolvimento de sistemas no IFG, e decidi começar na área da tecnologia por curiosidade e paixão, e desde então venho buscando agregar conhecimento participando de cursos e bootcamps.

**META**
Minha meta é me tornar uma desenvolvedora full stack.

**HABILIDADES**
|Nível: Básico|
|--------------|
|Java|
|Inteligência Artificial usando Python|
|HTML-CSS|
|Atualmente aprendendo Flutter e C#|
|Git|
|GitHub|

**SOCIAL**
[Linkedln](https://www.linkedin.com/in/ariele-carla-silva/)


Convido você  Dev, a me acompanhar e se possível contribuir para a minha formação, me orientando e dando aquela força nos meus futuros projetos.