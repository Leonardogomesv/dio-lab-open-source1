
**OPAAA, TUDO CERTO?👋🏽**

----------------
Brandon aqui! Então sempre fui fascinado por programação, e meu primeiro contato com a essa "prática", foi no período do ensino fundamental nos projetos de robótica, podia estar caindo o mundo, mas eu nunca faltava uma aula. 

Conforme o tempo foi passando, as ocasiões foram me distanciando do estudo de programação, inclusive, entrei em algumas faculdades visando apenas o dinheiro, mas graças a deus não me estendi em nenhuma dessas, e agora estou conseguindo estudar o que eu realmente gosto, que sempre foi a programação.

Sei que é uma área realmente desafiadora e que estou arrecém no início, mas o fato de eu estar estudando o que gosto, me deixa realmente feliz!

------------------------------------------------

- Conecte-se comigo

[![Instagram](https://img.shields.io/badge/Instagram-000080?style=for-the-badge&logo=instagram)](https://www.instagram.com/brandon_rosinski51/)

[![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord)](https://www.discord.com/in/brandonr10/)

- OBS: Recentemente comecei a estudar programação

|📍 **Habilidades**|
|--------------|
|Conhecimento básico em lógica de programação|
|Autodidata|
|Resiliente|
|Trabalho em equipe|




|📚 **Áreas atuais de estudo|
|-----------------------------------------------|
|**Fonte** | **Conteúdo** |
| DIO |BOOTCANP - Backend Java |
| Faculdade Unisul |Ciência da computação - cadeira - 1° semestre |
| Youtube |Inglês |



