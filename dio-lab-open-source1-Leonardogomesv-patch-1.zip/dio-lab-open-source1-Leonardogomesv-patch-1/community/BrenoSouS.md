# Ola , me chamo Breno

Uma breve descrição sobre o que esse projeto faz e para quem ele é

Iniciei com a programação faz pouco tempo , estou buscando aprender sempre mais , mesmo que as vezes eu procastine um pouco com isso .Não tenho ainda uma visão clara de qual carreira seguir dentro do mundo de desenvolvimento de software , mas creio que essa questão sera resolvida durante a jornada de aprendizado .Obrigado a você que leu isso ,ate mais.

linguagens :
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
