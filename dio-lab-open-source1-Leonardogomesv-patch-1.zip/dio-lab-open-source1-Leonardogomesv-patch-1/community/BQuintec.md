# Olá, Seja Bem-Vindo! Meu nome é Breno Quintino
### Ao seu dispor 😉
Engenheiro Eletricista/ Eletrônico aspirante a Cientista de Dados

### 🔗 Conecte-se comigo

[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://www.dio.me/users/quintino_breno/)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:quintino.breno@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/eng-bquintino)
## GitHub Status
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=BQuintec&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)


### Repositório Acadêmico
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=BQuintec&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF&hide-title)](https://github.com/BQuintec/dio-lab-open-source)