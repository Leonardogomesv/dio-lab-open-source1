# Andreas Hukuhara Christe

## Bem vindos!!!

 Meu nome é Andreas Hukuhara Christe, tenho 28 anos e sou estudante de Sistemas de Informação pela USP. Sou formado em Engenharia Mecânica pela UNINOVE, concluindo o curso em 2020. Durante essa formação, tive um breve contato com programação, o qual foi crucial para despertar minha paixão por tecnologia. Diante disso, decidi mudar de área para trabalhar efetivamente com resolução de problemas e explorar minha criatividade.
Atualmente, tenho praticado algumas linguagens de programação, como C, Java e JavaScript, assim como alguns frameworks e bibliotecas, como React e Spring, para compor meu portfólio no GitHub. Dito isso, estou em busca de uma vaga de estágio na área de tecnologia, com o objetivo de colocar em prática os conhecimentos adquiridos pessoalmente e na academia

## tecnologias utilizadas

<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-plain.svg" width="30px" margin="3px"/>
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-plain.svg" width="30px"/>
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-plain.svg" width="30px"/>
<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/React-icon.svg/2300px-React-icon.svg.png" width="30px"/>
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-plain.svg" width="30px"/>
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-plain.svg" width="30px"/>

## Estatísticas do github

<div>
<a href="https://github.com/AndreasChriste">
<img height="150px" src="https://github-readme-stats.vercel.app/api?username=AndreasChriste&show_icons=true&theme=midnight-purple&include_all_commits=true&count_private=true"/>
</a>

<a href="https://github.com/AndreasChriste">
<img height="150px" src="https://github-readme-stats.vercel.app/api/top-langs/?username=AndreasChriste&layout=compact&langs_count=7&theme=midnight-purple"/>
</a>
</div>

## contatos

<div>
<a href="mailto:andreash.christe@gmail.com"><img src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
<a href="https://www.linkedin.com/in/andreas-hukuhara-christe/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>   
</div>
<hr/>