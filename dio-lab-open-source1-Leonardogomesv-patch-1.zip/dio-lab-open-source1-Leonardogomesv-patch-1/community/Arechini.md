# Bruno Peruchini

##  Introdução
Olá, meu nome é Bruno, tenho 21 anos e estudo Ciência da Computação na Universidade do Vale do Rio dos Sinos - [Unisinos](https://www.unisinos.br/). Este é o meu primeiro projeto com Markdown, como meu perfil no Github é novo, há poucas informações! Comecei a programar em 2023 e espero construir uma sólida carreira no futuro. Te encontro lá!



## Contato
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/bruno-arechini/)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/are_chini/)

## Linguagens 
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
	![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)
    ![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)

## Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Arechini&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF) 

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Arechini&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)