## Hello 👋 I am Ayrton Lopes

## Bem vindo ao meu Perfil
<p>
Me chamo Ayrton Lopes. Sou uma pessoa que quanto mais aprende mais se apaixona pela tecnologia e a programação.<br>
Estudante em em Sistemas de Informação. 
<br>
técnico em manutenção e suporte em informática.
</p>

## Conecte-se comigo
   [![Gmail](https://img.shields.io/badge/Gmail-FF0000?style=for-the-badge&logo=gmail&logoColor=white)](mailto:ayrtonlopes54@gmail.com)
   [![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/ayrton-lopes/)
  
   
## Habilidades


### Minhas Linguagens de Marcação e Estilos
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
### Linguagens de Programação
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)
### frameworks 
   ![Spring Boot](https://img.shields.io/badge/Spring%20Boot-000?style=for-the-badge&logo=spring)
   ![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)
### Banco De Dados
![MySQL](https://img.shields.io/badge/MySQL-000?style=for-the-badge&logo=mysql)
![SQLite](https://img.shields.io/badge/SQLite-000?style=for-the-badge&logo=sqlite)

## GitHub Status
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Ayrton54&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=FF0000&text_color=FFF)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Ayrton54&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)



