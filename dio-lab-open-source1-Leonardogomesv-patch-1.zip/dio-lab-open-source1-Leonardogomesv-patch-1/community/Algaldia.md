# Diego Jefferson Sodré de Araújo

Programador javascript e node.
Atualmente estudando Java e Angular no [DIO](https://www.dio.me/)

## Redes sociais

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/diego-jefferson-sodr%C3%A9-de-ara%C3%BAjo-09b92b261/)

[![GitHub](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=github)](https://github.com/Algaldia)

## Habilidades

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Git](https://img.shields.io/badge/git-000?style=for-the-badge&logo=git)
![GitHub](https://img.shields.io/badge/github-000?style=for-the-badge&logo=github)
![Node](https://img.shields.io/badge/nodejs-000?style=for-the-badge&logo=nodejs)

## GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Algaldia&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Algaldia&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)