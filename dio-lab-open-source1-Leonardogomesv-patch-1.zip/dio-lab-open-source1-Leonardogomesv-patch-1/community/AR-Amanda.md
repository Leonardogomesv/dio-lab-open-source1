## Oi, sou Amanda! 👋

Sou uma pessoa motivada e apaixonada pela área de tecnologia. Minha constante curiosidade é um dos pilares da minha motivação e desejo de criar soluções inovadoras para desafios complexos. Ultimamente, tenho passado meu tempo melhorando minhas habilidades de aprendizado em JavaScript e Node.js buscando novos desafios. Estou animada e otimista sobre meu futuro na área de TI.

<!--


Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
-->

<div style="display: inline_block"><br>
  <img align="center" alt="Ar-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Ar-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Ar-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
</div>
  
  ##
 
<div> 
   <a href="https://www.linkedin.com/in/amanda-rodrigues-989262a0/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
  
</div>
