<body>
<div style="display: flex; justify-content: center">
<img src="https://readme-typing-svg.herokuapp.com/?color=5430b4&size=35&center=true&vCenter=true&width=500&lines=よろしくお願いします">
<br>
</div>
<h1 style="text-align:center">About me</h1>

<div style="display: flex; justify-content: space-between">
    <div>
        <ul>
        <li style="font-size:16px"> <b>Name</b>: Antonio Henrique Nazar </li>
        <li style="font-size:16px"> <b>Pronouns</b>: He/Him </li>
        <li style="font-size:16px"> I love Omori, Celeste, Artic Monkeys, Nirvana and city pop 🎵🎮 </li>
        <li style="font-size:16px"> I also love rainy days, I find it quite relaxing for programming ✌ </li>
        </ul>
    </div>
    <img src="https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExM3IxaGl0Mmx4aXNxdWNvZHFwNDRhaWY4MjE0c2t0OXowZzNzNXdmdyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/nYtrgEFgarVfPSBJC4/giphy.gif" style="width: 300px; height: 200px">
</div>


<h2> Languages and tools: </h2>

<div>
	<img src="https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5">
    <img src="https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4">
    <img src="https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript">
    <img src="https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python">
    <img src="https://img.shields.io/badge/C-000?style=for-the-badge&logo=c">
    <img src="https://img.shields.io/badge/C%2B%2B-000?style=for-the-badge&logo=c%2B%2B&logoColor=00599C">
</div>
<br>
<div style="display:flex; justify-content:center">
    <img src="https://github-readme-stats.vercel.app/api?username=AntonioNazar&theme=tokyonight&border_color=10007D&show_icons=true&icon_color=30A3DC"
    style="padding:16px">
    <img src="https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AntonioNazar&layout=compact&langs_count=8&theme=tokyonight&hide=HLSL,ShaderLab&border_color=10007D&">
</div>
<hr>
<h3 style="text-align:center">How to reach me</h3>
<br>
<div style="text-align:center">
    <a href="https://www.linkedin.com/in/antonio-henrique-nazar-de-souza-674988250/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
    <a href="https://www.instagram.com/nico_mitsuki_/" target="_blank"><img src="https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white"></a> 
    <a href="https://github.com/AntonioNazar" target="_blank"><img src="https://img.shields.io/badge/GitHub-161B22?style=for-the-badge&logo=github&logoColor=white)"></a> 
    <a href="mailto:nicodeneeko@gmail.com" target="_blank"><img src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white"></a> 