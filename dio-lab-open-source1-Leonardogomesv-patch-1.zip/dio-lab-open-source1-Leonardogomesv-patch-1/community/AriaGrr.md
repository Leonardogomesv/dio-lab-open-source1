# Hello World

Meu nome é Marjorie e nasci em BH, e sou estudante de Ciência da computação na FEI de São Bernardo do Campo - SP.

## 🔗 Conecte-se Comigo

[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/marjorie-luize/)
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-000?style=for-the-badge)](https://web.dio.me/users/marjorieluize?tab=skills)


| **Habilidades**                                                                                                       | **Frameworks**                                                                                         | **Linguagens**                                                                                     |
|-----------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------|
| ![HTML5](https://img.shields.io/badge/HTML-000?style=for-the-badge&logo=html5&logoColor=30A3DC)                       |    | ![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python) |
| ![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=E94D5F)                         
| ![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript&logoColor=30A3DC)       
| [![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc) 
| [![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/) |


### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AriaGrr&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF) 
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AriaGrr&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)