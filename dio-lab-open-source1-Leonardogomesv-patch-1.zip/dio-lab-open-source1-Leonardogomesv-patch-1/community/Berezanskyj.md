# Rafael Berezanskyj
<p> Olá! Seja bem-vindo! Sou Rafael Cardoso Berezanskyj, um estudante de desenvolvimento de sistemas no primeiro ano. Estou animado para compartilhar minha jornada no mundo da programação e meu desejo de me tornar um programador fullstack no futuro.

- 📚 Técnico em desenvolvimento de sistemas.

<h2> Conecte-se comigo!


- [![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](linkedin.com/in/rcberezanskyj/)

- [![Twitter](https://img.shields.io/badge/Twitter-000?style=for-the-badge&logo=twitter)](https://twitter.com/CBerezanskyj)

- [![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/rberezanskyj/)

<h2> ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀



![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Berezanskyj&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)