# Belisnalva Costa
Olá!
Sou estudante da Univesp cursando Bacharelado em Tecnologia da Informação, cursando também na plataforma da DIO.me e através DIO tenho aprendido muito, e agora estou ingressando na área de Ciência de Dados, pela Univesp e Santander Bootcamp Ciências de Dados - PYTHON, 
com a bolsa Becas Santander. \
Ama estudar, e conhecer coisas novas (DESAFIOS). \
Espero aprender cada vez mais e poder ajudar a comunidade.

**META**
Minha meta é me tornar uma grande desenvolvedora de Software
e poder contribuir para a melhoria da vida das pessoas.

## _** HABILIDADES **_
<details open>
| Nível: Básico e intermediário |
|-------------------------------|
| Java                          |
| PostgreSQL                    |
| Linux                         |   
| Python                        |
| Git                           |
| GitHub                        |
| JavaScript                    |
| Banco de Dados                |
| HTML                          | 
</details>

<details open>
| FRAMEWORK  e BIBLIOTECAS |
|--------------------------|
| Spring Boot              |
| AWS                      |
| Pandas                   |   
| Django                   |
</details>

### Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/belisnalva4?tab=skills/)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:principal2.bella-costa@hotmail.com.br)
[![Facebook](https://img.shields.io/badge/Facebook-000?style=for-the-badge&logo=facebook)](https://www.facebook.com/bella.costa.142/)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/belisnalva-costa-pereira/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/BelisnalvaCosta)

## *_Habilidades_*:
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
![AWS](https://img.shields.io/badge/AWS-%23FF9900.svg?style=for-the-badge&logo=amazon-aws&logoColor=30A3DC)
![C++](https://img.shields.io/badge/c++-%2300599C.svg?style=for-the-badge&logo=c%2B%2B&logoColor=white)

[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)

### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=BelisnalvaCosta&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

### Meus Principais Desafios de Projeto DIO
[![Repo DIO Versionamento de Código com Git e GitHub](https://github-readme-stats.vercel.app/api/pin/?username=elidianaandrade&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/BelisnalvaCosta/dio-curso-git-github.git)
[![Repo DIO Roadmaps](https://github-readme-stats.vercel.app/api/pin/?username=digitalinnovationone&repo=roadmaps&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/digitalinnovationone/roadmaps)

### Meus Principais Artigos na DIO
<table>
  <thead>
    <tr align="left">
      <th>Data</th>
      <th>Título</th>
      <th>Link</th>
    </tr>
  </thead>
  <tbody align="left">
    <tr>
      <td>30/06/2023</td>
      <td>Arquitetura de Dados-Python</td>
    <td align="center">
        <a href="https://web.dio.me/articles/arquitetura-de-dados-em-python?back=%2Farticles&page=1&order=oldest">
           <img align="center" alt="Ler Artigo" src="https://img.shields.io/badge/Ler%20Artigo-30A3DC?style=for-the-badge">
        </a>
    </td> 
    </tr>
  <td align="left">
    <tr>    
      <td>07/04/2023</td>    
      <td>Desafio: Criando um Sistema Bancário-Python</td>
    <td align="center">
        <a href="https://web.dio.me/articles/desafio-criando-um-sistema-bancario?back=%2Farticles&page=1&order=oldest">
           <img align="center" alt="Ler Artigo" src="https://img.shields.io/badge/Ler%20Artigo-30A3DC?style=for-the-badge">
        </a>
    </td>
    </tr>
  <td align="left">
    <tr>
      <td>26/07/2022</td>
      <td>Resume Summary-Java</td>
    <td align="center">
      <a href="https://web.dio.me/articles/resume-summary?back=%2Farticles&page=1&order=oldest">
           <img align="center" alt="Ler Artigo" src="https://img.shields.io/badge/Ler%20Artigo-30A3DC?style=for-the-badge">
        </a>
    </td>   
    </tr>
  <tfoot></tfoot>
</table>

---
> A persistência e o auto-controle pode te fazer mais que vencedor: tenha fé e nunca desista dos seus sonhos!! .

— Belisnalva Costa