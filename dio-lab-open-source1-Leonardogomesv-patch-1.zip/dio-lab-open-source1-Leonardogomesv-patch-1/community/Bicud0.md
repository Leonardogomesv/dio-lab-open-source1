# **BICUDO**

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Bicud0&theme=transparent&bg_color=000&border_color=000000&show_icons=true&icon_color=30A3DC&title_color=008000&text_color=00FF7F)

## SOCIAL

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/thalys-caires-2004/)

[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=007BFF)](mailto:thalyscaires@hotmail.com)

[![X](https://img.shields.io/badge/X-000?style=for-the-badge&logo=x)](https://x.com/bicudoT9999)

## Habilidades

![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)