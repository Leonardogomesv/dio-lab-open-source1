## Carlos Vieira

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=github&logoColor=0E76A8)](https://github.com/CVieiraSantos)


## Habilidades
![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)
![TypeScript](https://img.shields.io/badge/TypeScript-000?style=for-the-badge&logo=typescript)
![SqlServer](https://img.shields.io/badge/SqlServer-000?style=for-the-badge&logo=SqlServer)
![Angular](https://img.shields.io/badge/Angular-000?style=for-the-badge&logo=angular&logoColor=C3002F)
![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=C3002F)
![Docker](https://img.shields.io/badge/Docker-000?style=for-the-badge&logo=docker&logoColor=C3002F)


## Github Starts
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=CVieiraSantos&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Minhas contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=CVieiraSantos&repo=SEUREPOSITORIO&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/CVieiraSantos/https://www.github.com/CVieiraSantos/dio-lab-open-source)

