
# Athos Sperber

Olá, tenho 21 anos e atualmente estudo Desenvolvimento de Software Multiplataforma na Fatec Araras. 


## Conecte-se comigo

[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-000?style=for-the-badge)](https://web.dio.me/users/athossperber123) 
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=fff)](https://www.linkedin.com/in/athos-sperber-63016124b/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=fff)](https://github.com/AthosSperber)

## Habilidades

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![flask](https://img.shields.io/badge/Flask-000?style=for-the-badge&logo=flask)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![NodeJS](https://img.shields.io/badge/NodeJS-000?style=for-the-badge&logo=nodejs)


## GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AthosSperber&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

