# Beatriz Da Cruz Freire 

😄 Oi,

Meu nome é Beatriz, sou Bacharel em Educação Física e estudante de Engenharia de Software. Em busca da transição de carreira.

🎯 Gosto muito de desafios! Sempre focada, e doação de 100