<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=9400D3&height=120&section=header"/>

[![Typing SVG](https://readme-typing-svg.herokuapp.com/?color=9400D3&size=35&center=true&vCenter=true&width=1000&lines=HELLO,+My+name+is+Nanya+😊;I'm+23+years+old+🎉;I'm+from+Brazil+(Rio+de+Janeiro)+🌍;Studying+Computer+science+📖;Be+Welcome!🐰+:%29)](https://git.io/typing-svg)


<div align="center">  
  <img width="49%" height="195px" src="https://github-readme-stats.vercel.app/api?username=BotNany&show_icons=true&count_private=true&hide_border=true&title_color=9400D3&icon_color=9400D3&text_color=DDA0DD&bg_color=0d1117" alt="Nany github stats" /> 
  <img width="41%" height="195px" src="https://streak-stats.demolab.com/?user=BotNany&theme=midnight-purple&background=000&border=9400D3&dates=FFF)](https://git.io/streak-stats)" />
</div>


[![Ashutosh's github activity graph](https://github-readme-activity-graph.vercel.app/graph?username=BotNany&bg_color=0d1117&color=9400D3&line=9400D3&point=FF00FF&area=true&hide_border=true)](https://github.com/ashutosh00710/github-readme-activity-graph)


<p align="center">
  <img src="https://github-profile-trophy.vercel.app/?username=BotNany&theme=dracula&row=2&no-bg=true&column=3&margin-w=15&margin-h=15" />
</p>





## Skills
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)
![Photoshop](https://img.shields.io/badge/Adobe%20Photoshop-31A8FF?style=for-the-badge&logo=Adobe%20Photoshop&logoColor=black)
![Lua](https://img.shields.io/badge/Lua-2C2D72?style=for-the-badge&logo=lua&logoColor=white)
![3DS](https://img.shields.io/badge/3DS-D12228?style=for-the-badge&logo=nintendo-3ds&logoColor=white)

## Studying in this moment:
![JavaScript](https://img.shields.io/badge/-JavaScript-0D1117?style=for-the-badge&logo=javascript&labelColor=0D1117)&nbsp;
![Php](https://img.shields.io/badge/-php-0D1117?style=for-the-badge&logo=php&logoColor=purple&labelColor=0D1117)&nbsp; 
![CSS](https://img.shields.io/badge/-CSS-0D1117?style=for-the-badge&logo=CSS3&logoColor=1572B6&labelColor=0D1117)&nbsp;
![AngularJS](https://img.shields.io/badge/AngularJS-0D1117?style=for-the-badge&logo=angularjs&logoColor=white)&nbsp;
![MySQL](https://img.shields.io/badge/mysql-0D1117.svg?style=for-the-badge&logo=mysql&logoColor=white)&nbsp;

<div align="center">



### Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://www.dio.me/users/naianysilvap)

<br><p align="centre"><b>Visitors Count</b></p>  
<p align="center"><img align="center" src="https://profile-counter.glitch.me/{BotNany}/count.svg" /></p> 
<br>
</div>

<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=9400D3&height=120&section=footer"/>



