## Olá, eu sou Ana Beatriz Rodrigues ***(Beatriz-Rodriguesx)*** 🌺


### Estatísticas no GitHub 🚀
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Beatriz-Rodriguesx&theme=transparent&bg_color=000&border_color=6B8E23&show_icons=true&icon_color=00ff00&title_color=008000&text_color=FFF)


### Projetos em Destaques 🎸
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Beatriz-Rodriguesx&bg_color=000&border_color=6B8E23&title_color=008000&text_color=FFF)
