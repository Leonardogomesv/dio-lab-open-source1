# Caique Resende

Olá! Seja bem-vindo ao meu perfil.

Tenho 28 anos, sou formado em Engenharia Química, pela UFMG, e, no tempo livre, gosto muito de jogos online competitivos. 

Atuo como Engenheiro de Dados, na ATRA Informática, e já trabalhei como Analista de Dados, na Saraiva Educação.

## Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/caique-resende/) 

## Habilidades
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python) ![Static Badge](https://img.shields.io/badge/PostgreSQL-000?style=for-the-badge&logo=postgresql) ![Static Badge](https://img.shields.io/badge/Excel-000?style=for-the-badge&logo=microsoftexcel) ![Static Badge](https://img.shields.io/badge/Informatica%20Cloud-000?style=for-the-badge&logo=informatica)


## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=CaiqueResende&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)