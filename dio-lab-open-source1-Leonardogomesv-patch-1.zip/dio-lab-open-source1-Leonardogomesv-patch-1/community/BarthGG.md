# Gabriel Bartholomeu
```
✈️ Piloto de Avião

🧑‍💻 Amante da Tecnologia
```

## 💻Redes Sociais
```
Conecte-se comigo
```
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/gabriel-augusto-bartholomeu-a28287214/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/gabriel_barthh/)

## Card
```
Começando a jornada na Tecnologia (por isso está vazio!)
```


![GitHub Stats](https://github-readme-stats.vercel.app/api?username=BarthGG&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)




