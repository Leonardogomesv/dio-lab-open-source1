## Olá, meu nome é Álefe
### Desenvolvedor Fullstack!

<div style="display: inline_block">
 <img height=180em style="display: flex, flex: 1" alt="Alefe's GitHub Stats" src="https://github-readme-stats-sigma-five.vercel.app/api?username=AlefeSk8&show_icons=true&theme=tokyonight" />
 <img height=180em width=300px alt="Alefe's GitHub Stats" src="https://github-readme-stats.vercel.app/api/top-langs/?username=AlefeSk8&layout=compact&langs_count=8&theme=tokyonight" />
</div>
 
<div style="display: inline_block"><br>
  <img align="center" alt="Álefe-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Álefe-Ts" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/typescript/typescript-plain.svg">
  <img align="center" alt="Álefe-React" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original.svg">
  <img align="center" alt="Álefe-Node" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/nodejs/nodejs-original.svg">
  <img align="center" alt="Álefe-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Álefe-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" alt="Álefe-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/csharp/csharp-original.svg">
  <img align="center" alt="Álefe-Docker" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/docker/docker-plain-wordmark.svg">
  <img align="center" alt="Álefe-Postgres" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/postgresql/postgresql-plain-wordmark.svg">
</div>
  
  ##
 
<div>
 <a href="https://alefesk8.github.io" target="_blank"><img src="https://img.shields.io/badge/website-000000?style=for-the-badge&logo=About.me&logoColor=white" target="_blank"></a>
 <a href="https://www.linkedin.com/in/alefe-kouichi-araujo-mikawa/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>
 <a href="https://www.instagram.com/alefe_sk8/" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
 <a href = "mailto:alefe_sk8@hotmail.com"><img src="https://img.shields.io/badge/-email-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
</div>

<a href="https://github.com/AlefeSk8/Spotify-Clone-Next.js">
  <img align="center" src="https://github-readme-stats.vercel.app/api/pin/?username=AlefeSk8&theme=tokyonight&repo=Spotify-Clone-Next.js" />
</a>
<a href="https://github.com/AlefeSk8/MyFirstGame-Unity">
  <img align="center" src="https://github-readme-stats-sigma-five.vercel.app/api/pin/?username=AlefeSk8&theme=tokyonight&repo=MyFirstGame-Unity" />
</a>
