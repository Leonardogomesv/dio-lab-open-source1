## Hi there, i'm Arthur Nunes 👋.

> I'm a Java Developer from Brazil.

- 🌱 I’m currently learning **Java**.
- 💬 Ask me about **Anything**, I am happy to help :smile:.
- 🧗 I try to: **Go beyond and push the bounds**.
- ⚡ I **Love** connecting with different people :raised_hands: .
- 📫 How to reach me: <a href="https://www.linkedin.com/in/arthur-nunes-pereira-35725a110/" target="_blank"><img align="center" height="25" src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>

## <img src="https://img.icons8.com/nolan/25/computer.png"/> Technologies
<div style="display: inline_block"><br>
  <img align="center" alt="Arthur-Java" height="32" width="42" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg"> 
  <img align="center" alt="Arthur-MySql" height="34" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mysql/mysql-original-wordmark.svg"">
  <img align="center" alt="Arthur-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Arthur-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" alt="Arthur-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Arthur-Git" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/git/git-original.svg">
  <img align="center" alt="Arthur-GitHub" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/github/github-original.svg">
  <img align="center" alt="Arthur-Postman" height="30" width="30" src="https://www.vectorlogo.zone/logos/getpostman/getpostman-icon.svg">
</div>
                                                                                                                                        
## <img src="https://img.icons8.com/nolan/26/github.png"/> Github Stats
![Arthur's github stats](https://github-readme-stats.vercel.app/api?username=ArthurNunesPereira&show_icons=true&theme=tokyonight&include_all_commits=true) ![Arthur's github stats](https://github-readme-stats.vercel.app/api/top-langs/?username=ArthurNunesPereira&theme=tokyonight&layout=compact)

<!-- Isso é um comentário
**ArthurNunesPereira/ArthurNunesPereira** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->