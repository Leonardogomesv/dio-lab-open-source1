# Olá! Me chamo Bruna, Sejam bem vindos ao meu mundinho de aspirante a Dev HAHA!🚀

Meu nome é Bruna, tenho 25 anos e estou atualmente no segundo semestre de Análise e Desenvolvimento de Sistemas. Durante toda minha trajetória profissional, trabalhei em setores administrativos, mas a vida me reservou uma surpresa fascinante ao me apresentar ao mundo da tecnologia. Desde que conheci esse universo incrível, minha paixão por ele só tem crescido, e estou em uma emocionante transição de carreira.
**META**
Minha meta é me tornar uma Desenvolvedora Front-End.

**HABILIDADES**
|Nível: Básico|
|--------------|
|Python|
|Javascript|
|HTML|
|CSS|
|Git|
|GitHub|
|SQL|

**SOCIAL**
[Linkedln](https://www.linkedin.com/in/brunagabriela23/)
[Gmail](bruna.gabriela.pereira98@gmail.com)

Agora que você chegou até aqui, gostaria de lhe convidar para me acompanhar no próximo passo da minha jornada. Seria incrível contar com a sua companhia, orientação e até mesmo contribuição para a minha formação contínua. Se você puder oferecer sua orientação e apoio aos meus projetos futuros, isso significaria muito para mim. Juntos, podemos alcançar realizações ainda maiores.
