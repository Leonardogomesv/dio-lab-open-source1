## 👋 Olá, eu sou a Alyda Lourena !
- 💻 Full-stack web developer,
- 🪗 Nordestina, Alagoana.
- 🎵 Apaixonada por Música.
- 🪐 Fascinada por Astronomia.

</br>

## 📊 GitHub Stats

<div align="center">
  <a href="https://github.com/AlydaLourena">
  <img height="160rem" src="https://github-readme-stats.vercel.app/api?username=alydalourena&show_icons=true&theme=synthwave&include_all_commits=true&count_private=true"/>
  <img height="160rem" src="https://github-readme-stats.vercel.app/api/top-langs/?username=alydalourena&layout=compact&langs_count=7&theme=dracula"/>
</div>

</br>

## ⚡ Habilidades

<div style="display: inline_block"><br>
  <img align="center" alt="Aly-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
   <img align="center" alt="Aly-TS" height="30" width= 40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/typescript/typescript-original.svg"/>
  <img align="center" alt="Aly-React" height="30" width= 40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original.svg"/>
  <img align="center" alt="Aly-HTML"  height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Aly-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" alt="Aly-Python" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" />
     <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-plain.svg" height="30" width="40"
  <img align="center" alt="Aly-sql" height="30" width= 40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg"/>
  <img align="center" alt="Aly-MySQL" height="30" width= 40" src="https://img.icons8.com/color/48/000000/mysql-logo.png"/>
  <img align="center" alt="Aly-JAVA" height="30" width= 40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg"/>
   <img align="center" alt="Aly-TS" height="30" width= 40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/nodejs/nodejs-original.svg"/>
   <img align="center" alt="Aly-docker" height="30" width= 70" src="https://img.shields.io/badge/-Docker-05122A?style=flat&logo=docker"/>

   </br>

   ## Conecte-se comigo em minhas Redes Sociais :
 
<div> 
  <a href="https://www.instagram.com/alydalourena/" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/alyda-lourena-365289202/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
 
</div>