<!DOCTYPE html>
<html>

<head>
  <title>Meu Perfil</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }
  </style>
</head>

<body>
  <div>
    <h2>Oi, Meu nome é Alan 🐢</h2>

    Sou estudante de Sistemas de Informação na UAST-UFRPE. Atualmente, estou concentrando meus estudos no desenvolvimento full-stack, com ênfase em tecnologias como .NET e React. Estou empolgado em aprimorar minhas habilidades nesses campos e construir soluções inovadoras!
  </div>

  <div style="text-align: center;">
    <h2>Habilidades</h2>
    <img src="https://img.shields.io/badge/C%23-239120?style=for-the-badge&logo=c-sharp&logoColor=white" alt="C#" />
    <img src="https://img.shields.io/badge/.NET-5C2D91?style=for-the-badge&logo=.net&logoColor=white" alt=".NET" />
    <img src="https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=java&logoColor=white" alt="Java" />
    <img src="https://img.shields.io/badge/Python-14354C?style=for-the-badge&logo=python&logoColor=white" alt="Python" />
    <img src="https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black" alt="JavaScript" />
    <img src="https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB" alt="React" />
  </div>

  <div style="text-align: center;">
    <h2>GitHub Stats</h2>
    <img width="49%" height="195px" src="https://github-readme-stats.vercel.app/api?username=AlannTorres&show_icons=true&theme=github_dark&include_all_commits=true&count_private=true&border_color=0D1117"
      alt="Estatísticas do GitHub de Alan Torres" />
    <img width="41%" height="195px" src="https://github-readme-stats.vercel.app/api/top-langs/?username=AlannTorres&layout=compact&langs_count=7&theme=github_dark&border_color=0D1117"
      alt="Linguagens mais usadas de Alan Torres" />
  </div>

  <div style="text-align: center;">
    <h1>Conecte-se comigo</h1>
    <a href="https://www.linkedin.com/in/alann-torres/"><img src="https://img.shields.io/badge/LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white"
        alt="LinkedIn" /></a>
    <a href="https://github.com/AlannTorres"><img src="https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=fff"
        alt="GitHub" /></a>
  </div>

  <img width="100%" src="https://capsule-render.vercel.app/api?type=waving&color=483D8B&height=120&section=footer" />
</body>

</html>
