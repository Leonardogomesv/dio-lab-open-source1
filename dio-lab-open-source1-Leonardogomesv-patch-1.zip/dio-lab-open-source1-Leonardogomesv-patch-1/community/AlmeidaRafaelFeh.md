# Rafael Freire de Almeida

#### Bem vindo ao meu git-hub pessoal, tenho 31 anos, estou tentando me tornar um dev de alto nivel, gosto de estudar e fico muito feliz quando tenho insight da "magic" da programação (risos). Quando nao estou estudando estou puxando peso, me ajuda a diminuir a ansiedade e auxilia no foco.


## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/almeida-rafaelfeh/)
[![YouTube](https://img.shields.io/badge/YouTube-000?style=for-the-badge&logo=Youtube&logoColor=red)](https://www.youtube.com/channel/UCy4jrbOITRoa0MTJCWbBWaQ)

## Habilidades
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)

![Angular](https://img.shields.io/badge/Angular-000?style=for-the-badge&logo=angular&logoColor=C3002F)

## Em Desenvolvimento

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

![React Native](https://img.shields.io/badge/React-Native-025?style=for-the-badge&logo=React-Native)

## Planos futuros

![Unity](https://img.shields.io/badge/Unity-000?style=for-the-badge&logo=unity)
![Canva Element](https://img.shields.io/badge/Canvas-Element-711?style=for-the-badge&logo=Canvas-Element)


## Git Hub Status

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AlmeidaRafaelFeh&theme=transparent&bg_color=026&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF&hide_title=true)

