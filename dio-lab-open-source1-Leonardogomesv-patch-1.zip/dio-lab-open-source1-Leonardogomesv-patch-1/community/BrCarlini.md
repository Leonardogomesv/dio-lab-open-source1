<h1>Olá, me chamo Bruno</h1>
 <div>
  <ul>
    <li>Trabalho como Analista de Service Desk, e estou migrando para Desenvolvimento de Software</li>
    <li>Dev Fullstack | Análise e Desenvolvimento de Sistemas</li>
    <li>Meu Portfólio: <a hreaf="https://portfolio-brcarlini.vercel.app">https://portfolio-brcarlini.vercel.app</a></li>
   <ul>
  </div>


<div align="center">
  <a href="https://github.com/BrCarlini">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=BrCarlini&show_icons=true&theme=algolia&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=BrCarlini&layout=compact&langs_count=7&theme=algolia"/>
</div>
<div align="center" style="display: inline_block"><br>
  <img align="center" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/kotlin/kotlin-original.svg">
  <img align="center" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg">
  <img align="center" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg">
  <img align="center" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mysql/mysql-original.svg">
  
</div>
  
 
  ##
 
<div align="center">
  <a href=mailto:"bruno-carlini@hotmail.com"><img src="https://img.shields.io/badge/-Email-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/bruno-carlini-b92184159/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
 
</div>
