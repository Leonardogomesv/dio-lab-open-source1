
# Augusto Mol

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/augusto-6x10a23/)

## Habilidades
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python) 

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)

![Angular](https://img.shields.io/badge/Angular-000?style=for-the-badge&logo=angular&logoColor=C3002F)



## Sobre mim
#### Estudante de Ciência da Computação na FUMEC. Foco em desenvolvimento Full Stack com Java e Angular no Bootcamp Santander da DIO. Interesse em Ciência de Dados e Inteligência Artificial, conduzindo pesquisas independentes nesses campos. Comprometido com aprendizado contínuo e contribuições na área tecnológica.

## GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Augusto6x10a23&theme=transparent&bg_color=000&border_color=67061D&show_icons=true&icon_color=67061D&title_color=67061D&text_color=67061D)






