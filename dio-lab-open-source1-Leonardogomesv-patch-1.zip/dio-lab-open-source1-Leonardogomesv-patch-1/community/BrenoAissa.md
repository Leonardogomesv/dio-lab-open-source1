 
### Olá, bem-vindos ao meu readme do projeto DIO

- 🔭 Sou estudante de Análise e desenvolvimento de sistemas
- ⚡ Atualmente sou estagiário na área de desenvolvimento de software na Fine Instrument Technology

<div align="center">
  <a href="https://github.com/brenoaissa">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=brenoaissa&show_icons=true&theme=cobalt&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=brenoaissa&layout=compact&langs_count=7&theme=cobalt"/>
</div>
 
<div style="display: inline_block"><br>
  <img align="center" alt="Breno-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Breno-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Breno-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" alt="Breno-Python" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">
  <img align="center" alt="Breno-C" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/c/c-original.svg"/>
  <img align="center" alt="Breno-Java" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg" />
          
          



  </div>
  
##
- 😎 Meu linkedin
<div> 
  <a href="https://www.linkedin.com/in/breno-oliveira-214591187/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
  
</div>
