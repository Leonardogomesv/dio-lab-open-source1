# **Bruno Dias**

## Sou estudante de Tecnologia da Informação, e atualmente faço estágio de Suporte Técnico. Sou curioso e muito interessado por tecnologia, sobretudo na área de Desenvolvimento Web e Game Design.

## Meus links:

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/bruno-dias-19a1b722b/) [![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/brunofbdias) 

## Interesses e habilidades:

![Aseprite](https://img.shields.io/badge/Aseprite-000?style=for-the-badge&logo=Aseprite&logoColor=white) ![JavaScript](https://img.shields.io/badge/Javascript-000?style=for-the-badge&logo=javascript&logoColor=yellow) ![HTML5](https://img.shields.io/badge/html5-000?style=for-the-badge&logo=html5&logoColor=orange) ![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=Markdown&logoColor=white) ![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=CSS3&logoColor=green) ![Debian](https://img.shields.io/badge/Debian-000?style=for-the-badge&logo=Debian&logoColor=red)
