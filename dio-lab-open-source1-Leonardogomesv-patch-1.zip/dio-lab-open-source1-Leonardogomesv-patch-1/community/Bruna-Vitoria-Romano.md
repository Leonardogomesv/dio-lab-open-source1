# Bruna Romano

Olá! Eu sou Bruna, estudo programação há algum tempo (como autodidata) e estou participando de vários bootcamps oferecidos pela DIO (Digital Innovation One), que são disponibilizados em parceria com empresas dos mais variados setores. Graças à DIO tenho aprendido muito e tenho certeza de que avançarei ainda mais nesse vasto campo do conhecimento. Tenho uma grande paixão por C# e JAVA.

## Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=fff)](https://www.linkedin.com/in/bruna-romano-50b835215/)

## Habilidades

![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)