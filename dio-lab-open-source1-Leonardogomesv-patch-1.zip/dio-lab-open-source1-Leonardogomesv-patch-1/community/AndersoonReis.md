
# Anderson Oliveira
<br>

Olá, Sou estudante da DIO, minha primeira linguagem está sendo o Python, mas em breve pretendo estudar também o Java. Pretendo me especializar na área de back-end e analise de dados e machine learning. 

<br>

## 🔗 Conecte-se comigo

[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://github.com/AndersoonReis)
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-000?style=for-the-badge)](https://web.dio.me/users/andersonx775) 
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/andersoonreis/)

<br>

## 💻 Skills


![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![GitHub](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=github)
![Java](https://img.shields.io/badge/java-000?style=for-the-badge&logo=JAVA)
![MySQL](https://img.shields.io/badge/MySQL-000?style=for-the-badge&logo=MySQL)
![MongoDb](https://img.shields.io/badge/MongoDb-000?style=for-the-badge&logo=MongoDb)


<br>

## GitHub stats


![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AndersoonReis&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)


<br>

## Main Projects

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AndersoonReis&repo=Bot-RU-UEFS&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/AndersoonReis/Bot-RU-UEFS)


