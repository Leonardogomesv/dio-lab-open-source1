# Bruno Gomes

            Jovem de 26 anos, que um dia resolveu mudar de vida, e agora está se aventurando no mundo da Programação. Apaixonado por desafios, relações e aprendizados. Gosto de jogos, música, filmes, séries, mas principalmente, momentos com pessoas que eu amo. Em busca de uma vida confortável, e se possível, deixar uma contribuição para o mundo.

### Conecte-se comigo

[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/bsgomes16/)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:bsgomes16@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-Instagram-000?style=for-the-badge&logo=instagram&logoColor=)](https://www.instagram.com/brunogomes_71/)

### Habilidades

![HTML5](https://img.shields.io/badge/HTML-000?style=for-the-badge&logo=html5&logoColor=30A3DC)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=E94D5F)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript&logoColor=30A3DC)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)

### GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=BrunoGomes-97&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=BrunoGomes-97&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

### Meus Principais Desafios de Projeto DIO

[![Repo DIO Classes Jogo](https://github-readme-stats.vercel.app/api/pin/?username=BrunoGomes-97&repo=dio-classes-jogo&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/BrunoGomes-97/dio-classes-jogo)
[![Repo DIO Roadmaps](https://github-readme-stats.vercel.app/api/pin/?username=BrunoGomes-97&repo=dio-classificador-heroi&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/BrunoGomes-97/dio-classificador-heroi)
