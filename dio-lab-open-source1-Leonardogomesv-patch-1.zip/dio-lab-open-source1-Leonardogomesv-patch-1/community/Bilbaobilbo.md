# Bilbaobilbo

Olá, meu nome é Igor, é um prazer poder me conectar um pouco com meus colegas de curso através de uma contribuição no projeto opensource!

## Minhas redes
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/igor-bilbao-31b337243/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/igorianbilbao/)

## Habilidades

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

