
# Alan Germano





## 🚀 Sobre mim
✋✋Olá! Meu nome é Alan e sou estudante na DIO com foco em aprimoramento das habilidades. Formado em GTI, Sou apaixonado por tecnologia e gosto de explorar vários aspectos do desenvolvimento de software. Atualmente estudando Desenvolvimento Web

## 🛠 Habilidades
![HTML5](https://img.shields.io/badge/HTML-yellow?style=for-the-badge&logo=html5&logoColor=30A3DC)

![CSS3](https://img.shields.io/badge/CSS3-green?style=for-the-badge&logo=css3&logoColor=E94D5F)

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript&logoColor=30A3DC)

[![Git](https://img.shields.io/badge/Git-004?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc) 

[![GitHub](https://img.shields.io/badge/GitHub-045?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)


## 🔗 Conecte-se

[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/alangermanos/)

[![DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A?style=for-the-badge)](https://www.dio.me/users/srgermano13)

[![E-mail](https://img.shields.io/badge/-Email-576?style=for-the-badge&logo=microsoft-outlook&logoColor)](mailto:germano.alan@outlook.com)

## GitHub Status

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=SEUUSERNAME&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)


