# Aniibea
Olá, eu sou Beatriz, pode me chamar de Ani ou Bea, tenho 23 anos e estou atualmente tentando mudar de área profissional.

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=8F9FE4)](https://www.linkedin.com/in/mariana-araújo-75257827b/overlay/contact-info/)
[![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord&logoColor=8F9FE4)](https://https://discord.com/channels/@anibea/)
[![Telegram](https://img.shields.io/badge/Telegram-000?style=for-the-badge&logo=telegram&logoColor=8F9FE4)](https://t.me/@anibeea)

## Github stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Aniibea&theme=transparent&bg_color=bca5d4&border_color=7164b4&show_icons=true&icon_color=7164b4&title_color=efe2fa&text_color=000)

## Minhas contribuições