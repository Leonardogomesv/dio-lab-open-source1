# Bruno LR

## Segue aí
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=8b30e6)](https://www.linkedin.com/in/bruno-lima-da-rosa-8574a5150/)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=8b30e6)](mailto:brunolr1999@gmail.com)
## Habilidades

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Brun0LR&theme=transparent&bg_color=000&border_color=8b30e6&show_icons=true&icon_color=8b30e6DC&title_color=8b30e6&text_color=FFF)
## Minhas Contribuições

## Itch.IO