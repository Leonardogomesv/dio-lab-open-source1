
# ola, me chamo Adonis!
## Apaixonado pela área da tecnologia e sua complexidade
- atualmente faço faculdade de ADS, cursos e bootcamp na plataforma da Dio. Tenho conhecimento em javascript, Html e CSS, continuo estudando e buscando cada vez mais evoluir, quero ser desenvolvedor fullstack e jogos.
## Tecnologia que estão em minha metas de estudos:
- ![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java) 
- ![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react) 
- ![Angular](https://img.shields.io/badge/Angular-000?style=for-the-badge&logo=angular&logoColor=C3002F)


 ## redes sociais
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/adonis-pantoja-232662239?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app )

