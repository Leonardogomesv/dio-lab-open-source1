### <a href="https://fontmeme.com/pt/fontes-legais/"><img src="https://fontmeme.com/permalink/230522/61fd287e0e81f7aff539deddd947da74.png" alt="fontes-legais" border="0"></a>

<!--**BrunaSilva25/BrunaSilva25** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.-->

- 😍 Apaixonada por Tecnologia
- 🌱 Formada em Análise e Desenvolvimento de Sistemas pela PUCGO
- 🌱 Atualmente cursando Pós em Desenvolvimento Full-Stack e MBA em Segurança da informação
##
<div align="center">
  <a href="https://github.com/BrunaSilva25">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=BrunaSilva25&show_icons=true&theme=bear&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=BrunaSilva25&layout=compact&langs_count=7&theme=bear"/>
</div>
 
<div style="display: inline_block"><br>
 
  <img align="center" alt="Bruna-Java" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original-wordmark.svg">
  <img align="center" alt="Bruna-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Bruna-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" alt="Bruna-bootstrap" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/bootstrap/bootstrap-original-wordmark.svg" />
 <img align="center" alt="Bruna-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Bruna-figma" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/figma/figma-original.svg" />
  <img align="center" alt="Bruna-Canvas" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/canva/canva-original.svg" />
  <img align="center" alt="Bruna-Github" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/github/github-original.svg" />
  <img align="center" alt="Bruna-Vscode" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vscode/vscode-original.svg" />




  </div>
  
##

<div> 
<!--  <a href="https://www.youtube.com/#" target="_blank"><img src="https://img.shields.io/badge/YouTube-FF0000?style=for-the-badge&logo=youtube&logoColor=white" target="_blank"></a>
  <a href="https://instagram.com/#" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
 	<a href="https://www.twitch.tv/#" target="_blank"><img src="https://img.shields.io/badge/Twitch-9146FF?style=for-the-badge&logo=twitch&logoColor=white" target="_blank"></a>
 <a href="https://discord.gg/#" target="_blank"><img src="https://img.shields.io/badge/Discord-7289DA?style=for-the-badge&logo=discord&logoColor=white" target="_blank"></a> 
  <a href = "mailto:#"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a> -->
  📬 Conecte-se comigo nas redes sociais: <br>
  <a href="https://www.linkedin.com/in/bruna-lorrane-caires-9139a685/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
  
</div>
