# Brenda Caroline

## Sobre mim

👩‍🎓Sou formada no curso técnico em Informática para Internet, e no curso Bacharelado em Sistemas de Informação, ambos pelo Instituto Federal do Norte de Minas Gerais - IFNMG. 

📚Atualmente estou cursando Mestrado em Ciências da Computação na Universidade Federal de Santa Catarina - UFSC.

💻Amo a programação e já tive contato com diversas linguagens. Atualmente tenho estudado a linguagem Python e espero com esse Bootcamp aprender mais sobre a área e ingressar no mercado de trabalho. 

## Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/brenda-c-092707142/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github)](https://github.com/Brenda-Caroline)
[![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord)](https://www.discord.com/in/brendacaroline./)
[![Gmail](https://img.shields.io/badge/Gmail-000?style=for-the-badge&logo=gmail)](https://www.gmail.com/2014brendacs0@gmail.com/)


## Habilidades

Durante minha formação, estudei várias linguagens de programação e bibliotecas, como: 

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![C++](https://img.shields.io/badge/C%2B%2B-000?style=for-the-badge&logo=c%2B%2B&logoColor=00599C)
![C++](https://img.shields.io/badge/PHP-000?style=for-the-badge&logo=php)
![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)
![React Native](https://img.shields.io/badge/React-Native-000?style=for-the-badge&logo=React-Native)


Atualmente tenho mais conhecimento em: 

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)


## GitHub Stats

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Brenda-Caroline&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)


