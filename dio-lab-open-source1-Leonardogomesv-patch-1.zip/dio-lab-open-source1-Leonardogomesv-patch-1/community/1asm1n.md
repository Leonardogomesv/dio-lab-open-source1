<div>
    <h1>Oiê! Meu nome é Iasmin, mas pode me chamar de Ias. 👋 </h1>
    <h2>Bem vindo(a) ao meu Perfil.</h2>
    <p> Me chamo Iasmin Ghirlinzone. Estou no primeiro período da faculdade de Sistemas de Informação e sou apaixonada por tecnologia desde que tive meu primeiro contato com o maravilhoso mundo da programação, no curso técnico de informática que fiz durante o ensino médio. Atualmente, sou professora de Inglês em uma escola local, mas meu maior sonho é conseguir um emprego na área da tecnologia. Estou estudando e dando meu melhor para me capacitar e me tornar uma programadora competente e formidável. 
    </p>
    <p> Sobre meus hobbies para além da informática, eu gosto muito de ler - especialmente aqueles romances bem clichês. Gosto também de fazer crochê e cozinhar - principalmente doces, sou uma confeiteira de mão cheia.
    </p>
</div>
<div>
    <h2>Conecte-se comigo</h2>
   <a href="https://www.linkedin.com/in/iasmin-lessa-ghirlinzone-00126b246/" target="_blank"></a> 
   
</div>
<br>
<div align="center">
  <a href="https://github.com/1asm1n">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=1asm1n&show_icons=true&theme=tokyonight&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=1asm1n&layout=compact&langs_count=7&theme=tokyonight"/>
</div>
<div style="display: inline_block"><br>
    <h2>Tecnologias</h2>
  
  <img align="center" alt="Rafa-MySQL" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original-wordmark.svg">
  <img align="center" alt="Rafa-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Rafa-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
</div>
<br>
<br>

## Principais Projetos
[![Repo DIO Git GitHub](https://github-readme-stats.vercel.app/api/pin/?username=elidianaandrade&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/elidianaandrade/dio-lab-open-source)



## Minhas Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=1asm1n&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](thhps://github.com/1asm1n/dio-lab-open-source)


