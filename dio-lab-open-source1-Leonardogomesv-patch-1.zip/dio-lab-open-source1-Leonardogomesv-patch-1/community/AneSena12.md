# Thayane Sena

Hello, Friend! 


![X-Men-Evolution-gifs-featuring-Kitty-Pryde-Shadowcat-x-men-40329704-450-338](https://github.com/AneSena12/AneSena12/assets/140628944/a84295c0-2053-40ed-b361-f2da80619a4d)

## Hard Skills
I’m currently learning Front-end web development:

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)

## Soft Skills

![Curiosity](https://img.shields.io/badge/Curiosity-darkgreen)
![Communicative](https://img.shields.io/badge/Communicative-yellow)
![Proactive](https://img.shields.io/badge/Proactive-grey)
![Problem Solving](https://img.shields.io/badge/Problem_Solving-darkred)
![Empathetic](https://img.shields.io/badge/Empathetic-blue)
![Creative](https://img.shields.io/badge/Creative-orange)



## Connect with me

[![LinkedIn](https://img.shields.io/badge/Linkedin-blue)](https://www.linkedin.com/in/thayane-sena-de-moura-633193177/)
[![Perfil DIO](https://img.shields.io/badge/DIO/PERFIL-purple)](https://web.dio.me/users/anesmbonny)
[![GitHub](https://img.shields.io/badge/GitHub-black)](https://github.com/AneSena12)

## GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AneSena12&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF&hide_title=true)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AneSena12&bg_color=000&border_color=30A3DC&title_color=1589F0&text_color=FFF)

[![GitHub Streak](https://streak-stats.demolab.com/?user=AneSena12&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)