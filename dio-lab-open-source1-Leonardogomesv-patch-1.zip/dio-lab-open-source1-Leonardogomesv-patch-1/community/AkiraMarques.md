# Lucas Marques

Sou uma pessoa que esta reexplorando o mundo da programação. Tive meu primeiro contato durante o técnico em mecatrônica onde aprendi o básico de assembly, C e C++ e durante a faculdade de engenharia mecatrônica, aprofundei ainda mais em C e C++ principalmente.
Depois de alguns anos acabei criando a curiosidade novamente de me aprofundar no mundo da lógica e programação e de um hobby acabei percebendo o quanto me sinto bem aprendendo e desenvolvendo. Sinto que ainda to no inicio mas com certeza estou com um apetite enorme por esse mundo.

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/omarqueslucas/)
[![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord)](https://www.discord.com/in/akiramarx/)

## Habilidades
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AkiraMarques&bg_color=000&border_color=&title_color=E94D5F&text_color=FFF)


## Github Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AkiraMarques&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)


## Minhas Linguagens de Marcação e Estilos
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)


## Linguagens de Programação
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c)
![C++](https://img.shields.io/badge/C%2B%2B-000?style=for-the-badge&logo=c%2B%2B&logoColor=00599C)


## Principais Projetos
[![Repo DIO Git GitHub](https://github-readme-stats.vercel.app/api/pin/?username=elidianaandrade&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/elidianaandrade/dio-lab-open-source)
[![Desafio-Felipao](https://github-readme-stats.vercel.app/api/pin/?username=AkiraMarques&repo=desafio-felipao&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/AkiraMarques/desafio-felipao)

##