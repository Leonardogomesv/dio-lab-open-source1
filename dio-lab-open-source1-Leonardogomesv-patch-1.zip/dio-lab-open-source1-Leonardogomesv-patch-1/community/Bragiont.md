# Bragiont


Olá, meu nome é Tamires Bragion, sou formada em Ciencias Contabeis e servidora pública municipal. Atualmente estou aprendendo programação através da DIO.

---

## Conecte-se comigo

[![GitHub](https://img.shields.io/badge/GitHbt-000?style=for-the-badge&logo=github&logoColor=white)](+https://github.com/Bragiont) 
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-000?style=for-the-badge)](ttps://www.dio.me/users/tmenezes_foto/)

---

## Estudando no momento

![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python) 
![MySQL](https://img.shields.io/badge/MySQL-000?style=for-the-badge&logo=mysql&logoColor=white)

## GitHub Status

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=bragiont&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=fff&title_color=fff&text_color=FFF&hide_title=true)


## Minhas Contribições

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Bragiont&repo=dio-lab-open-source&bg_color=000&border_color=fff&show_icons=true&icon_color=fff&title_color=fff&text_color=FFF)](https://github.com/bragiont/dio-lab-open-source)
