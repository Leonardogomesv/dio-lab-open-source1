# Airton Alves Medina

Eterno Aprendiz de Binary Exploitation.

### Conecte-se comigo

[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/airtonmedina_92458)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:airtonnmedina@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/airtonmedina/)

### Habilidades

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python&logoColor=30A3DC)
![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c&logoColor=30A3DC)
![Assembly x64](https://img.shields.io/badge/Assembly%20x64-000?style=for-the-badge&logo=Hackaday&logoColor=30A3DC)
![Assembly x86](https://img.shields.io/badge/Assembly%20x86-000?style=for-the-badge&logo=amazon-ec2&logoColor=30A3DC)
![Assembly ARM](https://img.shields.io/badge/ARM%20Assembly-000?style=for-the-badge&logo=arm&logoColor=30A3DC)
![Linux](https://img.shields.io/badge/Linux-000?style=for-the-badge&logo=Linux&logoColor=30A3DC)

[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)

### GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Blind4rch3r&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Blind4rch3r&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)
