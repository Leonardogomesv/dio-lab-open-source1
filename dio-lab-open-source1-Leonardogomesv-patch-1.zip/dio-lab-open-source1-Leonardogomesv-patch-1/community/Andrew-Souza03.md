# AndrewSouza

## Conecte - se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/andrew-souza-870009289/)


## Habilidades
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)


## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Andrew-Souza03&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF&hide_title=true&)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Andrew-Souza03&layout=compact&bg_color=000&border_color=31A3D&title_color=E94D5F&text_color=FFF)

## Minhas Contribuições 