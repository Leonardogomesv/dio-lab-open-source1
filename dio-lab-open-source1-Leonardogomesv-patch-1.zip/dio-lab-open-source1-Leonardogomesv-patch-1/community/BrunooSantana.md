# Sobre mim

Me chamo Bruno C. Santana, tenho interesse por tecnologia desde pequeno, pois nessa época já montava meus computadores, instalava os programas, jogos e aprendia sobre OS.

Atualmente estou fazendo curso de Análise e Desenvolvimento de Sistemas pela UNIP finalizando em 2024, já passei por várias linguagens de programação e algumas de marcação como Python, HTML, CSS, JavaScript, C e Java, claro que também aprendi Git e GitHub.

Atualmente estou participando do BootCamp do Santander focado em Java + Angular como Dev. Full Stack que é onde pretendo seguir me aprofundando.

Gosto muito de sempre aprender coisas novas e sempre buscando crescer na carreira, visando o próximo cargo de liderança que eu posso ocupar para contribuir a cada dia mais com a empresa onde eu estiver, como sempre fiz ao longo da minha carreira.

## Vamos nos conectar?
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://https://www.linkedin.com/in/bruno--santana/)

[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github)](https://github.com/BrunooSantana/)

[![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord)](https://www.discord.com/in/bruno_santana./)bruno_santana.

## Linguagens mais usadas nos repositórios
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=BrunooSantana&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Linguagens de Marcação e Estilo (Aprendendo)
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)

![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)

## Linguagens de Programação (Aprendendo)
![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c)

![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)

![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=oracle)

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

![TypeScript](https://img.shields.io/badge/TypeScript-000?style=for-the-badge&logo=typescript)

## Bibliotecas e Frameworks (Aprendendo)
![Angular](https://img.shields.io/badge/Angular-000?style=for-the-badge&logo=angular&logoColor=C3002F)

![Figma](https://img.shields.io/badge/Figma-000?style=for-the-badge&logo=figma&logoColor=C3002F)

## Repositórios

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=BrunooSantana&repo=RocketSeat-Projects&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/BrunooSantana/RocketSeat-Projects)



