
# Amanda Silveira 👩🏻‍💻

##Conecte-se ao meu perfil

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/amanda-hutt-silveira-319141166/)

[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/amandanhutts/)

## Sobre mim
Sou Graduada em Gestão de Recursos Humanos, analista em Departamento Pessoal.

Atualmente em transição de carreira, já atuando na área de Qualidade e Testes de Softwares.

## Atualmente cursando :

Gestão em Banco de Dados



Análise e Gestão em Power BI


## Habilidades
![GitHub](https://img.shields.io/badge/GitHub-black?logo=github)
![ScripSQL](https://img.shields.io/badge/SQL-purple?logo=scripsql)
![Python](https://img.shields.io/badge/Python-black?logo=python)
![PowerBI](https://img.shields.io/badge/PowerBI-white?logo=powerbi)
![TestComplete](https://img.shields.io/badge/TestComplete-blue?logo=testcomplete)



