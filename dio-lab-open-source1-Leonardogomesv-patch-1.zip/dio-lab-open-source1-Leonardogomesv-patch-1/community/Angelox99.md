<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=9202F7&section=header&text=&fontSize=40&fontColor=fff&animation=twinkling&fontAlignY=35"/>

[![Typing SVG](https://readme-typing-svg.demolab.com?font=Arbutus&size=40&duration=4000&pause=400&color=9202F7&vCenter=true&width=1000&lines=Hi+there+%F0%9F%91%8B%2C+My+Name+is+Angelo+Ferro+;but+you+can+call+me+as+%7CSIG%7C+%F0%9F%98%8E)](https://git.io/typing-svg)

##

- 🔭 I’m currently working on SEFAZ with java.
- 🌱 I’m currently learning Java and C.
- 🤔 I’m looking for help with Java.
- 💬 Ask me about Animes,Mangas and Games.
- 📫 How to reach me: Angelo.sonic@gmail.com
- ⚡ Fun fact: I don't like cold but my dreans is to live in  Canada-Vancouver

##

<table align="center">
	<tbody>
		<tr>
			<td align="center">
  <a href="https://github.com/Angelox99">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=Angelox99&show_icons=true&theme=midnight-purple&include_all_commits=true&count_private=true"/>
  <img height="215em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Angelox99&layout=compact&langs_count=7&theme=midnight-purple"/>
      </td>
			<td>
  <img align="right" alt="SIG-pic" height="400" style="border-radius:50px;" src="https://static.wikia.nocookie.net/biblioteca-de-calnat/images/e/e1/Sieg_base.png/revision/latest/scale-to-width-down/1000?cb=20200601060342&path-prefix=pt-br">
      </td>
		</tr>
	</tbody>
</table>

  ##

<div align="center" style="display: inline_block"><br>
  <img align="center" alt="SIG-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="SIG-Java" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original-wordmark.svg">
  <img align="center" alt="SIG-C" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/c/c-original.svg">
  <img align="center" alt="SIG-php" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/php/php-plain.svg">
  <img align="center" alt="SIG-HTML" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-plain-wordmark.svg">
  <img align="center" alt="SIG-Python" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">
  <img align="center" alt="SIG-PhotoShop" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/photoshop/photoshop-plain.svg">
  <img align="center" alt="SIG-Unity" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/unity/unity-original.svg">
  <img align="center" alt="SIG-Unity" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/gimp/gimp-original-wordmark.svg">
  
  
          

</div>

  ##
  
<div align="center"> 
  <a href="https://www.youtube.com/channel/UChIkJ-Ph7fZF5bK5F_TRhmw" target="_blank"><img src="https://img.shields.io/badge/YouTube-FF0000?style=for-the-badge&logo=youtube&logoColor=white" target="_blank"></a>
  <a href = "mailto:angelo.sonic@gmail.com"><img src="https://img.shields.io/badge/-Gmail-db4a39?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://www.instagram.com/angelo.a.ferro/?hl=pt-br" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
  <a href="https://www.twitch.tv/i_sieg_i" target="_blank"><img src="https://img.shields.io/badge/Twitch-9146FF?style=for-the-badge&logo=twitch&logoColor=white" target="_blank"></a>  
  <a href="https://www.linkedin.com/in/angelo-ferro-ti-games/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>
  <a href="https://twitter.com/IAngelo_FerroI target="_blank"><img src="https://img.shields.io/badge/Twitter-00acee?style=for-the-badge&logo=twitter&logoColor=white" target="_blank"></a>
</div>

  ##
  
  [![@angeloferro's Holopin board](https://holopin.me/angeloferro)](https://holopin.io/@angeloferro)
  
  ##
  
<div>
  ![Snake animation](https://github.com/Angelox99/Angelox99/blob/output/github-contribution-grid-snake.svg)
</div>

  ##
  
<div align="center">
<br><p align="centre"><b>Visitors Count</b></p>  
<p align="center"style="color:#9202F7"><img align="center" src="https://profile-counter.glitch.me/{Angelox99}/count.svg" /></p> 
<br></div>

  ##

<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=9202F7&section=footer&text=&fontSize=30&fontColor=fff&animation=twinkling&fontAlignY=35"/>


	
  
