# Augusto Gomes
Bem vindo ao meu GitHub, sou o Augusto tenho 31 anos  e sempre gostei da área da tecnologia, iniciando com montagem e manutenção de computadores aos 14 anos, mas me apaixonei pela programação ao primeiro contato! sou formado em Sistemas da Informação e cursei Jogos Digitais. tenho como Hobbies jogar futebol, jogos eletrônicos (FPS principalmente) e faço lives das gameplays na [Twitch](https://twitch.tv/BOKAsp), segue la :smiley: .

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue?style=for-the-badge&logo=linkedin&logoColor=fff)](https://www.linkedin.com/in/augusto-gomes-49ba2a46/)
[![GitHub](https://img.shields.io/badge/GitHub-blue?style=for-the-badge&logo=github&logoColor=fe4r)](https://github.com/augustotgomes)
[![Perfil DIO](https://img.shields.io/badge/-DIO%20PROFILE-blue?style=for-the-badge)](https://www.dio.me/users/augusto_tgomes)

<a href = "[mailto:augusto.tgomes@gmail.com](https://www.dio.me/users/augusto_tgomes)"><img src="https://img.shields.io/badge/Gmail-blue?style=for-the-badge&logo=gmail&logoColor=red" target="_blank"></a>
[![Whatsapp](https://img.shields.io/badge/WhatsApp-blue?style=for-the-badge&logo=whatsapp&logoColor=green)](https://wa.me/5511989342578) [![Instagram](https://img.shields.io/badge/Instagram-blue?style=for-the-badge&logo=Instagram&logoColor=fff)](https://www.instagram.com/augustogms/) 

## Habilidades
[![GitHub](https://img.shields.io/badge/GitHub-blue?style=for-the-badge&logo=github&logoColor=fff)](https://docs.github.com/)
[![Git](https://img.shields.io/badge/Git-blue?style=for-the-badge&logo=git&logoColor=fff)](https://git-scm.com/doc) 
![HTML5](https://img.shields.io/badge/HTML5-blue?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-blue?style=for-the-badge&logo=css3&logoColor=264CE4)
![JavaScript](https://img.shields.io/badge/JavaScript-blue?style=for-the-badge&logo=javascript)
![TypeScript](https://img.shields.io/badge/TypeScript-blue?style=for-the-badge&logo=typescript)
![React](https://img.shields.io/badge/React-blue?style=for-the-badge&logo=react)

<p align="center">
  <img src="https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=augustotgomes&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF" >
</p>



## GitHub Stats
<p align="center">
<img src="https://github-readme-stats.vercel.app/api?username=augustotgomes&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF">
</p>



## Skills em Aprendizado
![Next](https://img.shields.io/badge/Next.Js-blue?style=for-the-badge&logo=react)
![React](https://img.shields.io/badge/Flutter-blue?style=for-the-badge&logo=flutter)
![React](https://img.shields.io/badge/Dart-blue?style=for-the-badge&logo=dart)