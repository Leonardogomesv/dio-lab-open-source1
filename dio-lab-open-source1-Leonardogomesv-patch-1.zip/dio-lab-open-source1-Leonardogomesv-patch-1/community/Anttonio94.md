# Augustto94
Olá
sou o Augustto Brito,  tenho 29 anos
e estou ingressando na carreira de progração.
## conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=Instagram&logoColor=0E76A8)](https://https://www.instagram.com/augusto_btt/) [![Facebook](https://img.shields.io/badge/Facebook-000?style=for-the-badge&logo=facebook)](https://www.facebook.com/https://www.facebook.com/augusto.brito.7//)





##  Habilidades

 ![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown) ![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)       ![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
## Github status
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=SEUUSERNAME&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=00FF00)

## Linguagens mais usadas



## Minhas contribuições

## Principais arquivos de projeto

Loja lucas cell | https://github.com/Anttonio94/lucascell  |

Fora de serie   |  ____________________________________________
                                      |