##   💫  Hi, I'm Antonio Carioca Junior or Bill Carioca, i started a career transition in 2022 from advocacy to developer.


- 🔭 I’m currently working on Back-End and Front-End.
- 🌱 I’m currently learning Java, JavaScript and MongoDB.
- ⚡ Fun fact: I am passionate about technology, I like to work with programming and to face challenges.
<br>

## 🔗 Conect With Me

[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://github.com/BillCarioca)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/BillCarioca/)

<br>
<div>

##  📊  GitHub stats
  <a href="https://github.com/BillCarioca">
  <img height="180em"   align="center" src="https://github-readme-stats.vercel.app/api?username=BillCarioca&show_icons=true&theme=dark&include_all_commits=true&count_private=true"/>

<br>

  <img height="180em"  align="center" src="https://github-readme-stats.vercel.app/api/top-langs/?username=BillCarioca&&layout=compact&hide=shell&theme=dark"/>
  
</div>


## 💻 Skills
<div style="display: inline_block"><br>
  <img align="center" alt="Bill-Java" height="60" width="80"src="https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg" /> 
  <img align="center" alt="Bill-Spring" height="60" width="80"src="https://raw.githubusercontent.com/devicons/devicon/master/icons/spring/spring-original.svg" />
  <img align="center" alt="Bill-Js" height="60" width="80" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Bill-Ts" height="60" width="80" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/typescript/typescript-plain.svg">
  <img align="center" alt="Bill-Angular" height="60" width="80" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/angularjs/angularjs-original.svg">
  <img align="center" alt="Bill-HTML" height="60" width="80" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Bill-CSS" height="60" width="80" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
</div>
  

## ✍️  Main Projects

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=BillCarioca&repo=angula-pokedex&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/BillCarioca/angula-pokedex)
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=BillCarioca&repo=javamongodb&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/BillCarioca/javamongodb)


