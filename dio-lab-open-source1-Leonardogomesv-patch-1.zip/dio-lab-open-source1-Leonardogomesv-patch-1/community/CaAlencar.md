# Hi There! 

## 📚 *Olá, me chamo Maria Clara e estou incrementando a minha experiencia na área da computação no Bootcamp da DIO* 
- ### Atualmente estou trabalhando em outra área mas sigo tentando seguir meu sonho em me profissionalizar. 
- ### Cursando Ciências da Computação no Centro Universitário UNIBTA
- ### Me apaixonei pela programação no momento em que tive contato pela primeira vez através do Sistema operacional Linux (Ubuntu) 

# Cursos em Andamento
<img src="https://hermes.dio.me/tracks/03253ff0-95b9-4904-84e7-2063e9d6cb26.png" width=130> <img src="https://img.shields.io/badge/Santander Bootcamp 2023 - Ciência de Dados com Python -FFF?style=for-the-badge&logo=&logoColor">



<img src=https://static-cdn.myedools.com/org-6988%2Fschool-7227%2F84c9f4eaf08ecb0c30bf4d05e5fd77be%2F2021.11.16_-_cc50_128x128.png> <img src="https://img.shields.io/badge/Estudar Na Prática - CC50: Introdução à Ciência da Computação -FFF?style=for-the-badge&logo=&logoColor">


<img src=https://www.itinovacao.org.br/wp-content/uploads/2019/04/TAMANHO-OK.png width=130> <img src="https://img.shields.io/badge/ITI - SQL 2012 e Introdução à Lógica de Programação -FFF?style=for-the-badge&logo=&logoColor">



# Contato
<div align="center">
<a href = "mailto:clara.alencarr205@gmail.com"><img src="https://img.shields.io/badge/Gmail-FFF?style=for-the-badge&logo=gmail&logoColor" target="_blank"></a>  
<a href="https://wa.me/5511967164641" target="_blank"><img src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"></a>
