# Angel Neves

Estudante de Ciência da Computação com foco em JavaScript, Java e C#.
Certificada em Auxiliar de Ciência de Dados pela FAETEC com foco em Python.
Bolsista na Santander Bootcamp 2023 na trilha FullStack Java + Angular.

Procuro utilizar meu gosto por organização, estrutura e pesquisa para desenvolver códigos concisos e claros de maneira rápida, a fim de entregar os projetos dentro do prazo necessário.

## Conhecimentos

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

![TypeScript](https://img.shields.io/badge/TypeScript-000?style=for-the-badge&logo=typescript)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![Angular](https://img.shields.io/badge/Angular-000?style=for-the-badge&logo=angular&logoColor=C3002F)


## Conecte-se comigo 

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/maryangela-neves-124069165/)



