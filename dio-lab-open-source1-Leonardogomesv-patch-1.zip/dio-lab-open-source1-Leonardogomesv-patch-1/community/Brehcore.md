# Sobre Mim

Olá rede, me chamo Brena 😸!

👩‍💻 Permita-me compartilhar um pouco sobre minha jornada profissional e meu interesse crescente na área de TI.

## 📚 Experiência e Habilidades

- **Recursos Humanos:** Trago comigo uma experiência sólida no campo de Recursos Humanos, onde pude aprender e aplicar habilidades em programas como Word, Excel, Publisher, PowerPoint, Power BI e Access. Também dediquei tempo ao auto aprendizado em design gráfico, principalmente no uso do Adobe Photoshop.

- **Comunicação em Inglês:** Possuo um nível intermediário de habilidades de comunicação em inglês, o que me permite colaborar de forma eficaz com colegas e clientes de diferentes origens.

## 💻 Transição para TI

Neste momento, estou no caminho da minha jornada de transição para o campo de Tecnologia da Informação. Estou cursando Tecnologo em Análise e Desenvolvimento de Sistemas para aprimorar meus conhecimentos e habilidades nessa área.

## 🖱️ Tecnologias

Tenho focado meus estudos principalmente em JAVA, SQL e Spring Boot na área de desenvolvimento back-end. Estou me esforçando para melhorar continuamente meu conhecimento nesses campos.

## Contato

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/brenasoares/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/brehsoarees/)

Agradeço por visitar meu perfil e por considerar minha jornada em constante evolução! 😊