# Bielvski
🧑🏽‍💻Olá, Me chamo Gabriel Silva, Tenho 28 Anos, sou de Cuiabá-MT. Trabalho como suporte técnico. 

👨🏽‍💻Estou fazendo transição de carreira, entrando para a aréa de programação ou ciencia de dados. Estudo pela plataforma da Dio.

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/gabriel-victor-correa-da-silva-77ba252b)
[![Github](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=Github&logoColor=fffff)](https://github.com/Bielvski)

## Habilidades
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)
![Git](https://img.shields.io/badge/-Git-000?style=for-the-badge&logo=git)
![GitHub](https://img.shields.io/badge/-GitHub-000?style=for-the-badge&logo=github)
## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Bielvski&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Bielvski&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)
## Minhas Contribuições 
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Bielvski&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Bielvski/dio-resumos-git-e-gihub)
