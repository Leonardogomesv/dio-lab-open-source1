  <p align="center">
    <a href="https://github.com/AlcenirSantos/">
      <img src="https://firebasestorage.googleapis.com/v0/b/pessoal-6a511.appspot.com/o/Banner%20(1).svg?alt=media&token=da6020dd-a75c-4568-9479-9817aa6e0327" alt="banner"/>
    </a>
  </p>
  <p align="center">
   <a href="https://developer.mozilla.org/pt-BR/docs/Web/HTML" target="_blank">
      <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-plain.svg" alt="html5" width="40" height="40"/>
   </a>
   <a href="https://developer.mozilla.org/pt-BR/docs/Web/CSS" target="_blank">
      <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-plain.svg" alt="css3" width="40" height="40"/>
   </a>
   <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank">
      <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" alt="javascript" width="40" height="40"/>
   </a>
   <a href="https://www.typescriptlang.org/" target="_blank">
      <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/typescript/typescript-original.svg" alt="Typescript" width="40" height="40"/>
   </a>
   <a href="https://nodejs.org" target="_blank">
      <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-original.svg" alt="nodejs" width="40" height="40"/>
   </a>
   <a href="https://start.spring.io/" target="_blank">
      <img src="https://img.icons8.com/color/144/000000/spring-logo.png" alt="spring-boot" width="40" height="40"/>
   </a>
   <a href="https://www.java.com/pt-BR/" target="_blank">
      <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-plain.svg" alt="java" width="40" height="40"/>
   </a>
   <a href="https://git-scm.com/" target="_blank">
      <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-original.svg" alt="git" width="40" height="40"/>
   </a>
   <a href="https://flutter.dev/" target="_blank">
      <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/flutter/flutter-original.svg" alt="Flutter" width="40" height="40"/>
   </a>
    <a href="https://pt-br.reactjs.org/" target="_blank">
      <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg" alt="ReactJS" width="40" height="40"/>
   </a>
</p>

<h4 align="center">
<details>
<summary>Mais...</summary>
<h1 align="center"><img src="https://media.giphy.com/media/hvRJCLFzcasrR4ia7z/giphy.gif" width="25px">Oi meu nome é Alcenir</h1></img>

<p align="center">
  <a href="https://github.com/AlcenirSantos">
    <img
      align="center"
      height="150em"
      src="https://github-readme-stats.vercel.app/api?username=AlcenirSantos&show_icons=true&include_all_commits=true&count_private=false&theme=tokyonight"
    />
  </a>
  <a href="https://github.com/AlcenirSantos">
    <img
      align="center"
      height="150em"
      src="https://github-readme-stats.vercel.app/api/top-langs/?username=AlcenirSantos&show_icons=true&include_all_commits=true&count_private=false&layout=compact&theme=tokyonight"
    />
  </a>
</p>


<p align="center">
  <a href="https://github.com/AlcenirSantos">
    <img
      align="center"
      src="https://github-profile-trophy.vercel.app/?username=AlcenirSantos&theme=onedark&no-frame=true&row=1&&margin-w=20&no-bg=true"
    />
  </a>
</a>
</p>

<h3 align="center">Trabalhando em:</h3>

<p align="center">
  <a href="https://github.com/alcenirSantos/boleto-sicoob">
    <img
      align="center"
      height="120em"
      src="https://github-readme-stats.vercel.app/api/pin/?username=AlcenirSantos&repo=boleto-sicoob&theme=tokyonight&description=Gerador de boletos">
    </img>
  </a>
</p>

<h3 align="center">Sobre mim:</h3>

<p align="center">
  <a href="https://www.instagram.com/cenii.santos/" target="_blank">
    <img
      align="center"
      src="https://img.shields.io/badge/Instagram-1C1C1C?style=for-the-badge&logo=instagram&logoColor=00FFFF"
    />
  </a>
   <a href="https://linkedin.com/in/Alcenir-Santos" target="_blank">
    <img
         align="center"
         src="https://img.shields.io/badge/LinkedIn-1C1C1C?style=for-the-badge&logo=linkedin&logoColor=00FFFF"
  </a>
  <a href="https://twitter.com/ceniisantos">
    <img
      align="center"
      src="https://img.shields.io/badge/Twitter-1C1C1C?style=for-the-badge&logo=twitter&logoColor=00FFFF"
    />
  </a>
</p>
<!--h5 align="center">Seu @</h5-->
</details>
