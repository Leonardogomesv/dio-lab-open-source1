# Anderson Becker
--------------------------------------------------
### Olá sou Anderson, tenho 37 anos, estou cursando análise e desenvolvimentos de sistemas, conheci a [DIO - Digital Innovation One](https://web.dio.me/) pela faculdade da  [Uniritter](https://www.uniritter.edu.br/) e adorei a plataforma. Aqui começo como prática a criação do primeiro repositório do GitHub.

Principal Objetivo deste desafio é fazer a primeira contribuição no GitHub...

## Conecte-se junto à mim:
[![LinkedIn](https:/img.shields.io/badges/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/anderson-becker-639130205/)

[Email](andersonbecker86@hotmail.com)

## Conhecimentos
![C++](https://img.shields.io/badge/C%2B%2B-000?style=for-the-badge&logo=c%2B%2B&logoColor=00599C)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

##Status Atual
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AndersonBecker&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

##Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AndersonBecker&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/AndersonBecker/dio-lab-open-source)