# Anderson Luis
Olá, sou dev iniciante e estou focando meus estudos em python, estou no terceiro semestre da faculdade de Tecnologia da Informação na Univesp.
## Conecte-se comigo
[![PerfilDIO](https://img.shields.io/badge/meu_perfil_na_DIO-202?style=for-the-badge)](https://web.dio.me/users/als90and?tab=skills)
[![GitHub](https://img.shields.io/badge/GitHub-00008b?style=for-the-badge&logo=GitHub&logoColor=add8e6)](https://github.com/Andyysu)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-00008b?style=for-the-badge&logo=linkedin&logoColor=add8e6)](https://www.linkedin.com/in/anderson-silva-036a94263/)

## Habilidades
![Python](https://img.shields.io/badge/Python-00008b?style=for-the-badge&logo=python&logoColor=add8e6)
![Git](https://img.shields.io/badge/Git-00008b?style=for-the-badge&logo=git&logoColor=add8e6)
![GitHub](https://img.shields.io/badge/GitHub-00008b?style=for-the-badge&logo=github&logoColor=add8e6)
## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Andyysu&theme=transparent&bg_color=00008b&border_color=add8e6&show_icons=true&icon_color=add8e6&title_color=add8e6&text_color=FFF)
