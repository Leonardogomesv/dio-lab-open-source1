# Bongarino 

## Conecte-se comigo 
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/vitor-jacques-3a10ab268/)


## habilidades 
Cursando HTML CSS e JAVASCRIPT na DIO

Cursando Desenvolvimento de jogos 2d em LUA

Cursando Desenvolvimento de jogos na DIO

## Github Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Bongarino&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)


## Minhas Contribuições
[![GitHub Streak](https://streak-stats.demolab.com/?user=Bongarino&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)

