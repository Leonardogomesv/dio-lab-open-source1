# Bruno Pires

<P>  Olá, meu nome é Bruno Pires, atualmente estou em um transição profissional para o mundo da programação, sempre trabalhei na área de CS, CS Sales e Gestão de Pessoas</h2>
<p> 🌱 I’m currently learning JAVA + ANGULAR</h2>
<br>
<hr>
<p></p>

## **Conecte-se comigo...**
<div>
<a href="https://www.instagram.com/ibrunopires" target="_blank"><img loading="lazy" src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
<a href = "brunopires.ctto@gmail.com"><img loading="lazy" src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
<a href="https://www.linkedin.com/in/bruno-pires-046216135" target="_blank"><img loading="lazy" src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>   
</div>
<HR>

## **Habilidades**

<p align="center">
  <a href="https://skillicons.dev">
    <img src="https://skillicons.dev/icons?i=java,angular,javascript,css,html,github,python,mongodb,mysql,virtualstudio" />
  </a>
</p>
<hr>

## **GitHub Stats**
<figure>
  <a href="https://github.com/BruhhPires">
    <img loading="lazy" height="150em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=BruhhPires&layout=compact&langs_count=7&theme=vision-friendly-dark"/>
  </a>
  <a href="https://github.com/BruhhPires">
    <img loading="lazy" height="150em" src="https://github-readme-stats.vercel.app/api?username=BruhhPires&show_icons=true&theme=vision-friendly-dark&include_all_commits=true&count_private=true"/>
  </a>
</figure>

<hr>

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=BruhhPires&repo=chess-system-java&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=FFA500&text_color=FFF)](https://github.com/BruhhPires/chess-system-java)

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=BruhhPires&repo=workshop-spring-boot-mongodb&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=FFA500&text_color=FFF)](https://github.com/BruhhPires/workshop-spring-boot-mongodb)

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=BruhhPires&repo=workshop-springboot3-jpa&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=FFA500&text_color=FFF)](https://github.com/BruhhPires/workshop-springboot3-jpa)


