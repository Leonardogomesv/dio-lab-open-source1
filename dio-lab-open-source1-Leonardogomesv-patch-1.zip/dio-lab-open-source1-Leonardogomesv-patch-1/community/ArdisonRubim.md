# Hi there!

---
## My name is Ardison Rubim

---
### Connect with me: :iphone:
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/ardison-rubim/)

---
### My Skills: :desktop_computer:

![PostgreSQL](https://img.shields.io/badge/PostgreSQL-000?style=for-the-badge&logo=postgresql)
![Linux](https://img.shields.io/badge/Linux-000?style=for-the-badge&logo=linux&logoColor=FCC624)
![Python](https://img.shields.io/badge/Python-14354C?style=for-the-badge&logo=python&logoColor=black)
