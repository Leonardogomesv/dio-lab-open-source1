<div>
    <h1>Olá!!! Eu sou o Alexandre. 😎 </h1>
    <h2>Bem vindo ao meu Perfil no GitHub.</h2>
    <p> Me chamo Alexandre Mazarin Bakanovas. Sou formado em Farmácia e Bioquímica pela Universidade de São Paulo (USP) e, após algumas experiências na indústria, acabei me apaixonando pela Tecnologia, o que me levou a minha segunda graduação, agora em Engenharia de Software pelo Centro Universitário Internacional (UNINTER). Estou me dedicando à Ciência de Dados, desenvolvimento Back-end e, para complementar um pouco o conhecimento, um pouco de Front-end também.
    </p>
    <p>Essa paixão pela tecnologia me trouxe até aqui hoje e, cada dia que passa, me sinto cada vez mais realizado por ter a oportunidade de poder aprender um pouco todos os dias. 
    </p>
    <p>Com todo o meu empenho, espero poder conquistar muitas vitórias e, com isso, poder ajudar outras pessoas que, como eu, não tiveram a oportunidade de acertar em sua primeira graduação.
    </p>
</div>
<div>
    <h2>Conecte-se comigo</h2>
   <a href="https://www.linkedin.com/in/alexandre-bakanovas-3593b9167/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
    <a href = "alexandremazarinbakanovas@gmail.com.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
    <a href = "https://github.com/Alexandre-Bakanovas" target ="_blank"> <img src = "https://img.shields.io/badge/GITHUB-blue?logo=GitHub" target = "_blank" width = 98em></a>
</div>
<br>
<div align="center">
  <a href="https://github.com/Alexandre-Bakanovas">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=Alexandre-Bakanovas&show_icons=true&theme=tokyonight&include_all_commits=true&count_private=true"/>
                <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Alexandre-Bakanovas&layout=compact&langs_count=7&theme=tokyonight"/>
</div>
<div style="display: inline_block"><br>
    <h2>Tecnologias</h2>
  <img align="center" alt="Alexandre-Python" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">
  <img align="center" alt="Alexandre-PowerBI" height="30" width="30" src="https://e7.pngegg.com/pngimages/252/727/png-clipart-power-bi-business-intelligence-microsoft-analytics-microsoft-text-rectangle.png">
  <img align="center" alt="Alexandre-MySQL" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original-wordmark.svg">
  <img align="center" alt="Alexandre-Java" height="30" width="30" src="https://upload.wikimedia.org/wikipedia/pt/thumb/3/30/Java_programming_language_logo.svg/1200px-Java_programming_language_logo.svg.png">
  <img align="center" alt="Alexandre-AWS" height="30" width="30" src="https://static-00.iconduck.com/assets.00/aws-icon-2048x2048-274bm1xi.png">
  <img align="center" alt="Alexandre-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Alexandre-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
</div>
<br>
<br>

## Principais Projetos

[![Repo Python](https://github-readme-stats.vercel.app/api/pin/?username=Alexandre-Bakanovas&repo=Python&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Alexandre-Bakanovas/Python)
[![Repo C e C#](https://github-readme-stats.vercel.app/api/pin/?username=Alexandre-Bakanovas&repo=C-Cpp&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Alexandre-Bakanovas/C-Cpp)
[![Repo Curso Web](https://github-readme-stats.vercel.app/api/pin/?username=Alexandre-Bakanovas&repo=Curso_Web&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Alexandre-Bakanovas/Curso_Web)
[![Repo Curso Web](https://github-readme-stats.vercel.app/api/pin/?username=Alexandre-Bakanovas&repo=Java&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Alexandre-Bakanovas/Java)
    

## Minhas Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=83Rafa&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Alexandre-Bakanovas/dio-lab-open-source)

