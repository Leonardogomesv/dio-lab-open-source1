# Olá! 👋🏻
Meu nome é Ana Joyce dos Santos, tenho 21 anos e estou muito empolgada em estar aqui. Sou uma entusiasta no mundo do desenvolvimento e estou no início da minha jornada nessa emocionante área. Tenho um desejo genuíno de aprender e crescer como desenvolvedora, explorando novas tecnologias e enfrentando desafios empolgantes.

# Linguagens em que gostaria de me desenvolver 💻
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![TypeScript](https://img.shields.io/badge/TypeScript-000?style=for-the-badge&logo=typescript)
# Conecte-se comigo 🔗🌎
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/sntjoyce/) 
[![Github](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=Github&logoColor=fffff)](https://github.com/AJoyceSantos)