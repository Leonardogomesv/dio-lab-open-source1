# Bem-vindos ao meu Perfil

Meu nome é Bordinhon, tenho 16 anos e sou apaixonado por tecnologia e skate.

Recentemente comecei a desenvolver um interesse por programação, e hoje em dia estou me aprofundando nisso junto com o meu ensino médio técnico."

Abaixo disso tem uma tabela mostrando o  que eu sei e o meu nivel de conhecimento sobre aquilo.

| Conhecimento    | Nivel |
|---------|-------|
| C#    | Intermediário    |
| MySQL   | Básico    |
| Git e GitHub  | Básico    |

#
# CONECTE-SE COMIGO
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-FFF?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/eduardo-bordinhon-068211294/)