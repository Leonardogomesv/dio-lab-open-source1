# André da Silveira Pereira
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/dev-andre-pereira/?locale=en_US)

I am a technology enthusiast interested in Data Science and Software Engineering. I possess strong skills in Java and Python programming, with a particular focus on back-end development. Additionally, I have knowledge in JavaScript through React.js and Node.js.

### Hard Skills
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=Java)
![Spring](https://img.shields.io/badge/SpringBoot-000?style=for-the-badge&logo=Spring)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![HTML](https://img.shields.io/badge/HTML-000?style=for-the-badge&logo=HTML5)
![CSS](https://img.shields.io/badge/CSS-000?style=for-the-badge&logo=CSS3)
![JS](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![REACT](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)
![SQL](https://img.shields.io/badge/SQL-000?style=for-the-badge&logo=sql)

### Soft Skills
![Communicative](https://img.shields.io/badge/Communicative-000?style=for-the-badge)
![Communicative](https://img.shields.io/badge/Communicative-000?style=for-the-badge)
![Communicative](https://img.shields.io/badge/Communicative-000?style=for-the-badge)
![Proactive](https://img.shields.io/badge/Proactive-000?style=for-the-badge)
![Organized](https://img.shields.io/badge/Organized-000?style=for-the-badge)
![Empathetic](https://img.shields.io/badge/Empathetic-000?style=for-the-badge)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Add0z&layout=compact&bg_color=000&border_color=4622bd&title_color=4f1df2&text_color=FFF)