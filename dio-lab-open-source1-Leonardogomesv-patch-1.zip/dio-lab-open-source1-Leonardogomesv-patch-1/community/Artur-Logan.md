
# Artur Logan

Olá, eu sou Artur Logan e estudo programação, principalmente Java, SpringBoot e GitHub.

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/arturlogan/)  
[![GitHub](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=github&logoColor=0E76A8)](https://github.com/Artur-Logan)  

## Habilidades

![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![GitHub](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=github&logoColor=0E76A8)
![SpringBoot](https://img.shields.io/badge/Springboot-000?style=for-the-badge&logo=springboot&logoColor=0E76A8)

## GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Artur-Logan&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Artur-Logan&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Principais Desafios de Projeto DIO

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Artur-Logan&repo=Netflix-DIO&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Artur-Logan/Netflix-DIO)
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Artur-Logan&repo=dio-trilha-java-basico&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Artur-Logan/dio-trilha-java-basico)

## Minha Contribuições 
