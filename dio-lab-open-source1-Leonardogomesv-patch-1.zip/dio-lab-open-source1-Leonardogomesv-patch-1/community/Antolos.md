# Antolos

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-888?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/antonio-noronha/)


## Habilidades
![Python](https://img.shields.io/badge/Python-888?style=for-the-badge&logo=python)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Antolos&theme=transparent&bg_color=888&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=FFFFF&text_color=FFF)

## Minhas Contribuições

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Antolos&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Antolos/https://github.com/Antolos/dio-lab-open-source)