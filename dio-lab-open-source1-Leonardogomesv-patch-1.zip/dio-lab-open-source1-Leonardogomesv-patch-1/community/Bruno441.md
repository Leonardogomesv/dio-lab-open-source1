# Bruno Ferreira
## DIO | Aprendendo a contribuir num projeto OpenSource

Esse projeto é para cunho acadêmico e para os alunos do bootcamp da Dio desenvolverem suas competências.

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](www.linkedin.com/in/brunoww-ferreira-2022dev)

