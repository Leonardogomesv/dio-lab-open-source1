
# Jean Carlos

Me chamo Jean apelido Bmipz, estou mudando de carreira profissional, foco de aprendizagem no começo foi HTML e CSS, mas estou cursando um curso Desenvolvedor de Sistema, onde adorei trabalhar com linguagem C# e agora estou fazendo Desenvolvimento Java com Cloud AWS, este é primeiro desafio proposto.

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](www.linkedin.com/in/jean-carlos-3845a926b)  

## Habilidades
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5) 
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)

## GitHub status
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Bmipz&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Meus projetos
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Bmipz&repo=the-last-of-us&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Bmipz/the-last-of-us)
 