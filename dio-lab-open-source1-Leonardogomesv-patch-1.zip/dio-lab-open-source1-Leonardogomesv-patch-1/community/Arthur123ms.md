
# Arthur Magalhães de Souza

## ✉️ Contas :

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/arhur-magalh%C3%A3es-444565230/) 

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/arthur3208/)


[![GitHub](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=Github)](https://github.com/Arthur123ms)




## 🚀 Skills :



![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)

![GitHub](https://img.shields.io/badge/github-000?style=for-the-badge&logo=github&logoColor=8560)

![Git](https://img.shields.io/badge/git-000?style=for-the-badge&logo=git&logoColor=8560)
