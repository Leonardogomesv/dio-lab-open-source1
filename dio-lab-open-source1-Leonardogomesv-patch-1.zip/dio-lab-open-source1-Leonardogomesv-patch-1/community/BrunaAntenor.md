
#### Prazer, meu nome é Bruna. 
Graduada em Bacharelado e Licenciatura Plena em Letras (Português/ Espanhol) pela Universidade Estadual Paulista Júlio de Mesquita Filho, Campus de Araraquara.

Estou em transição de carreira me aventurando no mundo tecnológico.

Sou extremamente dedicada e gosto de me destacar em tudo o que faço aprofundando os meus conhecimentos e superando as minhas próprias expectativas de sucesso.

## 🔗 Conecte-se Comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/bruna-antenor/)


## 📚 Habilidades:

Treinamento especial em Soft Skills.


## Atividades em andamento:

BootCamp Santander 2023 - Backend Java