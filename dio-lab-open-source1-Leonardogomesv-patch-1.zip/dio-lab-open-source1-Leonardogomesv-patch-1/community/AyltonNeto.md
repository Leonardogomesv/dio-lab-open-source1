# Aylton Neto
Atualmente focando em Engenharia de Dados na Nuvem AWS. Gosto muito de lidar com dados em todos as etapas desde a extração até as análises. Pretendo concluir projetos da DIO para enriquecer meu portifólio e quem sabe conseguir uma oprtunidade 😉

### Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/AyltonNeto/)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=yahoo&logoColor=purple)](mailto:aylton_12@yahoo.com.br)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/AyltonNeto/)

### Habilidades
![Python](https://img.shields.io/badge/python-000?style=for-the-badge&logo=python&logoColor=ffdd54)
![AWS](https://img.shields.io/badge/AWS-000.svg?style=for-the-badge&logo=amazon-aws&logoColor=white)
![Docker](https://img.shields.io/badge/Docker-000?style=for-the-badge&logo=docker&logoColor=)
![Apache Spark](https://img.shields.io/badge/ApacheSpark-000?style=for-the-badge&logo=apachespark&logoColor=yeallow)
![Linux](https://img.shields.io/badge/linux-000?style=for-the-badge&logo=linux&logoColor=)
![SQLite](https://img.shields.io/badge/sqlite-000?style=for-the-badge&logo=sqlite&logoColor=)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc) 
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=purple)](https://docs.github.com/)
![VS Code](https://img.shields.io/badge/VS%20Code-000.svg?style=for-the-badge&logo=visual-studio-code&logoColor=blue)

### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AyltonNeto&theme=transparent&bg_color=000&border_color=&show_icons=true&icon_color=&title_color=gray&text_color=gray)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AyltonNeto&bg_color=000&border_color=gray&title_color=gray&text_color=gray)