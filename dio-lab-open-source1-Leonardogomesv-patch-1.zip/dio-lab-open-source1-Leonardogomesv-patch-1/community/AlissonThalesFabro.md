## Alisson Thales Fabro

## Conecte-se comigo 
![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)https://www.linkedin.com/in/alisson-t-fabro-51258520b/

## Habilidades
![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

![MySQL](https://img.shields.io/badge/MySQL-000?style=for-the-badge&logo=mysql&logoColor=005C84)

