
# Ildon

Olá!
Me chamo Ildon, sou carioca e iniciante no mundo da programação.  
Estou emplogado com a possibilidade de criar o meu primeiro jogo neste bootcamp.


## Redes Socias:
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github)](https://github.com/Brabo-coach/)

## Linguagens de Marcação e Estilo:
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)

![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)

## Linguagens:
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)


## Ferramentas:
![Visual Studio Code](https://img.shields.io/badge/Visual_Studio_Code-000?style=for-the-badge&logo=visualstudiocode)