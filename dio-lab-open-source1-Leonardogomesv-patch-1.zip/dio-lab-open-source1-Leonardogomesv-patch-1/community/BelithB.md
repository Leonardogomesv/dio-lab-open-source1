# Belith Bernardo
Hello there. 

Designer and photoshop artist in carrer transition.

## conecte-se comigo:

[![LinkedIn](https://img.shields.io/badge/LinkedIn-FFF?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/belith-bernardo/) 
[![Github](https://img.shields.io/badge/Github-fff?style=for-the-badge&logo=Github&logoColor=357)](https://www.github.com/BelithB)
[![Instagram](https://img.shields.io/badge/Instagram-fff?style=for-the-badge&logo=instagram)](https://www.instagram.com/Belith/)


## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=BelithB&theme=transparent&bg_color=00253f&border_color=fff&show_icons=true&icon_color=91ff95&title_0e7a8=91ff95&text_color=fff)


