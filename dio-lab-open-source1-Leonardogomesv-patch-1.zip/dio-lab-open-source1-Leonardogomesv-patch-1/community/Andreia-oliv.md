
# 👋 Olá, eu sou Andreia Oliveira!

Sou formada em Ciência da Computação e em Designer Gráfico. Sou apaixonada por tecnologia e estou sempre em busca de aprender algo novo.  Atualmente, meu foco é em desenvolvimento web e ciência de dados.

##  🚀 Habilidades

- Desenvolvimento Frontend: HTML, CSS, JavaScript
- Ciência de Dados: Python, Pandas, Scikit-Learn

## 🌱 Atualmente Aprendendo

Estou aprimorando minhas habilidades em Frontend e explorando técnicas em ciência de dados.


## 📫 Como me Encontrar

- [LinkedIn](https://www.linkedin.com/in/andreia-oliveira-232681256/)
- [Instagram](https://www.instagram.com/deeiah_araujo/)

## 😄 Sobre Mim

Além da programação, gosto de café, livros e passeios ao ar livre.

Vamos nos conectar e aprender juntos!


