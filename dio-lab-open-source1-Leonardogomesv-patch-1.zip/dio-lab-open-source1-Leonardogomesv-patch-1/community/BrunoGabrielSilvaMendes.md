#  Sobre mim
Oi, sou o Bruno, e estou mergulhado no emocionante mundo da tecnologia e do desenvolvimento. Atualmente, estou cursando Análise e Desenvolvimento de Sistemas, onde mergulho fundo no entendimento dos sistemas que moldam nossa era digital. Estou focado em estudar Java, uma linguagem de programação que me fascina pela sua versatilidade e poder.

## Contatos
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/brunogabriels/)

## 💻 Resumos das Aulas

## GitHub Stats
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=BrunoGabrielSilvaMendes&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Habilidades
![Java](https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=openjdk&logoColor=white)
![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![Php](https://img.shields.io/badge/PHP-777BB4?style=for-the-badge&logo=php&logoColor=white)
![SpringBoot](https://img.shields.io/badge/Spring-6DB33F?style=for-the-badge&logo=spring&logoColor=white)
![PostGreSQL](https://img.shields.io/badge/PostgreSQL-316192?style=for-the-badge&logo=postgresql&logoColor=white)
![MongoDB](https://img.shields.io/badge/MongoDB-4EA94B?style=for-the-badge&logo=mongodb&logoColor=white)

## GitHub Streak
[![GitHub Streak](https://streak-stats.demolab.com/?user=BrunoGabrielSilvaMendes&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)