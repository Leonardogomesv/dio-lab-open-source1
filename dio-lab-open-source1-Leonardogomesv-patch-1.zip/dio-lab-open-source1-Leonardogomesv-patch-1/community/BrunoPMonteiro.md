# Bruno Monteiro  || Dev Fullstack Java & Angular

Olá, me chamo Bruno Monteiro e sou desenvolvedor Java, estou cursando Desenvolvimento de softwares Multiplataforma na Fatec de Cotia. Além disso me aventuro no copywriting para desenvolver minha escrita criativa. Desejo elevar ainda mais minhas habilidades na programação nesse bootcamp e quem sabe ja ingressar em uma empresa.

##  Minhas skills
- [HTML e CSS](https://github.com/BrunoPMonteiro)
- [Javascript](https://github.com/BrunoPMonteiro)
- [Java](https://github.com/BrunoPMonteiro)

## Você pode me encontrar em:

| Aulas | Resumos |
|-------|---------|
|github|https://github.com/BrunoPMonteiro|
|LinkedIn|https://www.linkedin.com/in/bruno-de-paiva-monteiro-795419191/|
|Instagram|https://www.instagram.com/brunopmonteiro/|
