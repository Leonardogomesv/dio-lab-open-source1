# Andréa Soares
Desenvolvedora fullstack desde 2021

### Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://www.dio.me/users/andreatenis)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:asoaresdev@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/andrea-rsoares/)

### Habilidades
![HTML5](https://img.shields.io/badge/HTML-000?style=for-the-badge&logo=html5&logoColor=30A3DC)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=E94D5F)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript&logoColor=30A3DC)
![TypeScript](https://img.shields.io/badge/TypeScript-000?style=for-the-badge&logo=typescript)
![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)
![StyledComponents](https://img.shields.io/badge/StyledComponents-000?style=for-the-badge&logo=styledcomponents)
![MUI](https://img.shields.io/badge/Mui-000?style=for-the-badge&logo=mui)
![Node](https://img.shields.io/badge/Node-000?style=for-the-badge&logo=nodedotjs)
![MySql](https://img.shields.io/badge/MySql-000?style=for-the-badge&logo=mysql)
![SQLite](https://img.shields.io/badge/SQLite-000?style=for-the-badge&logo=sqlite)
![Express](https://img.shields.io/badge/Express-000?style=for-the-badge&logo=express)
![Postman](https://img.shields.io/badge/Postman-000?style=for-the-badge&logo=postman)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc) 
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)


### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Asoaresdev&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Asoaresdev&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)


### Meus Principais Desafios de Projeto e Estudo
[![Repo API ](https://github-readme-stats.vercel.app/api/pin/?username=Asoaresdev&repo=estudo-POO2&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Asoaresdev/estudo-POO2)
[![Repo hackaton ](https://github-readme-stats.vercel.app/api/pin/?username=Asoaresdev&repo=indique-web-projeto-ProviHackWoman&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Asoaresdev/indique-web-projeto-ProviHackWoman)
[![Repo clone ifood ](https://github-readme-stats.vercel.app/api/pin/?username=Asoaresdev&repo=Projeto-Final-do-bootcamp-Labenu-4foodA&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Asoaresdev/Projeto-Final-do-bootcamp-Labenu-4foodA)