##### Name:

# Allan Tozelli
Sou analista de sistemas formado pela UNIP e atualmente cursando 1º semestre de Engenharia de Software pela faculdade Estácio. Possuo 4 anos de experiência na área de suporte a usuários.

Apaixonado pela área de desenvolvimento, buscando sempre novos conhecimentos e oportunidades.

### Hard Skills

![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)

![CSS3](https://img.shields.io/badge/css3-%231572B6.svg?style=for-the-badge&logo=css3&logoColor=white) 
![HTML5](https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white)
![JavaScript](https://img.shields.io/badge/javascript-%23323330.svg?style=for-the-badge&logo=javascript&logoColor=%23F7DF1E) 

![Git](https://img.shields.io/badge/git-%23F05033.svg?style=for-the-badge&logo=git&logoColor=white) 
![GitHub](https://img.shields.io/badge/github-%23121011.svg?style=for-the-badge&logo=github&logoColor=white)

### Soft Skills
![Leal](https://img.shields.io/badge/Leal-red)
![Pro-ativo](https://img.shields.io/badge/Pro_Ativo-blue)
![Adaptavel](https://img.shields.io/badge/Adaptável-red)
![Organizado](https://img.shields.io/badge/Organizado-blue)
![Comprometido](https://img.shields.io/badge/Comprometido-red)

### Social Media

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/allantozelli/) 
[![GitHub](https://img.shields.io/badge/Git-Hub?style=for-the-badge&logo=GitHub&color=black)](https://github.com/AllanTozelli)
[![Dio](https://img.shields.io/badge/Dio-perfil?style=for-the-badge&color=black)](https://web.dio.me/users/allan_tozelli?tab=skills)


### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AllanTozelli&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AllanTozelli&layout=compact&bg_color=013&border_color=30A3DC&title_color=E94D5F&text_color=FFF)