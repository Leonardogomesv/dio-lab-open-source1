

# Opa, tudo bem? Sou O Gui (Altskyforce) 🚀

😎 Me chamo **Guilherme Souza de Oliveira**.

**Graduando Engenharia da Computação** na FAMETRO

👩‍💻 Trabalho atualmente na [TechLog](https://www.econodata.com.br/consulta-empresa/03613289000102-TECHLOG-SERVICOS-DE-GESTAO-E-SISTEMAS-INFORMATIZADOS-LTDA) sendo Suporte Técnico

🧠 Estou aprendendo **Programação**, **Hardware** e **Redes**

Meu foco é extremo em aprimorar e aperfeiçoar meu conhecimento ao máximo na área tecnológica, estou preparado para elevar minhas habilidades durante os próximos 5 anos.
## 🛠 Habilidades

Programação
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

Hardwares de Computadores.
![Windows](https://img.shields.io/badge/Windows-000?style=for-the-badge&logo=windows&logoColor=2CA5E0)

Redes de Computadores.

Suporte técnico Presencial / Remoto.


## 🔗 Links

[![Youtube](https://img.shields.io/badge/youtube-000?style=for-the-badge&logo=youtube&logoColor=white)](https://www.youtube.com/channel/UCb1kPZuugesXws2MR5hwlYA/videos)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/guilhermetec2020/)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/sou.o.gui_00/)


