## 🚀 Sobre mim
Esse momento marca o início de uma grande jornada!

Atualmente (31/08/2023) não possuo muita história, mas o começo sempre parte de algum lugar ^_^

Minhas plataformas de mídias sociais:

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/arnaldo-ferreira-silva-a4810b206/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/arnaldofs_/)

[![Facebook](https://img.shields.io/badge/Facebook-000?style=for-the-badge&logo=facebook)](https://www.facebook.com/arnaldo.ferreirasilva.33/)

[![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord)](https://www.discord.com/in/Arnaldo#1291/)

## Obrigado pela sua atenção! 😊