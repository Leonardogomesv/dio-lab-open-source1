# Elias Boaroli

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-FFF?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/elias-boaroli/)

[![Instagram](https://img.shields.io/badge/Instagram-FFF?style=for-the-badge&logo=instagram)](https://www.instagram.com/eliasboaroli/)

## Habilidades

![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=BoaroliElias&layout=compact&theme=dracula&hide_border=true&bg_color=0D1117&title_color=CC6699&icon_color=CC6699)

![Java](https://img.shields.io/badge/java-0D1117.svg?style=for-the-badge&logo=openjdk&logoColor=marrom)

![TypeScript](https://img.shields.io/badge/TypeScript-0D1117.svg?style=for-the-badge&logo=TypeScript&logoColor=marrom)

![SQL](https://img.shields.io/badge/SQL-0D1117.svg?style=for-the-badge&logo=database&logoColor=marrom)

![PL/SQL](https://img.shields.io/badge/PL/SQL-0D1117.svg?style=for-the-badge&logo=database&logoColor=marrom)

![GitHub](https://img.shields.io/badge/GitHub-0D1117.svg?style=for-the-badge&logo=GitHub&logoColor=CC6699)

![Git](https://img.shields.io/badge/Git-0D1117.svg?style=for-the-badge&logo=Git&logoColor=laranja)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=BoaroliElias&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)


## Sobre 

Posuo 2 anos de experiência no desenvolvimento de aplicações Java, C#, PowerBuilder, Oracle e Spring, atuando em projetos desafiadores e inovadores que me permitiram aprimorar minhas habilidades técnicas e de resolução de problemas. 

Durante minha trajetória profissional, tive a oportunidade de trabalhar com equipes multidisciplinares e enfrentar diversos desafios, o que me proporcionou um entendimento abrangente das melhores práticas de desenvolvimento e uma sólida capacidade de colaboração. 

## Minhas contribuições
