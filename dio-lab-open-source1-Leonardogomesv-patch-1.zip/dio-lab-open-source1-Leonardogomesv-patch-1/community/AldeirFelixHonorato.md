# APRESENTAÇÃO
Olá! Me chamo Aldeir. Sou de Paraíba do Sul/RJ.
Tenho 38 anos. Sou farmacêutico.

Atualmente estou em transição de carreira para programador, dando meus primeiros passos na linguagem *Python*.

Estou super empolgado com esta nova etapa de aprendizado!

#
## Minhas Redes Sociais

[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/aldeirhonoratocoach/)
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-000?style=for-the-badge)](https://www.dio.me/users/aldeirfelixhonorato)
