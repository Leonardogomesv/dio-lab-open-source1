<h1 align="center">Hi , I'm Augusto Rengel</h1>
<div align="center">
<a href = "mailto:Augustowollace@hotmail.com"><img src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
<a href="https://www.linkedin.com/in/augusto-wollace-de-lima-rengel-4922071b7/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>
</div>

[![An image of @augustorengel's Holopin badges, which is a link to view their full Holopin profile](https://holopin.me/augustorengel)](https://holopin.io/@augustorengel)

## <picture><img src = "https://github.com/0xAbdulKhalid/0xAbdulKhalid/raw/main/assets/mdImages/about_me.gif" width = 50px></picture> **About me**

My first contact with programming was in 2018, at the beginning of my Biomedical Engineering college degree. However, it was in 2020, with the creation of my first app, that I decided to focus on software development. Since then, I have published one more app and worked on several projects while studying Python, C#, and Kotlin. <br>
Currently, I work as an intern at Siemens Healthineers, where I am responsible for developing systems and automating processes.
<br><br>

## <img src="https://media2.giphy.com/media/QssGEmpkyEOhBCb7e1/giphy.gif?cid=ecf05e47a0n3gi1bfqntqmob8g9aid1oyj2wr3ds3mg700bl&rid=giphy.gif" width ="25"><b> Skills</b>

<picture> <img align="right" src="https://github.com/7oSkaaa/7oSkaaa/blob/main/Images/Right_Side.gif?raw=true" width = 350px></picture>

### Mobile

<a href="https://skillicons.dev">
  <img src="https://skillicons.dev/icons?i=androidstudio,kotlin,java,firebase&perline=14" />
</a>

### Desktop

<a href="https://skillicons.dev">
  <img src="https://skillicons.dev/icons?i=cs,dotnet,py,qt&perline=14" />
</a>

### Softwares and Tools

<a href="https://skillicons.dev">
  <img src="https://skillicons.dev/icons?i=git,github,figma,unity,blender,mysql&perline=14" />
</a>
