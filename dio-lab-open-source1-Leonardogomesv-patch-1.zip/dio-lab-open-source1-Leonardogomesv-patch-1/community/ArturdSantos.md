# Artur
olá! me chamo Artur e estou iniciando uma nova jornada!!

## habilidades
*em desenvolvimento*

## conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/artur-santos-1b0500170/)  [![Dio](https://img.shields.io/badge/Dio-blue?style=for-the-badge&logo=Dio)](https://www.dio.me/users/ksas123jesus)

## biografia

**Artur Felipe Dos Santos,
nascido em pernambuco aos 16 anos de idade mudou para são paulo, Atualmente 27 anos de idade,
reside em são paulo.**
