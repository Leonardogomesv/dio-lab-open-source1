<div align="center">
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=oswald&weight=200&duration=1500&pause=500&color=FFC900&background=7F000000&center=true&width=435&lines=Hello!+My+name+is+Almir+Gabriel;I'm+26+years+old;I'm+studying+to+be+a+front+end+developer;Be+Welcome+!+" alt="Typing SVG" /></a>
</div>

<div align="center">
<img height="200em" weight="180em" src="https://i.pinimg.com/originals/09/c6/29/09c62903beeba336dc9da76eb5c9a107.gif"/>
</div>

<div align="center"> 
<a href="https://www.instagram.com/_almir_gabriel_/" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white"</a>
<a href = "mailto:almir.gabriel.andrade@gmail.com"> <img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
<a href="https://www.linkedin.com/in/almir-gabriel-andrade-82377b25a/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" style="border-radius: 30px" target="_blank"></a> 
 <br><br>
  <img alingn="center" src="https://komarev.com/ghpvc/?username=AlmirGabriel&style=for-the-badge&label=Total+profile+visits&color=red"/>
 </div>
 
<div style="display: inline_block"><br>
<h1>My Skills</h1>
  <a target="_blank" href="https://developer.mozilla.org/pt-BR/docs/Web/HTML"><img align="center" alt="HTML" height="40" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <a target="_blank" href="https://developer.mozilla.org/pt-BR/docs/Web/CSS"><img align="center" alt="CSS" height="40" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <a target="_blank" href="https://developer.mozilla.org/pt-BR/docs/Web/JavaScript"><img align="center" alt="JavaScript" height="40" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <a target="_blank" href="https://git-scm.com/"><img align="center" alt="GIT" height="40" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-original.svg">
</div>

<div>
<h1>I'm studying</h1>
   <a target="_blank" href="https://developer.mozilla.org/pt-BR/docs/Web/JavaScript"><img align="center" alt="JavaScript" height="40" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
   <a target="_blank" href="https://nodejs.org/en/docs/"><img align="center" alt="NodeJS" height="40" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-original.svg"></a>
</div>

<div align="center">
<h1></h1>
<a href="https//beacons.ai/AlmirGabriel">
<img height="160em" src="https://github-readme-stats.vercel.app/api?username=AlmirGabriel&show_icons=true&theme=outrun"/>
<img height="160em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=AlmirGabriel&layout=compact&theme=outrun"/>
</div>
