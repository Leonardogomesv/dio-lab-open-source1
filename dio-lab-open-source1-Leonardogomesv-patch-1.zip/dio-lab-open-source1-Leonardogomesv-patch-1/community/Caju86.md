# Caju86

## Quem sou eu
  Me chamo Carlos Junior, tenho 36 anos, Pernambucano, em busca do sonho de ser Desenvolvedor Backend!!!!

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/carlos-silva-52218247/)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/carlos_junior.ti/?hl=pt-br//)
[![LinkedIn](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=Github&logoColor=0E76A8)](https://github.com/Caju86/)

## Habilidades
![GitGub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=Github) 
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java) Em desenvolvimento

## Github Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Caju86&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Caju86&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Caju86/dio-lab-open-source)

## Minhas Contribuições
[![GitHub Streak](https://streak-stats.demolab.com/?user=Caju86&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)

Ainda sem contribuições

https://github.com/Caju86