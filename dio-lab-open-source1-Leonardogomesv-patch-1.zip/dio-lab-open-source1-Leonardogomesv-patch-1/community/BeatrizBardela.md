Olá!
Tenho 27 anos e decidi aprofundar meus conhecimentos de análise de dados,  aprender Python e SQL / NoSQL.

**Minha meta atual é me tornar Analista de BI**.


**Habilidades**
|Nível: Básico|
|----------|
|Git       |
|Github    |
|Python    |

|Nível: Intermediário |
|---------------------|
|Excel                |
|Matemática Financeira|


## Redes Sociais
Você pode me encontrar nas seguintes redes sociais:

- **LinkedIn**: [Beatriz Bardela Pereira](https://www.linkedin.com/in/beatriz-bardela-pereira-10575731/)

- **Email**: [biabardela@gmail.com](mailto:biabardela@gmail.com)
