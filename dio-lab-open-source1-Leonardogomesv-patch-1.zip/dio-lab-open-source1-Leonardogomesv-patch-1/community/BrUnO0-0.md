## 🤓 Bruno Pontes

Prazer, sou Bruno. Sou novo na área de Tecnologia, fiquei por 2 anos estudando ***Gestão da Produção Industrial***, mas durante o processo não consegui mais me adaptar a faculdade, então decide fazer um transição, aonde hoje estou cursando **Engenharia de Software**.

Sinceramente não dava muita bola para plataforma DIO, porém depois que começei me aprofundar mais nos cursos, sinceramente não sei quando vou parar mais, são muito bons os cursos, além dos professores claro. 

## Conecte-se Comigo!

[![Email](https://img.shields.io/badge/-Email-'?style=for-the-badge&logo=microsoft-outlook&logoColor=2fe0ff&color=020000)](mailto:beh2acf@gmail.com)
[![Static Badge](https://img.shields.io/badge/-Linkedin-'?style=for-the-badge&logo=linkedin&logoColor=2fe0ff&color=020000)](https://www.linkedin.com/in/bruno-pontes-2b912b227/)
[![Insta](https://img.shields.io/badge/-Instagram-'?style=for-the-badge&logo=instagram&logoColor=2fe0ff&color=020000)](https://www.instagram.com/brube.bl/)

## Habilidades
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS](https://img.shields.io/badge/css-000?style=for-the-badge&logo=CSS3)
![JS](https://img.shields.io/badge/JAVASCRIPT-000?style=for-the-badge&logo=Javascript&)

## Git Stats
<h3>
  
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=BrUnO0-0&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

</h3>

